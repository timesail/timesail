﻿# -*- coding: utf-8 -*-
import xbmc, xbmcgui, xbmcplugin, xbmcaddon
import urllib2, urllib, urlparse, re, sys, os, shutil, zlib, simplejson, HTMLParser

# 编码
if sys.getdefaultencoding() != 'utf-8':
	reload(sys)
	sys.setdefaultencoding('utf-8')

# 常数
__addonname__ = '冰豆视频'
__addonid__   = 'plugin.video.bingdou'
__addon__     = xbmcaddon.Addon(id=__addonid__)

# 函数
def logData(data, filePath='C:\Users\Administrator\Desktop\%s.txt' % __addonname__):
	filePath = filePath.decode('utf-8')
	fHandle = open(filePath, 'w')
	fHandle.write(data)
	fHandle.close()

def dialog(str, type='ok'):
	if type == 'ok': xbmcgui.Dialog().ok(__addonname__, str)
	elif type == 'textviewer': xbmcgui.Dialog().textviewer(__addonname__, str)

def saveHistory(history):
	dataDir = getDataDir()
	filePath = os.path.join(dataDir, 'history.log')
	if not os.path.exists(filePath): # 文件不存在则创建文件
		fHandle = open(filePath, 'w')
		historyList = [history]

	else: # 文件存在则读取文件
		try:
			fHandle = open(filePath, 'r+')
			historyList = simplejson.load(fHandle)
			if history in historyList: historyList.remove(history)
			historyList.insert(0, history)
			fHandle.seek(0, 0)
		except simplejson.scanner.JSONDecodeError: # 文件非json格式则重新创建文件
			fHandle = open(filePath, 'w')
			historyList = [history]
			pass

	simplejson.dump(historyList, fHandle, ensure_ascii=False)
	fHandle.close()

def deleteHistory():
	index = int(params.get('index'))

	dataDir = getDataDir()
	filePath = os.path.join(dataDir, 'history.log')
	fHandle = open(filePath, 'r+')

	historyList = simplejson.load(fHandle)
	if xbmcgui.Dialog().yesno(__addonname__, '确定要删除历史记录 [%s] 吗' % historyList[index]['label']):
		historyList.pop(index)
		fHandle.seek(0, 0)
		fHandle.truncate()
		simplejson.dump(historyList, fHandle, ensure_ascii=False)

		page = params.get('curpage')
		xbmc.executebuiltin('Container.Update(%s,replace)' % createUrl({'mode': 'history', 'change': 'refresh', 'curpage': page}))

	fHandle.close()

def clearHistory():
	dataDir = getDataDir()
	filePath = os.path.join(dataDir, 'history.log')
	if os.path.exists(filePath):
		fHandle = open(filePath, 'r')
		try:
			historyList = simplejson.load(fHandle)
			fHandle.close()
			if xbmcgui.Dialog().yesno(__addonname__, '历史记录共%d条，是否清除' % len(historyList)):
				os.remove(filePath)
				xbmcgui.Dialog().ok(__addonname__, '清除记录成功，共%d条' % len(historyList))

		except simplejson.scanner.JSONDecodeError:
			fHandle.close()
			if xbmcgui.Dialog().yesno(__addonname__, '历史记录为空或格式有误，是否清除'):
				os.remove(filePath)
				xbmcgui.Dialog().ok(__addonname__, '清除记录成功')

	else: xbmcgui.Dialog().ok(__addonname__, '历史记录不存在')

def addChannel():
	m3uFile = xbmcgui.Dialog().browse(1, '选择要添加的自定义频道M3U文件', 'files', '.m3u').decode('utf-8')
	if not m3uFile: return

	dataDir = getDataDir()
	m3uDir = os.path.join(dataDir, 'M3U')
	if not os.path.exists(m3uDir): os.makedirs(m3uDir)

	m3uName = os.path.basename(m3uFile)
	if m3uName in [entry.decode('utf-8') for entry in os.listdir(m3uDir)]:
		copy = xbmcgui.Dialog().yesno(__addonname__, 'M3U文件 [%s] 已存在，是否更新' % m3uName)
		if not copy: return

	shutil.copy(m3uFile, m3uDir)
	xbmcgui.Dialog().ok(__addonname__, '成功添加M3U文件 [%s]' % m3uName)

def removeChannel():
	dataDir = getDataDir()
	m3uDir = os.path.join(dataDir, 'M3U', '')

	m3uFile = xbmcgui.Dialog().browse(1, '选择要删除的自定义频道M3U文件', 'files', '.m3u', defaultt=m3uDir).decode('utf-8')
	m3uName = os.path.basename(m3uFile)
	if not m3uName: return

	delete = xbmcgui.Dialog().yesno(__addonname__, '确定要删除M3U文件 [%s] 吗' % m3uName)
	if not delete: return

	os.remove(m3uFile)
	xbmcgui.Dialog().ok(__addonname__, '成功删除M3U文件 [%s]' % m3uName)

def manageChannel():
	list = ['添加自定义频道', '删除自定义频道']
	while True:
		select = xbmcgui.Dialog().select('管理自定义频道', list)
		if select == -1: break
		elif select == 0: addChannel()
		elif select == 1: removeChannel()

def getDataDir():
	dataDir = xbmc.translatePath( __addon__.getAddonInfo('profile')).decode('utf-8')
	if not os.path.exists(dataDir): os.makedirs(dataDir)
	return dataDir

def getAddonDir():
	addonDir = xbmc.translatePath( __addon__.getAddonInfo('path')).decode('utf-8')
	return addonDir

def getHttpData(url):
	request = urllib2.Request(url)
	request.add_header('User-Agent', 'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0)')

	maxtimes = 10
	for t in range(maxtimes):
		try:
			response = urllib2.urlopen(request)
			httpData = response.read()
			break
		except Exception, e:
			if '11004' in str(e):
				if t<maxtimes-1: continue
				else: xbmcgui.Dialog().ok(__addonname__, '网络错误 %s %s %d次' % (url, str(e), maxtimes))
			else: xbmcgui.Dialog().ok(__addonname__, '网络错误 %s %s' % (url, str(e)))
			return

	if response.headers.get('content-encoding', None) == 'gzip':
		httpData = zlib.decompress(httpData, zlib.MAX_WBITS|32)

	response.close()
	return httpData

def postHttpData(url, data):
	request = urllib2.Request(url, urllib.urlencode(data))
	request.add_header('User-Agent', 'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0)')

	maxtimes = 10
	for t in range(maxtimes):
		try:
			response = urllib2.urlopen(request)
			httpData = response.read()
			break
		except Exception, e:
			if '11004' in str(e):
				if t<maxtimes-1: continue
				else: xbmcgui.Dialog().ok(__addonname__, '网络错误 %s %s %d次' % (url, str(e), maxtimes))
			else: xbmcgui.Dialog().ok(__addonname__, '网络错误 %s %s' % (url, str(e)))
			return

	if response.headers.get('content-encoding', None) == 'gzip':
		httpData = zlib.decompress(httpData, zlib.MAX_WBITS|32)

	response.close()
	return httpData

def getPoster(url):
	poster = os.path.join(getAddonDir(), 'media', 'bingdou.png')
	siteList = [(getDataDir(), 'tv'), ('m.tv.bingdou.net', 'tv'), ('api.bingdou.net', 'tv'), ('www.iqiyi.com', 'qiyi'), ('v.qq.com', 'qq'), ('v.youku.com', 'youku'), ('www.tudou.com', 'tudou'), ('www.mgtv.com', 'mgtv'), ('tv.sohu.com', 'sohu'), ('www.letv.com', 'levp'), ('www.le.com', 'levp'), ('www.1905.com', '1905'), ('vip.1905.com', '1905'), ('vip.m1905.com', '1905'), ('www.m1905.com', '1905'), ('www.fun.tv', 'fengxing'), ('v.pptv.com', 'pptv'), ('www.wasu.cn', 'huashu'), ('tv.cctv.com', 'cntv'), ('www.hanju.cc', 'hanju'), ('v.360kan.com', '360kan'), ('vod.kankan.com', 'kankan')]
	for site in siteList:
		if site[0] in url: poster = os.path.join(getAddonDir(), 'media', '%s.png' % site[1])
	return poster

def getInterface(url):
	interfaceList = []
	if url.startswith('../play/?play='): interfaceList.extend(['采集接口'])
	else:
		interfaceList.extend(['通用接口'])
		siteList = [('www.iqiyi.com', ['专用接口(qiyi)'])]
		for site in siteList:
			if site[0] in url: interfaceList.extend(site[1])
	return interfaceList

def createSelect(list, index, value):
	result = []
	if index == -1: #  一元列表
		for entry in list:
			if entry == value: result.append('[%s]' % value)
			else: result.append(entry)
	else: #  多元列表
		for entry in list:
			if entry[index] == value: result.append('[%s]' % value)
			else: result.append(entry[index])
	return result

def createUrl(urlInfo):
	url = '%s?' % addon_url
	for key, value in urlInfo.items():
		url += '%s=%s&' % (key, urllib.quote(value.encode('utf-8')))
	url.rstrip('&')
	return url

def arrangeList(originalList):
	newList = []
	for entry in originalList:
		if entry not in newList:
			newList.append(entry)
	return newList

def escapeRegex(originalStr):
	regexStr = '$()*+.[]?\^{}|'
	newStr = ''
	for entry in originalStr:
		if entry in regexStr:
			newStr += '\\'
		newStr += entry
	return newStr

def showRoot():
	# 显示导航
	items = [('冰豆直播', 'group'), ('冰豆影院', 'cate'), ('历史记录', 'history')]
	for entry in items:
		item = xbmcgui.ListItem(entry[0])
		item.setArt({'poster': defaultPic})
		item_url = createUrl({'mode': entry[1]})
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

	# 设置内容
	xbmcplugin.setContent(pHandle, 'files')
	xbmcplugin.endOfDirectory(pHandle)

def showGroup():
	url = 'http://tv.bingdou.net/list.html'
	httpData = getHttpData(url)
	if not httpData: return

	# 显示分组
	regex = re.compile('<h4>(.+?)</h4>', re.DOTALL)
	match = regex.findall(httpData)
	for entry in match:
		label = HTMLParser.HTMLParser().unescape(entry)
		item = xbmcgui.ListItem(label)
		item.setArt({'poster': defaultPic})
		item_url = createUrl({'mode': 'channel', 'group': label})
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

	# 显示自定义频道M3U文件
	dataDir = getDataDir()
	m3uDir = os.path.join(dataDir, 'M3U')
	if os.path.exists(m3uDir):
		m3uList = [entry.decode('utf-8') for entry in os.listdir(m3uDir) if entry.endswith('.m3u')]
		for entry in m3uList:
			label = entry
			item = xbmcgui.ListItem(label.rstrip('.m3u'))
			item.setArt({'poster': defaultPic})
			item_url = createUrl({'mode': 'channel', 'm3u': label})
			xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

	# 设置内容
	xbmcplugin.setContent(pHandle, 'files')
	xbmcplugin.setPluginCategory(pHandle, '冰豆直播')
	xbmcplugin.endOfDirectory(pHandle)

def showChannel():
	pageSize = 100

	# 显示直播频道
	group = params.get('group')
	if group:
		cateStr = group
		change = params.get('change')
		if not change: # 首次进入
			page = 1

		elif change == 'page': # 改变页数
			curPage = int(params.get('curpage'))
			totalPage = int(params.get('totalpage'))
			pageList = []
			if curPage>1: pageList.append('上一页')
			for i in range(1, totalPage+1): pageList.append(str(i))
			if curPage<totalPage: pageList.append('下一页')
			select = xbmcgui.Dialog().select('改变页数', createSelect(pageList, -1, str(curPage)))
			if select == -1 or pageList[select] == str(curPage): return
			if pageList[select] == '上一页': page = curPage-1
			elif pageList[select] == '下一页': page = curPage+1
			else: page = int(pageList[select])

		url = 'http://tv.bingdou.net/list.html'
		httpData = getHttpData(url)
		if not httpData: return

		# 显示视频
		regex = re.compile('<h4>%s</h4>\s*<div class="list-item(?: none)?">(.+?)</div>' % escapeRegex(group), re.DOTALL)
		match = regex.search(httpData)
		if match:
			reg = re.compile('<p><a href="(.+?)" target="iframe-player">(.+?)</a></p>', re.DOTALL)
			mat = reg.findall(match.group(1))
			mat.sort(key=lambda x: x[1])
			videoList = mat[(page-1)*pageSize: min(page*pageSize, len(mat))]
			for entry in videoList:
				video_url = entry[0]
				label = HTMLParser.HTMLParser().unescape(entry[1])
				poster = getPoster(entry[0])

				item = xbmcgui.ListItem(label)
				item.setArt({'poster': poster})
				item_url = createUrl({'mode': 'play', 'url': video_url, 'label': label})
				xbmcplugin.addDirectoryItem(pHandle, item_url, item, False)

			# 显示页数
			totalPage = int((len(mat)+pageSize-1)/pageSize)
			if totalPage>1:
				item = xbmcgui.ListItem('[COLOR yellow][B]页数：[/B]第%d页[/COLOR]' % page)
				item.setArt({'poster': defaultPic})
				item_url = createUrl({'mode': 'channel', 'change': 'page', 'curpage': str(page), 'totalpage': str(totalPage), 'group': group})
				xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

				cateStr += ' 第%d页' % page

	# 显示自定义频道
	m3u = params.get('m3u')
	if m3u:
		cateStr = m3u.rstrip('.m3u')
		change = params.get('change')
		if not change: # 首次进入
			page = 1

		elif change == 'page': # 改变页数
			curPage = int(params.get('curpage'))
			totalPage = int(params.get('totalpage'))
			pageList = []
			if curPage>1: pageList.append('上一页')
			for i in range(1, totalPage+1): pageList.append(str(i))
			if curPage<totalPage: pageList.append('下一页')
			select = xbmcgui.Dialog().select('改变页数', createSelect(pageList, -1, str(curPage)))
			if select == -1 or pageList[select] == str(curPage): return
			if pageList[select] == '上一页': page = curPage-1
			elif pageList[select] == '下一页': page = curPage+1
			else: page = int(pageList[select])

		dataDir = getDataDir()
		m3uFile = os.path.join(dataDir, 'M3U', m3u)
		if not os.path.exists(m3uFile):
			xbmcgui.Dialog().ok(__addonname__, '文件错误 %s' % m3uFile)
			return

		fHandle = open(m3uFile, 'r')
		m3uData = fHandle.read()
		fHandle.close()

		# 显示视频
		regex = re.compile('#EXTINF:.*?,(.*?)$', re.MULTILINE)
		match = regex.findall(m3uData)
		channelList = arrangeList(match)
		videoList = channelList[(page-1)*pageSize: min(page*pageSize, len(channelList))]
		for entry in videoList:
			video_url = m3uFile
			label = entry
			poster = getPoster(m3uFile)

			item = xbmcgui.ListItem(label)
			item.setArt({'poster': poster})
			item_url = createUrl({'mode': 'play', 'url': video_url, 'label': label})
			xbmcplugin.addDirectoryItem(pHandle, item_url, item, False)

		# 显示页数
		totalPage = int((len(channelList)+pageSize-1)/pageSize)
		if totalPage>1:
			item = xbmcgui.ListItem('[COLOR yellow][B]页数：[/B]第%d页[/COLOR]' % page)
			item.setArt({'poster': defaultPic})
			item_url = createUrl({'mode': 'channel', 'change': 'page', 'curpage': str(page), 'totalpage': str(totalPage), 'm3u': m3u})
			xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

			cateStr += ' 第%d页' % page

	# 设置内容
	xbmcplugin.setContent(pHandle, 'videos')
	xbmc.executebuiltin('container.SetViewMode(500)')
	xbmcplugin.setPluginCategory(pHandle, cateStr)
	xbmcplugin.endOfDirectory(pHandle)

def showCate():
	url = 'http://v.bingdou.net/'
	httpData = getHttpData(url)
	if not httpData: return

	# 显示分类
	regex = re.compile('<a class="HotKey" target="_self" href="(.+?)">(.+?)</a>', re.DOTALL)
	match = regex.findall(httpData)
	for entry in match:
		cate_url = entry[0]
		label = HTMLParser.HTMLParser().unescape(entry[1])
		item = xbmcgui.ListItem(label)
		item.setArt({'poster': defaultPic})
		item_url = createUrl({'mode': 'list', 'url': cate_url, 'cate': label})
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

	# 显示搜索
	item = xbmcgui.ListItem('搜索')
	item.setArt({'poster': defaultPic})
	item_url = createUrl({'mode': 'search'})
	xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

	# 设置内容
	xbmcplugin.setContent(pHandle, 'files')
	xbmcplugin.setPluginCategory(pHandle, '冰豆影院')
	xbmcplugin.endOfDirectory(pHandle)

def showSearch():
	key = xbmcgui.Dialog().input('输入关键词')
	if not key: return

	data = {'wd': key}
	url = 'http://v.bingdou.net/search/'
	httpData = postHttpData(url, data)
	if not httpData: return

	# 显示视频
	regex = re.compile("<a class='yun-link' href='(\.\./play/\?play=/(?:m|tv|va|ct)/[0-9a-zA-Z]+\.html)' title='(.+?)' target='_blank'>\s*<div class='img'>\s*<img src='(.+?)' alt='.*?' />.*?<i class='bgbbg'>(.*?)</i>\s*<p class='name'>(.*?)</p>\s*<p class='other'>(.*?)</p>.*?<p class='actor'>(.*?)</p>", re.DOTALL)
	match = regex.findall(httpData)
	for entry in match:
		series_url = entry[0]
		label = HTMLParser.HTMLParser().unescape(entry[1])
		poster = entry[2]

		infoLabels = {}
		infoLabels['plot'] = ''
		if entry[3]: infoLabels['plot'] += entry[3] + '\n'
		if entry[4]: infoLabels['plot'] += entry[4] + '\n'
		if entry[5]: infoLabels['plot'] += entry[5] + '\n'
		if entry[6]: infoLabels['plot'] += entry[6] + '\n'

		item = xbmcgui.ListItem(label)
		item.setArt({'poster': poster})
		item.setInfo('video', infoLabels)
		item_url = createUrl({'mode': 'series', 'url': series_url, 'title': label})
		item.addContextMenuItems([('解析方式…', 'RunPlugin(%s)' % createUrl({'mode': 'play', 'url': series_url, 'label': label, 'type': 'series'}))])
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

	# 设置内容 及 视图
	xbmcplugin.setContent(pHandle, 'movies')
	xbmc.executebuiltin('container.SetViewMode(%d)' % viewSetting)
	xbmcplugin.setPluginCategory(pHandle, key)
	xbmcplugin.endOfDirectory(pHandle)

def showList():
	url = params.get('url')
	cate = params.get('cate')
	change = params.get('change')
	if not change: # 首次进入
		url = 'http://v.bingdou.net/' + url + '?m=list.php?cat=all&pageno=1'
		genre = '全部'

	else: # 非首次进入
		httpData = getHttpData(url)
		if not httpData: return

		if change == 'genre': # 改变类别
			curGenre = params.get('curgenre')
			regex = re.compile("<a href='(\?[mu]=list.php\?[^']+)' target='_self'>(.+?)\n?</a>", re.DOTALL)
			match = regex.findall(httpData)
			select = xbmcgui.Dialog().select('改变类别', createSelect(match, 1, curGenre))
			if select == -1 or match[select][1] == curGenre: return
			url = url[:url.index('?')] + match[select][0]
			genre = match[select][1]

		elif change == 'page': # 改变页数
			curPage = params.get('curpage')
			regex = re.compile("<div monitor-desc='分页' id='js-ew-page' data-block='js-ew-page'  class='ew-page'>(.+?)</div>", re.DOTALL)
			match = regex.search(httpData)
			reg = re.compile("<a(.+?)target='_self'.*?>(.+?)</a>", re.DOTALL)
			mat = reg.findall(match.group(1))
			pageList = []
			for entry in mat:
				if entry[1] == '&lt;': pageList.append('上一页')
				elif entry[1] == '&gt': pageList.append('下一页')
				else: pageList.append(entry[1])
			select = xbmcgui.Dialog().select('改变页数', createSelect(pageList, -1, curPage))
			if select == -1 or mat[select][1] == curPage: return
			url = url[:url.index('?')] + mat[select][0][mat[select][0].index('?'):]
			genre = params.get('curgenre')

	httpData = getHttpData(url)
	if not httpData: return

	# 显示类别
	item = xbmcgui.ListItem('[COLOR yellow][B]类别：[/B]%s[/COLOR]' % genre)
	item.setArt({'poster': defaultPic})
	item_url = createUrl({'mode': 'list', 'change': 'genre', 'curgenre': genre, 'url': url, 'cate': cate})
	xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

	# 显示视频
	regex = re.compile("<a class='yun-link' href='(\.\./play/\?play=/(?:m|tv|va|ct)/[0-9a-zA-Z]+\.html)' title='(.+?)' target='_blank'>\s*<div class='img'>\s*<img class='lazy' data-original='(.+?)' src='//cdn\.qianqi\.net/bingdoumovie/images/noimage.gif' alt='.*?' />.*?<i class='bgbbg'>(.*?)</i>\s*<p class='name'>(.*?)</p>\s*<p class='other'>(.*?)</p>.*?<p class='actor'>(.*?)</p>", re.DOTALL)
	match = regex.findall(httpData)
	for entry in match:
		series_url = entry[0]
		label = HTMLParser.HTMLParser().unescape(entry[1])
		poster = entry[2]

		infoLabels = {}
		infoLabels['plot'] = ''
		if entry[3]: infoLabels['plot'] += entry[3] + '\n'
		if entry[4]: infoLabels['plot'] += entry[4] + '\n'
		if entry[5]: infoLabels['plot'] += entry[5] + '\n'
		if entry[6]: infoLabels['plot'] += entry[6] + '\n'

		item = xbmcgui.ListItem(label)
		item.setArt({'poster': poster})
		item.setInfo('video', infoLabels)
		item_url = createUrl({'mode': 'series', 'url': series_url, 'title': label})
		item.addContextMenuItems([('解析方式…', 'RunPlugin(%s)' % createUrl({'mode': 'play', 'url': series_url, 'label': label, 'type': 'series'}))])
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

	# 显示页数
	pageStr = ''
	regex = re.compile("<a target='_self' class='on'>(\d+)</a>", re.DOTALL)
	match = regex.search(httpData)
	if match:
		page = match.group(1)
		item = xbmcgui.ListItem('[COLOR yellow][B]页数：[/B]第%s页[/COLOR]' % page)
		item.setArt({'poster': defaultPic})
		item_url = createUrl({'mode': 'list', 'change': 'page', 'curpage': page, 'curgenre': genre, 'url': url, 'cate': cate})
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

		pageStr = ' 第%s页' % page

	# 设置内容 及 视图
	xbmcplugin.setContent(pHandle, 'movies')
	xbmc.executebuiltin('container.SetViewMode(%d)' % viewSetting)
	xbmcplugin.setPluginCategory(pHandle, cate+pageStr)
	xbmcplugin.endOfDirectory(pHandle)

def showSeries():
	url = params.get('url')
	title = params.get('title')

	if not url.startswith('http'): url = 'http://v.bingdou.net/' + url[3:]
	httpData = getHttpData(url)
	if not httpData: return

	infoLabels = {}
	infoLabels['plot'] = ''
	regex = re.compile('<div id="box-jqjieshao"><!--(.*?) -->(.*?)</div>', re.DOTALL)
	match = regex.search(httpData)
	if match:
		if match.group(1): infoLabels['plot'] += match.group(1) + '\n'
		if match.group(2): infoLabels['plot'] += '简介 ：' + match.group(2) + '\n'

	pageSize = 100
	regex = re.compile("<li(?: class=\"current\")?><span class=[\"']f[\"']>&nbsp(.+?)&nbsp</span></li>", re.DOTALL)
	match = regex.findall(httpData)
	if match: # 有来源标签页
		change = params.get('change')
		if not change: # 首次进入
			source = match[0]
			page = 1

		elif change == 'source': # 改变来源
			curSource = params.get('cursource')
			select = xbmcgui.Dialog().select('改变来源', createSelect(match, -1, curSource))
			if select == -1 or match[select] == curSource: return
			source = match[select]
			page = 1

		elif change == 'page': # 改变页数
			curPage = int(params.get('curpage'))
			totalPage = int(params.get('totalpage'))
			pageList = []
			if curPage>1: pageList.append('上一页')
			for i in range(1, totalPage+1): pageList.append(str(i))
			if curPage<totalPage: pageList.append('下一页')
			select = xbmcgui.Dialog().select('改变页数', createSelect(pageList, -1, str(curPage)))
			if select == -1 or pageList[select] == str(curPage): return
			if pageList[select] == '上一页': page = curPage-1
			elif pageList[select] == '下一页': page = curPage+1
			else: page = int(pageList[select])
			source = params.get('cursource')

		# 显示来源
		if len(match)>1:
			item = xbmcgui.ListItem('[COLOR yellow][B]来源：[/B]%s[/COLOR]' % source)
			item.setArt({'poster': defaultPic})
			item_url = createUrl({'mode': 'series', 'change': 'source', 'cursource': source, 'url': url, 'title': title})
			xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

		# 显示视频
		reg = re.compile('<div class="num-tab-main g-clear js-tab"(?: style="display:block;")?>(\s*<a id="\d+" data-daochu="to=%s".*?)</div>' % escapeRegex(source), re.DOTALL)
		mat = reg.search(httpData)

		regi = re.compile('<a id="(\d+)" data-daochu="to=%s" href="(.+?)">' % escapeRegex(source), re.DOTALL)
		mati = regi.findall(mat.group(1))
		videoList = mati[(page-1)*pageSize: min(page*pageSize, len(mati))]
		for entry in videoList:
			video_url = entry[1]
			label = '%s 第%s集' % (title, entry[0])
			poster = getPoster(entry[1])

			item = xbmcgui.ListItem(label)
			item.setArt({'poster': poster})
			item.setInfo('video', infoLabels)
			item_url = createUrl({'mode': 'play', 'url': video_url, 'label': label, 'type': 'video'})
			item.addContextMenuItems([('解析方式…', 'RunPlugin(%s)' % createUrl({'mode': 'play', 'url': video_url, 'label': label, 'type': 'video', 'manual': 'true'}))])
			xbmcplugin.addDirectoryItem(pHandle, item_url, item, False)

		# 显示页数
		pageStr = ''
		totalPage = int((len(mati)+pageSize-1)/pageSize)
		if totalPage>1:
			item = xbmcgui.ListItem('[COLOR yellow][B]页数：[/B]第%d页[/COLOR]' % page)
			item.setArt({'poster': defaultPic})
			item_url = createUrl({'mode': 'series', 'change': 'page', 'curpage': str(page), 'totalpage': str(totalPage), 'cursource': source, 'url': url, 'title': title})
			xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

			pageStr = ' 第%d页' % page

	else: # 无来源标签页
		change = params.get('change')
		if not change: # 首次进入
			page = 1

		elif change == 'page': # 改变页数
			curPage = int(params.get('curpage'))
			totalPage = int(params.get('totalpage'))
			pageList = []
			if curPage>1: pageList.append('上一页')
			for i in range(1, totalPage+1): pageList.append(str(i))
			if curPage<totalPage: pageList.append('下一页')
			select = xbmcgui.Dialog().select('改变页数', createSelect(pageList, -1, str(curPage)))
			if select == -1 or pageList[select] == str(curPage): return
			if pageList[select] == '上一页': page = curPage-1
			elif pageList[select] == '下一页': page = curPage+1
			else: page = int(pageList[select])

		# 显示视频
		reg = re.compile("<li><a href='(.+?)' title='(.+?)' target='ajax'>\\2</a></li>", re.DOTALL)
		mat = reg.findall(httpData)
		if mat:
			if mat.count(mat[-1])>1:
				i = mat.index(mat[-1])
				if i == 10: mat = mat[11:]

			if mat.count(mat[0])>1:
				i = mat.index(mat[0], 1)
				mat = mat[i:]

		videoList = mat[(page-1)*pageSize: min(page*pageSize, len(mat))]
		for entry in videoList:
			video_url = entry[0]
			label = '%s %s' % (title, HTMLParser.HTMLParser().unescape(entry[1]))
			poster = getPoster(entry[0])

			item = xbmcgui.ListItem(label)
			item.setArt({'poster': poster})
			item.setInfo('video', infoLabels)
			item_url = createUrl({'mode': 'play', 'url': video_url, 'label': label, 'type': 'video'})
			item.addContextMenuItems([('解析方式…', 'RunPlugin(%s)' % createUrl({'mode': 'play', 'url': video_url, 'label': label, 'type': 'video', 'manual': 'true'}))])
			xbmcplugin.addDirectoryItem(pHandle, item_url, item, False)

		# 显示页数
		pageStr = ''
		totalPage = int((len(mat)+pageSize-1)/pageSize)
		if totalPage>1:
			item = xbmcgui.ListItem('[COLOR yellow][B]页数：[/B]第%d页[/COLOR]' % page)
			item.setArt({'poster': defaultPic})
			item_url = createUrl({'mode': 'series', 'change': 'page', 'curpage': str(page), 'totalpage': str(totalPage), 'url': url, 'title': title})
			xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

			pageStr = ' 第%d页' % page

	# 设置内容 及 视图
	xbmcplugin.setContent(pHandle, 'videos')
	xbmc.executebuiltin('container.SetViewMode(%d)' % viewSetting)
	xbmcplugin.setPluginCategory(pHandle, title+pageStr)
	xbmcplugin.endOfDirectory(pHandle)

def showHistory():
	# 读取历史记录
	dataDir = getDataDir()
	filePath = os.path.join(dataDir, 'history.log')
	historyList = []
	if os.path.exists(filePath):
		fHandle = open(filePath, 'r')
		try:
			historyList = simplejson.load(fHandle)
		except simplejson.scanner.JSONDecodeError, e:
			xbmcgui.Dialog().ok(__addonname__, '历史记录为空或格式有误 %s' % str(e))
			pass
		fHandle.close()

	pageSize = 100
	totalPage = int((len(historyList)+pageSize-1)/pageSize)

	change = params.get('change')
	if change == None:  # 首次进入
		page = 1

	elif change == 'page': # 改变页数
		curPage = int(params.get('curpage'))
		pageList = []
		if curPage>1: pageList.append('上一页')
		for i in range(1, totalPage+1): pageList.append(str(i))
		if curPage<totalPage: pageList.append('下一页')
		select = xbmcgui.Dialog().select('改变页数', createSelect(pageList, -1, str(curPage)))
		if select == -1 or pageList[select] == str(curPage): return
		if pageList[select] == '上一页': page = curPage-1
		elif pageList[select] == '下一页': page = curPage+1
		else: page = int(pageList[select])

	elif change == 'refresh': # 刷新列表
		page = int(params.get('curpage'))

	# 显示视频
	videoList = historyList[(page-1)*pageSize: min(page*pageSize, len(historyList))]
	for i, entry in enumerate(videoList):
		video_url = entry['url']
		label = HTMLParser.HTMLParser().unescape(entry['label'])
		poster = getPoster(entry['url'])

		item = xbmcgui.ListItem(label)
		item.setArt({'poster': poster})

		type = entry.get('type')
		menuItems = [('删除单条记录', 'RunPlugin(%s)' % createUrl({'mode': 'delete', 'index': str(i+(page-1)*pageSize), 'curpage': str(page-int(len(videoList)==1 and totalPage!=1))}))]
		if type == 'series':
			isFolder = True
			item_url = createUrl({'mode': 'series', 'url': video_url, 'title': label})
			menuItems.append(('解析方式…', 'RunPlugin(%s)' % createUrl({'mode': 'play', 'url': video_url, 'label': label, 'type': 'series'})))
		elif type == 'video':
			isFolder = False
			item_url = createUrl({'mode': 'play', 'url': video_url, 'label': label, 'type': 'video'})
			menuItems.append(('解析方式…', 'RunPlugin(%s)' % createUrl({'mode': 'play', 'url': video_url, 'label': label, 'type': 'video', 'manual': 'true'})))
		else:
			isFolder = False
			item_url = createUrl({'mode': 'play', 'url': video_url, 'label': label})

		item.addContextMenuItems(menuItems)
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, isFolder)

	# 显示页数
	pageStr = ''
	if totalPage>1:
		item = xbmcgui.ListItem('[COLOR yellow][B]页数：[/B]第%d页[/COLOR]' % page)
		item.setArt({'poster': defaultPic})
		item_url = createUrl({'mode': 'history', 'change': 'page', 'curpage': str(page)})
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

		pageStr = ' 第%d页' % page

	# 设置内容 及 视图
	xbmcplugin.setContent(pHandle, 'videos')
	xbmc.executebuiltin('container.SetViewMode(500)')
	xbmcplugin.setPluginCategory(pHandle, '历史记录'+pageStr)
	xbmcplugin.endOfDirectory(pHandle)

def playVideo():
	url = params.get('url')
	label = params.get('label')
	type = params.get('type')

	# 获取视频播放信息
	if url.startswith('../play/?play='): # 影院专辑
		interfaceList = getInterface(url)
		try:
			select = xbmcgui.Dialog().contextmenu(interfaceList)
		except AttributeError:
			select = xbmcgui.Dialog().select(label, interfaceList)
		if select == -1: return # 取消

		if interfaceList[select] == '采集接口': from lib.zuidazy import getVideo

		xbmcgui.Dialog().notification(label, '正在调用 [%s] 解析视频' % interfaceList[select])
		video = getVideo(url, label)

	elif url.startswith('http'): # 影院单集
		interfaceList = getInterface(url)
		manual = params.get('manual')
		if manual: # 手动
			try:
				select = xbmcgui.Dialog().contextmenu(interfaceList)
			except AttributeError:
				select = xbmcgui.Dialog().select(label, interfaceList)
			if select == -1: return # 取消

			if interfaceList[select] == '通用接口': from lib.bingdou import getVideo
			elif interfaceList[select] == '专用接口(qiyi)': from lib.qiyi import getVideo

			xbmcgui.Dialog().notification(label, '正在调用 [%s] 解析视频' % interfaceList[select])
			video = getVideo(url, label)

		else: # 自动
			pDialog = xbmcgui.DialogProgress()
			pDialog.create(label)
			for i, interface in enumerate(interfaceList):
				pDialog.update(100*(i+1)/len(interfaceList), '(%d/%d) 正在调用 [%s] 解析视频' % (i+1, len(interfaceList), interface))

				if interface == '通用接口': from lib.bingdou import getVideo
				elif interface == '专用接口(qiyi)': from lib.qiyi import getVideo
				video = getVideo(url, label)

				if pDialog.iscanceled(): return # 取消
				if i<len(interfaceList)-1: # 非最后一个
					if video[0] == -1: return # 取消
					elif video[0] == 0: continue # 失败
					else: break # 成功
			pDialog.close()

	else: # 直播
		from lib.tv import getVideo
		video = getVideo(url, label)

	if video[0] == -1: return # 取消
	elif video[0] == 0: # 失败
		xbmcgui.Dialog().ok(__addonname__, video[1])
		return
	else: # 成功
		m3u = video[1]
		item = xbmcgui.ListItem(label)
		xbmc.Player().play(m3u, item) # 播放视频
		saveHistory({'url': url, 'label': label, 'type': type}) # 保存历史

# 主程序
addon_url = sys.argv[0]
if sys.argv[1] == 'clear': mode = 'clear'
elif sys.argv[1] == 'manage': mode = 'manage'
else:
	pHandle = int(sys.argv[1])
	params = dict(urlparse.parse_qsl(sys.argv[2][1:]))
	mode = params.get('mode')

defaultPic = os.path.join(getAddonDir(), 'media', 'default.png')

viewtype = __addon__.getSetting('viewtype')
if viewtype == '0': viewSetting = 54 # 信息墙
elif viewtype == '1': viewSetting = 500 # 海报墙
elif viewtype == '2': viewSetting = 55 # 宽列表

# 导航
if mode == None:
	showRoot()

# 分组
elif mode == 'group':
	showGroup()

# 频道
elif mode == 'channel':
	showChannel()

# 分类
elif mode == 'cate':
	showCate()

# 搜索
elif mode == 'search':
	showSearch()

# 列表
elif mode == 'list':
	showList()

# 专辑
elif mode == "series":
	showSeries()

# 历史
elif mode == 'history':
	showHistory()

# 播放
elif mode == 'play':
	playVideo()

# 删除单条记录
elif mode == 'delete':
	deleteHistory()

# 清除历史记录
elif mode == 'clear':
	clearHistory()

# 管理自定义频道
elif mode == 'manage':
	manageChannel()