﻿# -*- coding: utf-8 -*-
# bingdou解析 (1.0)

import xbmc
import urllib2, urllib, re, os, zlib, base64, simplejson

# 函数
def getHttpData(url, referer=None):
	request = urllib2.Request(url)
	request.add_header('User-Agent', 'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0)')
	if referer: request.add_header('Referer', referer)

	maxtimes = 10
	for t in range(maxtimes):
		try:
			response = urllib2.urlopen(request)
			httpData = response.read()
			break
		except Exception, e:
			if '11004' in str(e):
				if t<maxtimes-1: continue
			return

	if response.headers.get('content-encoding', None) == 'gzip':
		httpData = zlib.decompress(httpData, zlib.MAX_WBITS|32)

	response.close()
	return httpData

def postHttpData(url, data, referer=None):
	request = urllib2.Request(url, urllib.urlencode(data))
	request.add_header('User-Agent', 'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0)')
	if referer: request.add_header('Referer', referer)

	maxtimes = 10
	for t in range(maxtimes):
		try:
			response = urllib2.urlopen(request)
			httpData = response.read()
			break
		except Exception, e:
			if '11004' in str(e):
				if t<maxtimes-1: continue
			return

	if response.headers.get('content-encoding', None) == 'gzip':
		httpData = zlib.decompress(httpData, zlib.MAX_WBITS|32)

	response.close()
	return httpData

def getVideo(videoUrl, videoLabel):
	prefixUrl = 'https://api.bingdou.net/jiexi/'
	url = prefixUrl + '?url=' + videoUrl
	httpData = getHttpData(url)
	if not httpData: return (0, '网络错误 %s' % url)

	regex = re.compile('\$\.post\("(.+?)",({.+?})', re.DOTALL)
	match = regex.search(httpData)
	url = prefixUrl + match.group(1)
	data = simplejson.loads(match.group(2).replace("'ref':form,", "'ref':'0',").replace("'other':y.encode(other_l),", "'other':'%s'," % base64.b64encode(videoUrl)).replace("'", '"'))
	httpData = postHttpData(url, data)
	if not httpData: return (0, '网络错误 %s' % url)

	playInfo = simplejson.loads(httpData)
	if playInfo['code'] in ['404', '500']: return (0, '无法解析 %s' % url)

	elif playInfo['type'] == 'xml':
		url = playInfo['url']
		httpData = getHttpData(url)
		if not httpData: return (0, '网络错误 %s' % url)

		regex = re.compile('<file>.*?<!\[CDATA\[(.+?)\]\]>.*?</file>.*?<seconds>(.+?)</seconds>', re.DOTALL)
		match = regex.findall(httpData)

		cacheDir = xbmc.translatePath('special://temp/interface/')
		if not os.path.exists(cacheDir): os.makedirs(cacheDir)
		cacheFile = os.path.join(cacheDir, 'index.m3u8')
		fHandle = open(cacheFile, 'w')
		fHandle.write('#EXTM3U\n#EXT-X-TARGETDURATION:%d\n' % max([float(entry[1]) for entry in match]))
		for entry in match:
			fHandle.write('#EXTINF:%d,\n%s\n' % (float(entry[1]), entry[0]))
		fHandle.write('#EXT-X-ENDLIST')
		fHandle.close()

		m3u = cacheFile

	elif playInfo['url'].startswith('http'): m3u = playInfo['url']
	elif playInfo['url'].startswith('//'): m3u = 'http:' + playInfo['url']
	elif playInfo['url'].startswith('AINX'):
		from utils import Base64
		url = Base64.decode(playInfo['url'].replace('AINX', ''))
		if playInfo.get('play') != 'iqiyi':
			if url.startswith('http'): m3u = url
			elif url.startswith('//'): m3u = 'http:' + url
			elif url.startswith('player'): m3u = prefixUrl + url
			else: return (0, '无法解析 %s\nm3u: %s' % (url, playInfo['url']))
		else: return (0, '无法解析 %s\nm3u: %s' % (url, playInfo['url']))
	else: return (0, '无法解析 %s\nm3u: %s' % (url, playInfo['url']))

	return (1, m3u)