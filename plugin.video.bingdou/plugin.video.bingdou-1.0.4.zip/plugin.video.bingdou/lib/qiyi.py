﻿# -*- coding: utf-8 -*-
# qiyi解析 (1.0)

import xbmcgui
import urllib2, urllib, re, os, zlib, hashlib, time, base64, simplejson

# 函数
def getHttpData(url, referer=None):
	request = urllib2.Request(url)
	request.add_header('User-Agent', 'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0)')
	if referer: request.add_header('Referer', referer)

	maxtimes = 10
	for t in range(maxtimes):
		try:
			response = urllib2.urlopen(request)
			httpData = response.read()
			break
		except Exception, e:
			if '11004' in str(e):
				if t<maxtimes-1: continue
			return

	if response.headers.get('content-encoding', None) == 'gzip':
		httpData = zlib.decompress(httpData, zlib.MAX_WBITS|32)

	response.close()
	return httpData

def sort_key(s):
	value = int(s[0].split('x')[0])
	if ' ' in s[0]: value -= 1
	return value

def getVideo(videoUrl, videoLabel):
	url = videoUrl
	httpData = getHttpData(url)
	if not httpData: return (0, '网络错误 %s' % url)

	regex = re.compile('<head itemprop="video"', re.DOTALL)
	match = regex.search(httpData)
	if not match:
		reg = re.compile('<div class="cms-qipuId" data-qipuId="(.+?)"', re.DOTALL)
		mat = reg.search(httpData)
		if not mat: return (0, '无法获取视频信息 %s' % url)

		url = 'http://www.iqiyi.com/v_%s.html' % mat.group(1)
		httpData = getHttpData(url)
		if not httpData: return (0, '网络错误 %s' % url)

	regex = re.compile('data-player-tvid="(.+?)" data-player-videoid="(.+?)"', re.DOTALL)
	match = regex.search(httpData)
	if not match: return (0, '无法获取视频信息 %s' % url)

	tvid = match.group(1)
	videoid = match.group(2)
	t = int(time.time() * 1000)
	src = '76f90cbd92f94a2e925d83e8ccd22cb7'
	key = 'd5fb4bd9d50c4be6948c97edd7254b0e'
	sc = hashlib.md5(str(t)+key+videoid).hexdigest()

	cache_url = 'http://cache.m.iqiyi.com/tmts/{0}/{1}/?t={2}&sc={3}&src={4}'.format(tvid,videoid,t,sc,src)
	httpData = getHttpData(cache_url)
	if not httpData: return (0, '网络错误 %s' % url)

	playInfo = simplejson.loads(httpData.replace('\n', '').replace('\r', '').replace('　', ''))
	if playInfo['code'] != 'A00000': return (0, '当前视频无法播放 %s' % playInfo['code'])

	VRList = []
	videoLink = playInfo['data']['vidl']
	for i, entry in enumerate(videoLink):
		screenSize = entry.get('screenSize')
		fileFormat = entry.get('fileFormat')
		if not fileFormat: VRList.append([screenSize, i])
		else: VRList.append([screenSize+' '+fileFormat, i])

	VRList.sort(key=sort_key, reverse=True)
	selectList = [entry[0] for entry in VRList]
	select = xbmcgui.Dialog().select(videoLabel, selectList)
	if select == -1: return (-1, '取消选择 %s' % url)
	index = VRList[select][1]
	m3u = videoLink[index]['m3u']

	return (1, m3u)