﻿# -*- coding: utf-8 -*-
# zuidazy采集 (1.1)

import xbmcgui
import urllib2, urllib, re, zlib

# 函数
def getHttpData(url, referer=None):
	request = urllib2.Request(url)
	request.add_header('User-Agent', 'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0)')
	if referer != None: request.add_header('Referer', referer)

	maxtimes = 10
	for t in range(maxtimes):
		try:
			response = urllib2.urlopen(request)
			httpData = response.read()
			break
		except Exception, e:
			if '11004' in str(e):
				if t<maxtimes-1: continue
			return

	if response.headers.get('content-encoding', None) == 'gzip':
		httpData = zlib.decompress(httpData, zlib.MAX_WBITS|32)

	response.close()
	return httpData

def postHttpData(url, data, referer=None):
	request = urllib2.Request(url, urllib.urlencode(data))
	request.add_header('User-Agent', 'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0)')
	if referer: request.add_header('Referer', referer)

	maxtimes = 10
	for t in range(maxtimes):
		try:
			response = urllib2.urlopen(request)
			httpData = response.read()
			break
		except Exception, e:
			if '11004' in str(e):
				if t<maxtimes-1: continue
			return

	if response.headers.get('content-encoding', None) == 'gzip':
		httpData = zlib.decompress(httpData, zlib.MAX_WBITS|32)

	response.close()
	return httpData

def getList(videoLabel):
	referer = 'http://zuidazy.net'
	url = 'http://zuidazy.net/index.php?m=vod-search'
	data = {'wd': videoLabel, 'submit': 'search'}
	for i in range(10):
		httpData = postHttpData(url, data, referer)
		if not httpData: return

		regex = re.compile('搜索&nbsp;<span class="">(.+?)</span>&nbsp;的结果共')
		match = regex.search(httpData)
		if not match or not match.group(1):
			if i < 10: continue
			else: return
		else: break

	regex = re.compile('<span class="xing_vb4"><a href="(/\?m=vod-detail-id-\d+\.html)" target="_blank">(.+?)<span>(.*?)</span></a></span> <span class="xing_vb5">(.+?)</span>')
	match = regex.findall(httpData)
	return match

def getSeries(seriesUrl):
	url = 'http://zuidazy.net' + seriesUrl
	httpData = getHttpData(url)
	if not httpData: return

	regex = re.compile('checked="" />(.+?\$https?://.+?\.m3u8)</li>')
	match = regex.findall(httpData)
	if not match:
		regex = re.compile('checked="" />(.+?\$https?://.+?/share/.+?)</li>')
		match = regex.findall(httpData)
	return match

def getVideo(videoUrl, videoLabel):
	while True:
		list = getList(videoLabel)
		if list == None: return (0, '网络错误 %s' % videoUrl)
		elif len(list) == 0:
			videoLabel = xbmcgui.Dialog().input('重新输入标题', videoLabel)
			if not videoLabel: return (-1, '取消输入 %s' % videoLabel)
			else: continue
		break

	while True:
		seriesTitles = ['%s%s [%s]' % (entry[1], entry[2], entry[3]) for entry in list]
		if len(list) == 1: select_series = 0
		else:
			select_series = xbmcgui.Dialog().select(videoLabel, seriesTitles)
			if select_series == -1: return (-1, '取消选择 %s' % videoUrl)

		seriesUrl = list[select_series][0]
		series = getSeries(seriesUrl)
		if series == None: return (0, '网络错误 %s' % videoUrl)

		if len(series) == 1: select_video = 0
		else:
			select_video = xbmcgui.Dialog().select(seriesTitles[select_series], series)
			if select_video == -1:
				if len(list) == 1: return (-1, '取消选择 %s' % videoUrl)
				else: continue
		break

	url = series[select_video].split('$')[1]
	if url.endswith('m3u8'): m3u = url
	else:
		httpData = getHttpData(url)
		if not httpData: return (0, '网络错误 %s' % url)

		regex = re.compile('var main = "(.+?)";')
		match = regex.search(httpData)
		if not match: return (0, '无法获取视频链接 %s' % url)

		m3u = url.split('/share/')[0] + match.group(1)

	return (1, m3u)