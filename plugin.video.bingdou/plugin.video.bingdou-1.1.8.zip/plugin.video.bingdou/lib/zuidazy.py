﻿# -*- coding: utf-8 -*-
import xbmcgui
import urllib2, urllib, re, zlib

# 常数
interfaceName    = 'zuidazy采集'
interfaceVersion = '1.4'
interfaceUrl     = 'http://zuidazy1.net'

# 函数
def logData(data, filePath='C:\Users\Administrator\Desktop\%s.txt' % interfaceName):
	filePath = filePath.decode('utf-8')
	fHandle = open(filePath, 'w')
	fHandle.write(data)
	fHandle.close()

def dialog(str, type='ok'):
	if type == 'ok': xbmcgui.Dialog().ok(interfaceName, str)
	elif type == 'textviewer': xbmcgui.Dialog().textviewer(interfaceName, str)

def getHttpData(url, referer=None):
	request = urllib2.Request(url)
	request.add_header('User-Agent', 'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0)')
	if referer: request.add_header('Referer', referer)

	maxtimes = 10
	for t in range(maxtimes):
		try:
			response = urllib2.urlopen(request)
			httpData = response.read()
			break
		except Exception, e:
			if '11004' in str(e):
				if t<maxtimes-1: continue
			return

	if response.headers.get('content-encoding', None) == 'gzip':
		httpData = zlib.decompress(httpData, zlib.MAX_WBITS|32)

	response.close()
	return httpData

def postHttpData(url, data, referer=None):
	request = urllib2.Request(url, urllib.urlencode(data))
	request.add_header('User-Agent', 'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0)')
	if referer: request.add_header('Referer', referer)

	maxtimes = 10
	for t in range(maxtimes):
		try:
			response = urllib2.urlopen(request)
			httpData = response.read()
			break
		except Exception, e:
			if '11004' in str(e):
				if t<maxtimes-1: continue
			return

	if response.headers.get('content-encoding', None) == 'gzip':
		httpData = zlib.decompress(httpData, zlib.MAX_WBITS|32)

	response.close()
	return httpData

def getList(videoLabel):
	referer = interfaceUrl
	url = interfaceUrl + '/index.php?m=vod-search'
	data = {'wd': videoLabel, 'submit': 'search'}
	for i in range(10):
		httpData = postHttpData(url, data, referer)
		if not httpData: return

		regex = re.compile('搜索&nbsp;<span class="">(.+?)</span>&nbsp;的结果共')
		match = regex.search(httpData)
		if not match or not match.group(1):
			if i < 9: continue
			else: return
		else: break

	regex = re.compile('<span class="xing_vb4"><a href="(/\?m=vod-detail-id-\d+\.html)" target="_blank">(.+?)<span>(.*?)</span></a></span> <span class="xing_vb5">(.+?)</span>')
	match = regex.findall(httpData)
	return match

def getSeries(seriesUrl):
	referer = interfaceUrl
	url = interfaceUrl + seriesUrl
	httpData = getHttpData(url, referer)
	if not httpData: return

	regex = re.compile('checked="" />(.+?\$https?://.+?\.m3u8)</li>')
	match = regex.findall(httpData)
	if not match:
		regex = re.compile('checked="" />(.+?\$https?://.+?/share/.+?)</li>')
		match = regex.findall(httpData)
	return match

def getUrl(url):
	httpData = getHttpData(url)
	if not httpData: return

	regex = re.compile('var main = "(.+?)";')
	match = regex.search(httpData)
	if not match: return

	m3u = url.split('/share/')[0] + match.group(1)
	return m3u

def getVideo(videoUrl, videoLabel):
	while True:
		list = getList(videoLabel)
		if list == None: return (0, '网络错误 %s' % videoUrl)
		elif len(list) == 0:
			videoLabel = xbmcgui.Dialog().input('重新输入标题', videoLabel)
			if not videoLabel: return (-1, '取消输入 %s' % videoLabel)
			else: continue
		break

	preselect = -1
	while True:
		seriesTitles = ['%s%s [%s]' % (entry[1], entry[2], entry[3]) for entry in list]
		if len(list) == 1: select_series = 0
		else:
			select_series = xbmcgui.Dialog().select(videoLabel, seriesTitles, preselect=preselect)
			if select_series == -1: return (-1, '取消选择 %s' % videoUrl)

		preselect = select_series
		seriesUrl = list[select_series][0]
		series = getSeries(seriesUrl)
		if series == None: return (0, '网络错误 %s' % videoUrl)

		if len(series) == 1: select_video = 0
		else:
			select_video = xbmcgui.Dialog().select(seriesTitles[select_series], series)
			if select_video == -1:
				if len(list) == 1: return (-1, '取消选择 %s' % videoUrl)
				else: continue
		break

	url = series[select_video].split('$')[1]
	if url.endswith('m3u8'): m3u = url
	else:
		m3u = getUrl(url)
		if not m3u: return (0, '无法获取视频链接 %s' % url)

	return (1, m3u)