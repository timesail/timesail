﻿# -*- coding: utf-8 -*-
import xbmc, xbmcgui
import urllib2, urllib, re, os, zlib, hashlib, simplejson, HTMLParser

# 常数
interfaceName    = 'i607p解析'
interfaceVersion = '1.2'
interfaceUrl     = 'https://607p.com'

# 函数
def logData(data, filePath='C:\Users\Administrator\Desktop\%s.txt' % interfaceName):
	filePath = filePath.decode('utf-8')
	fHandle = open(filePath, 'w')
	fHandle.write(data)
	fHandle.close()

def dialog(str, type='ok'):
	if type == 'ok': xbmcgui.Dialog().ok(interfaceName, str)
	elif type == 'textviewer': xbmcgui.Dialog().textviewer(interfaceName, str)

def getHttpData(url, referer=None):
	request = urllib2.Request(url)
	request.add_header('User-Agent', 'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0)')
	if referer: request.add_header('Referer', referer)

	maxtimes = 10
	for t in range(maxtimes):
		try:
			response = urllib2.urlopen(request)
			httpData = response.read()
			break
		except Exception, e:
			if '11004' in str(e):
				if t<maxtimes-1: continue
			return

	if response.headers.get('content-encoding', None) == 'gzip':
		httpData = zlib.decompress(httpData, zlib.MAX_WBITS|32)

	response.close()
	return httpData

def postHttpData(url, data, referer=None):
	request = urllib2.Request(url, urllib.urlencode(data))
	request.add_header('User-Agent', 'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0)')
	if referer: request.add_header('Referer', referer)

	maxtimes = 10
	for t in range(maxtimes):
		try:
			response = urllib2.urlopen(request)
			httpData = response.read()
			break
		except Exception, e:
			if '11004' in str(e):
				if t<maxtimes-1: continue
			return

	if response.headers.get('content-encoding', None) == 'gzip':
		httpData = zlib.decompress(httpData, zlib.MAX_WBITS|32)

	response.close()
	return httpData

def sign(str):
	abc = hashlib.md5(str+chr(33)+chr(97)+chr(98)+chr(101)+chr(102)+chr(57)+chr(56)+chr(55)).hexdigest()
	_a = abc[10:22]
	_b = abc[24:30]
	return 'ab59' + _b + '8ab5d6' + _a + 'loij'

def getVideo(videoUrl, videoLabel=None, sorttype=None):
	prefixUrl = interfaceUrl
	url = prefixUrl + '/?url=' + videoUrl
	httpData = getHttpData(url)
	if not httpData: return (0, '网络错误 %s' % url)

	if '<title>607免费解析</title>' in httpData:
		regex = re.compile('(?<!//)url = "(.+?)"\+url;', re.DOTALL)
		match = regex.search(httpData)
		if not match: return (0, '无法解析 %s' % url)

		prefixUrl = match.group(1).strip('/?url=')
		url = prefixUrl + '/?url=' + videoUrl
		httpData = getHttpData(url)
		if not httpData: return (0, '网络错误 %s' % url)

	regex = re.compile('src="(.+?)"></iframe>', re.DOTALL)
	match = regex.search(httpData)
	if not match: return (0, '无法解析 %s' % url)

	src = match.group(1)
	if src.startswith('https://zuikzy.yc370.com'):
		httpData = getHttpData(src)
		if not httpData: return (0, '网络错误 %s' % src)

		regex = re.compile("url: '(.+?)'", re.DOTALL)
		match = regex.search(httpData)
		url = match.group(1)
		m3u = 'https://zuikzy.yc370.com' + url

	elif src.startswith('/m3u8.php') or src.startswith('/m3u8-dp.php'):
		m3u = src.split('url=')[1]

	elif src.startswith('/md/'):
		url = prefixUrl + src
		httpData = getHttpData(url, prefixUrl)
		if not httpData: return (0, '网络错误 %s' % src)

		regex = re.compile('eval\("(.+?)"\)', re.DOTALL)
		match = regex.search(httpData)
		hdMd5 = match.group(1).decode('string-escape')[17:-3]

		regex = re.compile('var WWW_URL=\'(.+?)\'.*?\$\.post\("(.+?)", ({.+?})', re.DOTALL)
		match = regex.search(httpData)
		url = match.group(1) + match.group(2)
		data = simplejson.loads(match.group(3).replace("sign($('#hdMd5').val())", "'%s'" % sign(hdMd5)).replace("$('#hdMd5').val()", "'%s'" % hdMd5).replace(',"iqiyicip":iqiyicip', '').replace("'", '"'))
		httpData = postHttpData(url, data, prefixUrl)
		if not httpData: return (0, '网络错误 %s' % src)

		playInfo = simplejson.loads(httpData)
		if playInfo.get('ext') == 'mp4':
			m3u = urllib.unquote_plus(playInfo['url'])

		elif playInfo.get('ext') in ['m3u8', 'm3u8_list', 'm3u8_list_youku', 'm3u8_list_iqiyi']:
			m3u = urllib.unquote_plus(playInfo['url'])

		elif playInfo.get('ext') == 'xml':
			url = urllib.unquote_plus(playInfo['url'])
			httpData = getHttpData(url)

			regex = re.compile('{f-&gt;(.+?)\[\$pat\]}{a-&gt;(.+?)}{defa-&gt;(.+?)}{deft-&gt;(.+?)}', re.DOTALL)
			match = regex.search(httpData)
			if match:
				CurXML = match.group(2)
				XMList = match.group(3).split('|')
				VRList = match.group(4).split('|')
				if len(VRList) > 1:
					select = xbmcgui.Dialog().select('选择清晰度', VRList)
					if select == -1: return (-1, '取消选择')
					if XMList[select] != CurXML:
						url = match.group(1) + HTMLParser.HTMLParser().unescape(XMList[select])
						httpData = getHttpData(url)

			regex = re.compile('<file>.*?<!\[CDATA\[(.+?)\]\]>.*?</file>.*?<seconds>(.+?)</seconds>', re.DOTALL)
			match = regex.findall(httpData)

			cacheDir = xbmc.translatePath('special://temp/interface/').decode('utf-8')
			if not os.path.exists(cacheDir): os.makedirs(cacheDir)
			cacheFile = os.path.join(cacheDir, 'index.m3u8')
			fHandle = open(cacheFile, 'w')
			fHandle.write('#EXTM3U\n#EXT-X-TARGETDURATION:%d\n' % max([float(entry[1]) for entry in match]))
			for entry in match:
				fHandle.write('#EXTINF:%d,\n%s\n' % (float(entry[1]), entry[0]))
			fHandle.write('#EXT-X-ENDLIST')
			fHandle.close()

			m3u = cacheFile

		else: return (0, '无法解析 %s' % src)
	else: return (0, '无法解析 %s' % src)

	return (1, m3u)