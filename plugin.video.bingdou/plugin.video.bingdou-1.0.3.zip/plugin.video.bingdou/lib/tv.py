﻿# -*- coding: utf-8 -*-
# tv解析 (1.0)

import xbmcgui
import urllib2, re, os, zlib

# 函数
def getHttpData(url, referer=None):
	request = urllib2.Request(url)
	request.add_header('User-Agent', 'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0)')
	if referer: request.add_header('Referer', referer)

	maxtimes = 10
	for t in range(maxtimes):
		try:
			response = urllib2.urlopen(request)
			httpData = response.read()
			break
		except Exception, e:
			if '11004' in str(e):
				if t<maxtimes-1: continue
			return

	if response.headers.get('content-encoding', None) == 'gzip':
		httpData = zlib.decompress(httpData, zlib.MAX_WBITS|32)

	response.close()
	return httpData

def arrangeList(originalList):
	newList = []
	for entry in originalList:
		if entry not in newList:
			newList.append(entry)
	return newList

def escapeRegex(originalStr):
	regexStr = '$()*+.[]?\^{}|'
	newStr = ''
	for entry in originalStr:
		if entry in regexStr:
			newStr += '\\'
		newStr += entry
	return newStr

def getVideo(videoUrl, videoLabel):
	url = videoUrl
	if url.endswith('.m3u'):
		if not os.path.exists(url): return (0, '文件错误 %s' % url)
		fHandle = open(url, 'r')
		m3uData = fHandle.read()
		fHandle.close()

		regex = re.compile('#EXTINF:.*?,%s\n(.*?)$' % escapeRegex(videoLabel), re.MULTILINE)
		match = regex.findall(m3uData)
		sourceList = arrangeList(match)
		if len(sourceList) == 0: return (0, '文件错误 %s' % url)
		elif len(sourceList) == 1: select = 0
		else:
			select = xbmcgui.Dialog().select(videoLabel, ['源%d' % (i+1) for i in range(len(sourceList))])
			if select == -1: return (-1, '取消选择 %s' % url)

		m3u = sourceList[select]

	elif url.endswith('.m3u8'):
		m3u = url[28:]

	else:
		url = 'http:' + url
		httpData = getHttpData(url)
		if not httpData: return (0, '网络错误 %s' % url)

		regex = re.compile("<a href=(//m\.tv\.bingdou\.net/e/DownSys/DownSoft/\?classid=\d+&id=\d+&pathid=\d+)><i class='icon-play-circle'></i><cite>(.+?)</cite></a>", re.DOTALL)
		match = regex.findall(httpData)
		if len(match)>1:
			select = xbmcgui.Dialog().select(videoLabel, [entry[1] for entry in match])
			if select == -1: return (-1, '取消选择 %s' % url)
			url = match[select][0]

			url = 'http:' + url
			httpData = getHttpData(url)
			if not httpData: return (0, '网络错误 %s' % url)

		regex = re.compile('iframe src="//m\.tv\.bingdou\.net/player/\?url=(.+?)"', re.DOTALL)
		match = regex.search(httpData)
		if not match: return (0, '无法获取视频信息 %s' % url)

		from utils import Base64
		m3u = Base64.decode(match.group(1))
		if m3u.startswith('.'): m3u = m3u.lstrip('.')

	return (1, m3u)