﻿# -*- coding: utf-8 -*-
# zuidazy采集 (1.0)

import xbmcgui
import urllib2, urllib, re, zlib

# 函数
def getHttpData(url, referer=None):
	request = urllib2.Request(url)
	request.add_header('User-Agent', 'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0)')
	if referer != None: request.add_header('Referer', referer)

	maxtimes = 10
	for t in range(maxtimes):
		try:
			response = urllib2.urlopen(request)
			httpData = response.read()
			break
		except Exception, e:
			if '11004' in str(e):
				if t<maxtimes-1: continue
			return

	if response.headers.get('content-encoding', None) == 'gzip':
		httpData = zlib.decompress(httpData, zlib.MAX_WBITS|32)

	response.close()
	return httpData

def postHttpData(url, data, referer=None):
	request = urllib2.Request(url, urllib.urlencode(data))
	request.add_header('User-Agent', 'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0)')
	if referer: request.add_header('Referer', referer)

	maxtimes = 10
	for t in range(maxtimes):
		try:
			response = urllib2.urlopen(request)
			httpData = response.read()
			break
		except Exception, e:
			if '11004' in str(e):
				if t<maxtimes-1: continue
			return

	if response.headers.get('content-encoding', None) == 'gzip':
		httpData = zlib.decompress(httpData, zlib.MAX_WBITS|32)

	response.close()
	return httpData

def getPlayInfo(key):
	referer = 'http://zuidazy.net'
	url = 'http://zuidazy.net/index.php?m=vod-search'
	data = {'wd': key, 'submit': 'search'}
	for i in range(10):
		httpData = postHttpData(url, data, referer)
		if not httpData: return

		regex = re.compile('搜索&nbsp;<span class="">(.+?)</span>&nbsp;的结果共')
		match = regex.search(httpData)
		if not match or not match.group(1):
			if i < 10: continue
			else: return
		else: break

	playInfo = {'title': key, 'info': []}
	regex = re.compile('<span class="xing_vb4"><a href="(/\?m=vod-detail-id-\d+\.html)" target="_blank">(.+?)</a></span> <span class="xing_vb5">(.+?)</span>')
	match = regex.findall(httpData)
	for entry in match:
		url = 'http://zuidazy.net' + entry[0]
		httpData = getHttpData(url)
		if not httpData: return

		reg = re.compile('checked="" />(.+?\$https?://.+?\.m3u8)</li>')
		mat = reg.findall(httpData)
		if not mat:
			reg = re.compile('checked="" />(.+?\$https?://.+?/share/.+?)</li>')
			mat = reg.findall(httpData)
			if not mat: continue

		playInfo['info'].append({'name': '%s [%s]' % (re.sub('</?span>', '', entry[1]), entry[2]), 'video': mat[:]})

	return playInfo

def getVideo(videoUrl, videoLabel):
	url = videoUrl
	key = videoLabel
	while True:
		playInfo = getPlayInfo(key)
		if not playInfo: return (0, '网络错误 %s' % url)

		if not playInfo['info']:
			key = xbmcgui.Dialog().input('重新输入标题', key)
			if not key: return (-1, '取消输入 %s' % url)
			else: continue
		else: break

	while True:
		nameList = [entry['name'] for entry in playInfo['info']]
		if len(nameList) == 1: select_name = 0
		else:
			select_name = xbmcgui.Dialog().select(playInfo['title'], nameList)
			if select_name == -1: return (-1, '取消选择 %s' % url)

		videoList = [entry for entry in playInfo['info'][select_name]['video']]
		if len(videoList) == 1:
			select_video = 0
			break
		else:
			select_video = xbmcgui.Dialog().select(playInfo['info'][select_name]['name'], videoList)
			if select_video == -1:
				if len(nameList) == 1: return (-1, '取消选择 %s' % url)
				else: continue
			else: break

	url = playInfo['info'][select_name]['video'][select_video].split('$')[1]
	if url.endswith('m3u8'): m3u = url
	else:
		httpData = getHttpData(url)
		if not httpData: return (0, '网络错误 %s' % url)

		regex = re.compile('var main = "(.+?)";')
		match = regex.search(httpData)
		if not match: return (0, '无法获取视频链接 %s' % url)

		m3u = url.split('/share/')[0] + match.group(1)

	return (1, m3u)