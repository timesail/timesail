﻿# -*- coding: utf-8 -*-
import xbmc, xbmcgui
import urllib2, urllib, re, os, zlib, base64, simplejson

# 常数
interfaceName    = 'bingdou解析'
interfaceVersion = '1.2'
interfaceUrl     = 'https://api.bingdou.net/jiexi/'

# 函数
def logData(data, filePath='C:\Users\Administrator\Desktop\%s.txt' % interfaceName):
	filePath = filePath.decode('utf-8')
	fHandle = open(filePath, 'w')
	fHandle.write(data)
	fHandle.close()

def dialog(str, type='ok'):
	if type == 'ok': xbmcgui.Dialog().ok(interfaceName, str)
	elif type == 'textviewer': xbmcgui.Dialog().textviewer(interfaceName, str)

def getHttpData(url, referer=None):
	request = urllib2.Request(url)
	request.add_header('User-Agent', 'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0)')
	if referer: request.add_header('Referer', referer)

	maxtimes = 10
	for t in range(maxtimes):
		try:
			response = urllib2.urlopen(request)
			httpData = response.read()
			break
		except Exception, e:
			if '11004' in str(e):
				if t<maxtimes-1: continue
			return

	if response.headers.get('content-encoding', None) == 'gzip':
		httpData = zlib.decompress(httpData, zlib.MAX_WBITS|32)

	response.close()
	return httpData

def postHttpData(url, data, referer=None):
	request = urllib2.Request(url, urllib.urlencode(data))
	request.add_header('User-Agent', 'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0)')
	if referer: request.add_header('Referer', referer)

	maxtimes = 10
	for t in range(maxtimes):
		try:
			response = urllib2.urlopen(request)
			httpData = response.read()
			break
		except Exception, e:
			if '11004' in str(e):
				if t<maxtimes-1: continue
			return

	if response.headers.get('content-encoding', None) == 'gzip':
		httpData = zlib.decompress(httpData, zlib.MAX_WBITS|32)

	response.close()
	return httpData

def getVideo(videoUrl, videoLabel):
	prefixUrl = interfaceUrl
	url = prefixUrl + '?url=' + videoUrl
	httpData = getHttpData(url)
	if not httpData: return (0, '网络错误 %s' % url)

	regex = re.compile('\$\.post\("(.+?)",({.+?})', re.DOTALL)
	match = regex.search(httpData)
	url = prefixUrl + match.group(1)
	data = simplejson.loads(match.group(2).replace("'ref':form,", "'ref':'0',").replace("'other':y.encode(other_l),", "'other':'%s'," % base64.b64encode(videoUrl)).replace("'", '"'))
	httpData = postHttpData(url, data)
	if not httpData: return (0, '网络错误 %s' % url)

	playInfo = simplejson.loads(httpData)
	#logData(httpData)
	if playInfo['code'] in ['404', '500']: return (0, '无法解析 %s' % url)
	elif playInfo['url'].startswith('http'): m3u = playInfo['url']
	elif playInfo['url'].startswith('//'): m3u = 'http:' + playInfo['url']
	elif playInfo['url'].startswith('AINX'):
		from utils import Base64
		url = Base64.decode(playInfo['url'].replace('AINX', ''))
		if playInfo.get('play') == 'txvd':
			httpData = getHttpData(url)
			if not httpData: return (0, '网络错误 %s' % url)

			videoInfo = simplejson.loads(simplejson.loads(httpData)['vinfo'])['vl']['vi'][0]
			url = [entry['url'] for entry in videoInfo['ul']['ui'] if entry['url'].startswith('https://apd-')][0]
			fn = videoInfo['fn']
			fvkey = videoInfo['fvkey']
			m3u = url + fn + '?vkey=' + fvkey

		elif playInfo.get('play') == 'iqiyi':
			return (0, '无法解析 %s' % url)

		elif url.startswith('http'): m3u = url
		elif url.startswith('//'): m3u = 'http:' + url
		elif url.startswith('player'): m3u = prefixUrl + url
		else: return (0, '无法解析 %s' % url)
	else: return (0, '无法解析 %s' % url)

	#dialog(m3u, 'textviewer')
	#return(0, 'debug')

	return (1, m3u)