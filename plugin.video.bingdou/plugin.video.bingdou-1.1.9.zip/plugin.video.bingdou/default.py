﻿# -*- coding: utf-8 -*-
import xbmc, xbmcgui, xbmcplugin, xbmcaddon, xbmcvfs
import urllib, urlparse, re, sys, os, HTMLParser
import simplejson

# 编码
if sys.getdefaultencoding() != 'utf-8':
	reload(sys)
	sys.setdefaultencoding('utf-8')

# 常数
__addonname__ = '冰豆视频'
__addonid__   = 'plugin.video.bingdou'
__addon__     = xbmcaddon.Addon(id=__addonid__)

# 函数
def logData(data, filePath='C:\Users\Administrator\Desktop\%s.txt' % __addonname__):
	filePath = filePath.decode('utf-8')
	fHandle = open(filePath, 'w')
	fHandle.write(data)
	fHandle.close()

def dialog(str, type='ok'):
	if type == 'ok': xbmcgui.Dialog().ok(__addonname__, str)
	elif type == 'textviewer': xbmcgui.Dialog().textviewer(__addonname__, str)

def saveHistory(history):
	dataDir = getDataDir()
	filePath = os.path.join(dataDir, 'history.log')
	if not os.path.exists(filePath): # 文件不存在则创建文件
		fHandle = open(filePath, 'w')
		historyList = [history]

	else: # 文件存在则读取文件
		try:
			fHandle = open(filePath, 'r+')
			historyList = simplejson.load(fHandle)
			if history in historyList: historyList.remove(history)
			historyList.insert(0, history)
			fHandle.seek(0, 0)
		except simplejson.scanner.JSONDecodeError: # 文件非json格式则重新创建文件
			fHandle = open(filePath, 'w')
			historyList = [history]
			pass

	simplejson.dump(historyList, fHandle, ensure_ascii=False)
	fHandle.close()

def deleteHistory():
	dataDir = getDataDir()
	filePath = os.path.join(dataDir, 'history.log')
	if os.path.exists(filePath):
		fHandle = open(filePath, 'r+')
		try:
			historyList = simplejson.load(fHandle)
			index = int(params.get('index'))
			if xbmcgui.Dialog().yesno(__addonname__, '确定要删除历史记录 [%s] 吗' % historyList[index]['label']):
				historyList.pop(index)
				fHandle.seek(0, 0)
				fHandle.truncate()
				simplejson.dump(historyList, fHandle, ensure_ascii=False)

				page = params.get('curpage')
				xbmc.executebuiltin('Container.Update(%s,replace)' % createUrl({'mode': 'history', 'change': 'refresh', 'curpage': page}))

		except simplejson.scanner.JSONDecodeError:
			if xbmcgui.Dialog().yesno(__addonname__, '历史记录为空或格式有误，是否清除'):
				os.remove(filePath)
				xbmc.executebuiltin('Container.Update(%s,replace)' % createUrl({'mode': 'history'}))

	else: xbmcgui.Dialog().ok(__addonname__, '历史记录不存在')
	fHandle.close()

def clearHistory():
	dataDir = getDataDir()
	filePath = os.path.join(dataDir, 'history.log')
	if os.path.exists(filePath):
		fHandle = open(filePath, 'r')
		try:
			historyList = simplejson.load(fHandle)
			fHandle.close()
			if xbmcgui.Dialog().yesno(__addonname__, '历史记录共%d条，是否清除' % len(historyList)):
				os.remove(filePath)
				xbmc.executebuiltin('Container.Update(%s,replace)' % createUrl({'mode': 'history'}))

		except simplejson.scanner.JSONDecodeError:
			fHandle.close()
			if xbmcgui.Dialog().yesno(__addonname__, '历史记录为空或格式有误，是否清除'):
				os.remove(filePath)
				xbmc.executebuiltin('Container.Update(%s,replace)' % createUrl({'mode': 'history'}))

	else: xbmcgui.Dialog().ok(__addonname__, '历史记录不存在')

def addChannel():
	m3uFile = xbmcgui.Dialog().browse(1, '选择要添加的自定义频道M3U文件', 'files', '.m3u').decode('utf-8')
	if not m3uFile: return

	dataDir = getDataDir()
	m3uDir = os.path.join(dataDir, 'M3U')
	if not os.path.exists(m3uDir): os.makedirs(m3uDir)

	m3uName = os.path.basename(m3uFile)
	if m3uName in [entry.decode('utf-8') for entry in os.listdir(m3uDir)]:
		copy = xbmcgui.Dialog().yesno(__addonname__, 'M3U文件 [%s] 已存在，是否更新' % m3uName)
		if not copy: return

	xbmcvfs.copy(m3uFile, os.path.join(m3uDir, m3uName))
	xbmcgui.Dialog().ok(__addonname__, '成功添加M3U文件 [%s]' % m3uName)
	xbmc.executebuiltin('Container.Update(%s,replace)' % createUrl({'mode': 'group'}))

def removeChannel():
	m3u = params.get('m3u')

	dataDir = getDataDir()
	m3uFile = os.path.join(dataDir, 'M3U', m3u)
	if not os.path.exists(m3uFile):
		xbmcgui.Dialog().ok(__addonname__, '文件错误 %s' % m3uFile)
		return

	delete = xbmcgui.Dialog().yesno(__addonname__, '确定要删除M3U文件 [%s] 吗' % m3u)
	if not delete: return

	os.remove(m3uFile)
	#xbmcgui.Dialog().ok(__addonname__, '成功删除M3U文件 [%s]' % m3u)
	xbmc.executebuiltin('Container.Update(%s,replace)' % createUrl({'mode': 'group'}))

def getDataDir():
	dataDir = xbmc.translatePath(__addon__.getAddonInfo('profile')).decode('utf-8')
	if not os.path.exists(dataDir): os.makedirs(dataDir)
	return dataDir

def getAddonDir():
	addonDir = xbmc.translatePath(__addon__.getAddonInfo('path')).decode('utf-8')
	return addonDir

def getHttpData(url):
	import urllib2
	request = urllib2.Request(url)
	request.add_header('User-Agent', 'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0)')

	maxtimes = 10
	for t in range(maxtimes):
		try:
			response = urllib2.urlopen(request)
			httpData = response.read()
			break
		except Exception, e:
			if '11004' in str(e):
				if t<maxtimes-1: continue
				else: xbmcgui.Dialog().ok(__addonname__, '网络错误 %s %s %d次' % (url, str(e), maxtimes))
			else: xbmcgui.Dialog().ok(__addonname__, '网络错误 %s %s' % (url, str(e)))
			return

	if response.headers.get('content-encoding', None) == 'gzip':
		import zlib
		httpData = zlib.decompress(httpData, zlib.MAX_WBITS|32)

	response.close()
	return httpData

def postHttpData(url, data):
	import urllib2
	request = urllib2.Request(url, urllib.urlencode(data))
	request.add_header('User-Agent', 'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0)')

	maxtimes = 10
	for t in range(maxtimes):
		try:
			response = urllib2.urlopen(request)
			httpData = response.read()
			break
		except Exception, e:
			if '11004' in str(e):
				if t<maxtimes-1: continue
				else: xbmcgui.Dialog().ok(__addonname__, '网络错误 %s %s %d次' % (url, str(e), maxtimes))
			else: xbmcgui.Dialog().ok(__addonname__, '网络错误 %s %s' % (url, str(e)))
			return

	if response.headers.get('content-encoding', None) == 'gzip':
		import zlib
		httpData = zlib.decompress(httpData, zlib.MAX_WBITS|32)

	response.close()
	return httpData

def getPoster(url):
	poster = os.path.join(getAddonDir(), 'media', 'bingdou.png')
	siteList = [('tv', 'tv'), ('www.iqiyi.com', 'qiyi'), ('m.iqiyi.com', 'qiyi'), ('v.qq.com', 'qq'), ('v.youku.com', 'youku'), ('www.tudou.com', 'tudou'), ('www.mgtv.com', 'mgtv'), ('tv.sohu.com', 'sohu'), ('www.letv.com', 'levp'), ('www.le.com', 'levp'), ('www.1905.com', '1905'), ('vip.1905.com', '1905'), ('vip.m1905.com', '1905'), ('www.m1905.com', '1905'), ('www.fun.tv', 'fengxing'), ('v.pptv.com', 'pptv'), ('www.wasu.cn', 'huashu'), ('tv.cctv.com', 'cntv'), ('www.hanju.cc', 'hanju'), ('v.360kan.com', '360kan'), ('vod.kankan.com', 'kankan')]
	for site in siteList:
		if site[0] in url: poster = os.path.join(getAddonDir(), 'media', '%s.png' % site[1])
	return poster

def createSelect(list, index, value=None):
	result = []
	if index == -1: #  一元列表
		for entry in list:
			if entry == value: result.append('[%s]' % entry)
			else: result.append(entry)
	else: #  多元列表
		for entry in list:
			if entry[index] == value: result.append('[%s]' % entry[index])
			else: result.append(entry[index])
	return result

def createUrl(urlInfo):
	url = '%s?' % addon_url
	for key, value in urlInfo.items():
		url += '%s=%s&' % (key, urllib.quote(value.encode('utf-8')))
	url = url[:-1]
	return url

def arrangeList(originalList):
	newList = []
	for entry in originalList:
		if entry not in newList:
			newList.append(entry)
	return newList

def arrangeVideos(videos):
	if videos.count(videos[-1])>1:
		i = videos.index(videos[-1])
		if i == 10: videos = videos[11:]
	if videos.count(videos[0])>1:
		i = videos.index(videos[0], 1)
		videos = videos[i:]
	return videos

def escapeRegex(originalStr):
	regexStr = '$()*+.[]?\^{}|'
	newStr = ''
	for entry in originalStr:
		if entry in regexStr:
			newStr += '\\'
		newStr += entry
	return newStr

def jsonfy(str):
	obj = eval(str, type('js', (dict,), dict(__getitem__=lambda s, n: n))())
	return obj

def setView(viewid):
	xbmcgui.Dialog().yesno(__addonname__, '强制固定视图，视图代码 [%s]' % viewid, autoclose=1)
	xbmc.executebuiltin('Container.SetViewMode(%s)' % viewid)

def showRoot():
	# 显示导航
	items = [('冰豆直播', 'group'), ('冰豆影院', 'cate'), ('冰豆搜索', 'search'), ('资源采集', 'gather'), ('历史记录', 'history')]
	for entry in items:
		item = xbmcgui.ListItem(entry[0])
		item.setArt({'poster': defaultPic})
		item_url = createUrl({'mode': entry[1]})
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

	# 设置内容
	xbmcplugin.setContent(pHandle, 'files')
	xbmcplugin.endOfDirectory(pHandle)

def showGroup():
	url = 'http://tv.bingdou.net/list.html'
	httpData = getHttpData(url)
	if not httpData: return

	# 显示分组
	regex = re.compile('<h4>(.+?)</h4>', re.DOTALL)
	match = regex.findall(httpData)
	for entry in match:
		label = HTMLParser.HTMLParser().unescape(entry)
		item = xbmcgui.ListItem(label)
		item.setArt({'poster': defaultPic})
		item_url = createUrl({'mode': 'channel', 'group': label})
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

	# 显示自定义频道
	dataDir = getDataDir()
	m3uDir = os.path.join(dataDir, 'M3U')
	if os.path.exists(m3uDir):
		fileList = sorted(os.listdir(m3uDir), key=lambda x: os.path.getmtime(os.path.join(m3uDir, x)))
		m3uList = [entry.decode('utf-8') for entry in fileList if entry.endswith('.m3u')]
		for entry in m3uList:
			label = entry[:-4]
			m3u = entry
			item = xbmcgui.ListItem(label)
			item.setArt({'poster': defaultPic})
			item.addContextMenuItems([('删除自定义频道', 'RunPlugin(%s)' % createUrl({'mode': 'remove', 'm3u': m3u}))])
			item_url = createUrl({'mode': 'channel', 'm3u': m3u, 'group': label})
			xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

	# 添加自定义频道
	item = xbmcgui.ListItem('添加自定义频道')
	item.setArt({'poster': defaultPic})
	item_url = createUrl({'mode': 'add'})
	xbmcplugin.addDirectoryItem(pHandle, item_url, item, False)

	# 设置内容
	xbmcplugin.setContent(pHandle, 'files')
	xbmcplugin.setPluginCategory(pHandle, '冰豆直播')
	xbmcplugin.endOfDirectory(pHandle)

def showChannel():
	pageSize = 100

	m3u = params.get('m3u')
	group = params.get('group')
	if not m3u: # 显示直播频道
		change = params.get('change')
		if not change: # 首次进入
			page = 1

		elif change == 'page': # 改变页数
			curPage = int(params.get('curpage'))
			totalPage = int(params.get('totalpage'))
			pageList = []
			if curPage>1: pageList.append('上一页')
			for i in range(1, totalPage+1): pageList.append(str(i))
			if curPage<totalPage: pageList.append('下一页')
			select = xbmcgui.Dialog().select('改变页数', createSelect(pageList, -1, str(curPage)))
			if select == -1 or pageList[select] == str(curPage): return
			if pageList[select] == '上一页': page = curPage-1
			elif pageList[select] == '下一页': page = curPage+1
			else: page = int(pageList[select])

		url = 'http://tv.bingdou.net/list.html'
		httpData = getHttpData(url)
		if not httpData: return

		# 显示视频
		regex = re.compile('<h4>%s</h4>\s*<div class="list-item(?: none)?">(.+?)</div>' % escapeRegex(group), re.DOTALL)
		match = regex.search(httpData)
		if match:
			reg = re.compile('<p><a href="(.+?)" target="iframe-player">(.+?)</a></p>', re.DOTALL)
			mat = reg.findall(match.group(1))
			mat.sort(key=lambda x: x[1])
			videoList = mat[(page-1)*pageSize: min(page*pageSize, len(mat))]
			for entry in videoList:
				video_url = entry[0]
				label = HTMLParser.HTMLParser().unescape(entry[1])
				poster = getPoster('tv')

				item = xbmcgui.ListItem(label)
				item.setArt({'poster': poster})
				item_url = createUrl({'mode': 'play', 'url': video_url, 'label': label})
				xbmcplugin.addDirectoryItem(pHandle, item_url, item, False)

			# 显示页数
			pageStr = ''
			totalPage = int((len(mat)+pageSize-1)/pageSize)
			if totalPage>1:
				item = xbmcgui.ListItem('[COLOR yellow][B]页数：[/B]第%d页[/COLOR]' % page)
				item.setArt({'poster': defaultPic})
				item_url = createUrl({'mode': 'channel', 'change': 'page', 'curpage': str(page), 'totalpage': str(totalPage), 'group': group})
				xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

				pageStr += ' 第%d页' % page

	else: # 显示自定义频道
		change = params.get('change')
		if not change: # 首次进入
			page = 1

		elif change == 'page': # 改变页数
			curPage = int(params.get('curpage'))
			totalPage = int(params.get('totalpage'))
			pageList = []
			if curPage>1: pageList.append('上一页')
			for i in range(1, totalPage+1): pageList.append(str(i))
			if curPage<totalPage: pageList.append('下一页')
			select = xbmcgui.Dialog().select('改变页数', createSelect(pageList, -1, str(curPage)))
			if select == -1 or pageList[select] == str(curPage): return
			if pageList[select] == '上一页': page = curPage-1
			elif pageList[select] == '下一页': page = curPage+1
			else: page = int(pageList[select])

		dataDir = getDataDir()
		m3uFile = os.path.join(dataDir, 'M3U', m3u)
		if not os.path.exists(m3uFile):
			xbmcgui.Dialog().ok(__addonname__, '文件错误 %s' % m3uFile)
			return

		fHandle = open(m3uFile, 'r')
		m3uData = fHandle.read()
		fHandle.close()

		import chardet
		charset = chardet.detect(m3uData)['encoding']
		if charset != 'utf-8': m3uData = m3uData.decode(charset, 'ignore').encode('utf-8')

		# 显示视频
		regex = re.compile('#EXTINF:.*?,(.*?)\r?$', re.MULTILINE)
		match = regex.findall(m3uData)
		channelList = arrangeList(match)
		videoList = channelList[(page-1)*pageSize: min(page*pageSize, len(channelList))]
		for entry in videoList:
			video_url = m3uFile
			label = entry
			poster = getPoster('tv')

			item = xbmcgui.ListItem(label)
			item.setArt({'poster': poster})
			item_url = createUrl({'mode': 'play', 'url': video_url, 'label': label})
			xbmcplugin.addDirectoryItem(pHandle, item_url, item, False)

		# 显示页数
		pageStr = ''
		totalPage = int((len(channelList)+pageSize-1)/pageSize)
		if totalPage>1:
			item = xbmcgui.ListItem('[COLOR yellow][B]页数：[/B]第%d页[/COLOR]' % page)
			item.setArt({'poster': defaultPic})
			item_url = createUrl({'mode': 'channel', 'change': 'page', 'curpage': str(page), 'totalpage': str(totalPage), 'm3u': m3u})
			xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

			pageStr += ' 第%d页' % page

	# 设置内容
	xbmcplugin.setContent(pHandle, 'videos')
	xbmcplugin.setPluginCategory(pHandle, group+pageStr)
	xbmcplugin.endOfDirectory(pHandle)

	# 设置视图
	forceview = __addon__.getSetting('forceview')
	if forceview == 'true': setView('500')

def showCate():
	# 显示分类
	cateList = [('电视剧', 'https://www.360kan.com/dianshi/list'),
                ('电影', 'https://www.360kan.com/dianying/list'),
                ('综艺', 'https://www.360kan.com/zongyi/list'),
                ('动漫', 'https://www.360kan.com/dongman/list')]
	for entry in cateList:
		cate_url = entry[1]
		label = entry[0]
		item = xbmcgui.ListItem(label)
		item.setArt({'poster': defaultPic})
		item_url = createUrl({'mode': 'list', 'url': cate_url, 'cate': label})
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

	# 设置内容
	xbmcplugin.setContent(pHandle, 'files')
	xbmcplugin.setPluginCategory(pHandle, '冰豆影院')
	xbmcplugin.endOfDirectory(pHandle)

def showList():
	cate = params.get('cate')
	change = params.get('change')
	if not change: # 首次进入
		url = params.get('url')
	else: # 非首次进入
		if change == 'subcate': # 改变子分类
			subCateInfo = simplejson.loads(params.get('subcateinfo'))
			subCateTitle = subCateInfo['name']
			subCateValue = subCateInfo['active']
			subCateList = subCateInfo['list']
			select = xbmcgui.Dialog().select('改变%s' % subCateTitle, createSelect(subCateList, 1, subCateValue))
			if select == -1 or subCateList[select][0] == '': return
			url = subCateList[select][0]

		elif change == 'tab': # 改变类别
			tabInfo = simplejson.loads(params.get('tabinfo'))
			curTab = tabInfo['active']
			tabList = tabInfo['list']
			select = xbmcgui.Dialog().select('改变类别', createSelect(tabList, 1, curTab))
			if select == -1 or tabList[select][1] == curTab: return
			url = tabList[select][0]

		elif change == 'page': # 改变页数
			pageInfo = simplejson.loads(params.get('pageinfo'))
			curPage = pageInfo['active']
			pageList = pageInfo['list']
			select = xbmcgui.Dialog().select('改变页数', createSelect(pageList, 1, curPage))
			if select == -1 or pageList[select][0] == '': return
			url = pageList[select][0]

	httpData = getHttpData(url)
	if not httpData: return

	# 显示子分类
	subCates = []
	regex = re.compile('<dl class="s-filter-item js-s-filter">\s*<dt class="type">(.+?):</dt>\s*<dd class="item g-clear js-filter-content">(.+?)</dd>', re.DOTALL)
	match = regex.findall(httpData)
	for entry in match:
		subCateInfo = {}
		subCateInfo['name'] = entry[0]

		reg = re.compile('<b class="on">(.+?)</b>', re.DOTALL)
		mat = reg.search(entry[1])
		subCateInfo['active'] = mat.group(1)

		subCateInfo['list'] = []
		reg = re.compile('<[ab](.+?)>(.+?)\s*(?:<i class="s-hot-icon"></i>\s*)?</[ab]>', re.DOTALL)
		mat = reg.findall(entry[1])
		for ent in mat:
			regi = re.compile('href="([^"]+)"', re.DOTALL)
			mati = regi.search(ent[0])
			if mati: subCateInfo['list'].append((mati.group(1), ent[1]))
			else: subCateInfo['list'].append(('', ent[1]))

		subCates.append(subCateInfo)

	for entry in subCates:
		item = xbmcgui.ListItem('[COLOR yellow][B]%s：[/B]%s[/COLOR]' % (entry['name'], entry['active']))
		item.setArt({'poster': defaultPic})
		item_url = createUrl({'mode': 'list', 'change': 'subcate', 'subcateinfo': simplejson.dumps(entry), 'cate': cate})
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

	# 显示类别
	regex = re.compile('<a target="_self" href="javascript:;">(.+?)</a>', re.DOTALL)
	match = regex.search(httpData)
	if match:
		tabInfo = {}
		tabInfo['active'] = match.group(1)

		reg = re.compile('<a (?:class="js-tongjip" )?target="_self" href="([^"]+)">(.+?)</a>', re.DOTALL)
		mat = reg.findall(httpData)
		tabInfo['list'] = mat[:]

		item = xbmcgui.ListItem('[COLOR yellow][B]类别：[/B]%s[/COLOR]' % tabInfo['active'])
		item.setArt({'poster': defaultPic})
		item_url = createUrl({'mode': 'list', 'change': 'tab', 'tabinfo': simplejson.dumps(tabInfo), 'cate': cate})
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

	# 显示视频
	regex = re.compile('<a class="js-tongjic" href="([^"]+)">.*?<img src="([^"]+)">(.*?)<span class="hint">(.+?)</span>(.*?)<span class="s1">(.+?)</span>(.*?)</div>', re.DOTALL)
	match = regex.findall(httpData)
	for entry in match:
		series_url = entry[0]
		poster = entry[1]
		label = HTMLParser.HTMLParser().unescape(entry[5])
		if '<span class="pay">付费</span>' in entry[2]: label2 = '[COLOR red]%s[/COLOR]' % label
		else: label2 = label

		infoLabels = {'plot': ''}
		if entry[3]:
			if entry[0].startswith('/m/'): infoLabels['plot'] += '年代：' + entry[3] + '\n' # 电影
			else: infoLabels['plot'] += '集数：' + entry[3] + '\n' # 电视剧 / 综艺 / 动漫

		reg = re.compile('<span class="point">(.+?)</span>', re.DOTALL)
		mat = reg.search(entry[4])
		if mat: infoLabels['plot'] += '评分：' + mat.group(1) + '\n'

		reg = re.compile('<p class="star">(.+?)</p>', re.DOTALL)
		mat = reg.search(entry[6])
		if mat: infoLabels['plot'] += mat.group(1) + '\n'

		item = xbmcgui.ListItem(label2)
		item.setArt({'poster': poster})
		item.setInfo('video', infoLabels)
		item_url = createUrl({'mode': 'series', 'url': series_url, 'title': label})
		item.addContextMenuItems([('采集方式…', 'RunPlugin(%s)' % createUrl({'mode': 'play', 'url': series_url, 'label': label, 'type': 'series'}))])
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

	# 显示页数
	pageStr = ''
	regex = re.compile("<div monitor-desc='分页' id='js-ew-page' data-block='js-ew-page'  class='ew-page'>(.+?)</div>", re.DOTALL)
	match = regex.search(httpData)
	if match:
		pageInfo = {}
		reg = re.compile("<a target='_self' class='on'>(\d+)</a>", re.DOTALL)
		mat = reg.search(match.group(1))
		pageInfo['active'] = mat.group(1)

		pageInfo['list'] = []
		reg = re.compile("<a(.+?)target='_self'.*?>(.+?)</a>", re.DOTALL)
		mat = reg.findall(match.group(1))
		for entry in mat:
			pageIndex = entry[1].lstrip('&lt;').rstrip('&gt;')

			regi = re.compile("href='([^']+)'", re.DOTALL)
			mati = regi.search(entry[0])
			if mati: pageInfo['list'].append((mati.group(1), pageIndex))
			else: pageInfo['list'].append(('', pageIndex))

		item = xbmcgui.ListItem('[COLOR yellow][B]页数：[/B]第%s页[/COLOR]' % pageInfo['active'])
		item.setArt({'poster': defaultPic})
		item_url = createUrl({'mode': 'list', 'change': 'page', 'pageinfo': simplejson.dumps(pageInfo), 'cate': cate})
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

		pageStr = ' 第%s页' % pageInfo['active']

	# 设置内容
	xbmcplugin.setContent(pHandle, 'movies')
	xbmcplugin.setPluginCategory(pHandle, cate+pageStr)
	xbmcplugin.endOfDirectory(pHandle)

	# 设置视图
	forceview = __addon__.getSetting('forceview')
	if forceview == 'true':
		viewid = __addon__.getSetting('viewid')
		setView(viewid)

def showSeries():
	url = params.get('url')
	title = params.get('title')

	if not url.startswith('http'): url = 'https://www.360kan.com' + url
	httpData = getHttpData(url)
	if not httpData: return

	# 获取信息
	infoLabels = {'plot': ''}
	regex = re.compile('<p class="item(?: item42)?"><span(?: class="cat-title")?>类型 ：</span>(.+?)</p>', re.DOTALL)
	match = regex.search(httpData)
	if match:
		reg = re.compile('<(?:a|span) class="cat(?: first)?"(?: href="[^"]*" target="_blank")?>(.+?)</(?:a|span)>', re.DOTALL)
		mat = reg.findall(match.group(1))
		if mat: infoLabels['plot'] += '类型：' + ' / '.join(mat) + '\n'

	regex = re.compile('<p class="item(?: item41)?"><span>年代 ：</span>(\d{4})</p>', re.DOTALL)
	match = regex.search(httpData)
	if match: infoLabels['plot'] += '年代：' + match.group(1) + '\n'

	regex = re.compile('<p class="item(?: item41)?"><span>地区 ：</span>(.+?)</p>', re.DOTALL)
	match = regex.search(httpData)
	if match:
		reg = re.compile('<(?:a|span) class="area(?: first)?"(?: href="[^"]*" target="_blank")?>(.+?)</(?:a|span)>', re.DOTALL)
		mat = reg.findall(match.group(1))
		if mat: infoLabels['plot'] += '地区：' + ' / '.join(mat) + '\n'
		else: infoLabels['plot'] += '地区：' + match.group(1) + '\n'

	regex = re.compile('<p class="item(?: item41)?"><span>播出 ：</span>(.+?)</p>', re.DOTALL)
	match = regex.search(httpData)
	if match: infoLabels['plot'] += '播出：' + match.group(1) + '\n'

	regex = re.compile('<p class="item(?: item-director)?">\s*<span>导演 ：</span>(.+?)</p>', re.DOTALL)
	match = regex.search(httpData)
	if match:
		reg = re.compile('<(?:a|span) class="name"(?: href="[^"]*")?>(.+?)</(?:a|span)>', re.DOTALL)
		mat = reg.findall(match.group(1))
		if mat: infoLabels['plot'] += '导演：' + ' / '.join(mat) + '\n'

	regex = re.compile('<p class="item(?: item-actor)?">\s*<span>演员 ：</span>(.+?)</p>', re.DOTALL)
	match = regex.search(httpData)
	if match:
		reg = re.compile('<(?:a|span) class="name"(?: href="[^"]*")?>(.+?)</(?:a|span)>', re.DOTALL)
		mat = reg.findall(match.group(1))
		if mat: infoLabels['plot'] += '演员：' + ' / '.join(mat) + '\n'

	regex = re.compile('<p class="item item44 item-actor">.*?<span>明星 ：</span>(.+?)</p>', re.DOTALL)
	match = regex.search(httpData)
	if match:
		reg = re.compile('<(?:a|span) class="name"(?: href="[^"]*")?>(.+?)</(?:a|span)>', re.DOTALL)
		mat = reg.findall(match.group(1))
		if mat: infoLabels['plot'] += '明星：' + ' / '.join(mat) + '\n'

	regex = re.compile('<div class="item-desc-wrap g-clear js-close-wrap" style="display:none;"><span>简介 ：</span><p class="item-desc">(.+?)<a href="#" class="js-close btn">(?:&lt;&lt;收起|收起&lt;&lt;)</a></p></div>', re.DOTALL)
	match = regex.search(httpData)
	if match: infoLabels['plot'] += '简介：' + match.group(1).replace('\n', '').replace('\r', '').replace('　', '') + '\n'

	pageSize = 100
	regex = re.compile('<script>\s*var serverdata ?= ?({.+?});\s*</script>', re.DOTALL)
	match = regex.search(httpData)
	serverInfo = jsonfy(match.group(1).decode('unicode_escape'))
	if serverInfo['playtype'] in ['tv', 'comics']: # 电视剧 / 动漫
		change = params.get('change')
		if not change: # 首次进入
			source = serverInfo['playsite'][0]['cnsite']
			site = serverInfo['playsite'][0]['ensite']
			page = 1

		else: # 非首次进入
			if change == 'source': # 改变来源
				curSource = params.get('cursource')
				sourceList = [entry['cnsite'] for entry in serverInfo['playsite']]
				select = xbmcgui.Dialog().select('改变来源', createSelect(sourceList, -1, curSource))
				if select == -1 or sourceList[select] == curSource: return
				source = serverInfo['playsite'][select]['cnsite']
				site = serverInfo['playsite'][select]['ensite']
				page = 1

			elif change == 'page': # 改变页数
				curPage = int(params.get('curpage'))
				totalPage = int(params.get('totalpage'))
				pageList = []
				if curPage>1: pageList.append('上一页')
				for i in range(1, totalPage+1): pageList.append(str(i))
				if curPage<totalPage: pageList.append('下一页')
				select = xbmcgui.Dialog().select('改变页数', createSelect(pageList, -1, str(curPage)))
				if select == -1 or pageList[select] == str(curPage): return
				if pageList[select] == '上一页': page = curPage-1
				elif pageList[select] == '下一页': page = curPage+1
				else: page = int(pageList[select])
				source = params.get('source')
				site = params.get('site')

		# 显示来源
		if len(serverInfo['playsite'])>1:
			item = xbmcgui.ListItem('[COLOR yellow][B]来源：[/B]%s[/COLOR]' % source)
			item.setArt({'poster': defaultPic})
			item_url = createUrl({'mode': 'series', 'change': 'source', 'cursource': source, 'url': url, 'title': title})
			xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

		# 显示视频
		switch_url = 'https://www.360kan.com/cover/switchsitev2?site=%s&id=%s&category=%s' % (site, serverInfo['id'], serverInfo['cat'])
		httpData = getHttpData(switch_url)
		if not httpData: return

		reg = re.compile('<a data-num=\\\\"(\d+)\\\\" ?data-daochu=\\\\"to=%s\\\\" href=\\\\"([^"]+)\\\\">(.*?)<\\\\/a>' % escapeRegex(site), re.DOTALL)
		mat = reg.findall(httpData)
		if mat:
			mat = arrangeVideos(mat)
			sorttype = __addon__.getSetting('sorttype')
			if sorttype == '1': mat.reverse()
		videoList = mat[(page-1)*pageSize: min(page*pageSize, len(mat))]
		for entry in videoList:
			video_url = entry[1].replace(r'\/', '/')
			poster = getPoster(entry[1])
			label = '%s 第%s集' % (title, entry[0])
			if r'<i class=\"ico-pay\"><\/i>' in entry[2]: label2 = '[COLOR red]%s[/COLOR]' % label
			else: label2 = label

			item = xbmcgui.ListItem(label2)
			item.setArt({'poster': poster})
			item.setInfo('video', infoLabels)
			item_url = createUrl({'mode': 'play', 'url': video_url, 'label': label, 'type': 'video'})
			item.addContextMenuItems([('解析方式…', 'RunPlugin(%s)' % createUrl({'mode': 'play', 'url': video_url, 'label': label, 'type': 'video', 'manual': 'true'}))])
			xbmcplugin.addDirectoryItem(pHandle, item_url, item, False)

		# 显示页数
		pageStr = ''
		totalPage = int((len(mat)+pageSize-1)/pageSize)
		if totalPage>1:
			item = xbmcgui.ListItem('[COLOR yellow][B]页数：[/B]第%d页[/COLOR]' % page)
			item.setArt({'poster': defaultPic})
			item_url = createUrl({'mode': 'series', 'change': 'page', 'curpage': str(page), 'totalpage': str(totalPage), 'source': source, 'site': site, 'url': url, 'title': title})
			xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

			pageStr = ' 第%d页' % page

	elif serverInfo['playtype'] == 'arts': # 综艺
		reg = re.compile('class="js-juji-site ea-site zd-down-item ea-site-([^"]+)" href="####">(.+?)</a>', re.DOTALL)
		mat = reg.findall(httpData)
		if not mat: # 单一来源
			reg = re.compile(' <span class="ea-site ea-site-([^"]+) btn">(.+?)</span>', re.DOTALL)
			mat = reg.findall(httpData)
		serverInfo['playsite'] = [{'ensite': entry[0], 'cnsite': entry[1]} for entry in mat]
		change = params.get('change')
		if not change: # 首次进入
			source = serverInfo['playsite'][0]['cnsite']
			site = serverInfo['playsite'][0]['ensite']
			yearList = []
			year = ''
			do = 'switchsite'
			page = 1

		else: # 非首次进入
			if change == 'source': # 改变来源
				curSource = params.get('cursource')
				sourceList = [entry['cnsite'] for entry in serverInfo['playsite']]
				select = xbmcgui.Dialog().select('改变来源', createSelect(sourceList, -1, curSource))
				if select == -1 or sourceList[select] == curSource: return
				source = serverInfo['playsite'][select]['cnsite']
				site = serverInfo['playsite'][select]['ensite']
				yearList = []
				year = ''
				do = 'switchsite'
				page = 1

			elif change == 'year': # 改变年份
				curYear = params.get('curyear')
				totalYears = params.get('totalyears')
				yearList = totalYears.split('|')
				select = xbmcgui.Dialog().select('改变年份', createSelect(yearList, -1, curYear))
				if select == -1 or yearList[select] == curYear: return
				year = yearList[select] 
				source = params.get('source')
				site = params.get('site')
				do = 'switchyear'
				page = 1

			elif change == 'page': # 改变页数
				curPage = int(params.get('curpage'))
				totalPage = int(params.get('totalpage'))
				pageList = []
				if curPage>1: pageList.append('上一页')
				for i in range(1, totalPage+1): pageList.append(str(i))
				if curPage<totalPage: pageList.append('下一页')
				select = xbmcgui.Dialog().select('改变页数', createSelect(pageList, -1, str(curPage)))
				if select == -1 or pageList[select] == str(curPage): return
				if pageList[select] == '上一页': page = curPage-1
				elif pageList[select] == '下一页': page = curPage+1
				else: page = int(pageList[select])
				source = params.get('source')
				site = params.get('site')
				totalYears = params.get('totalyears')
				yearList = totalYears.split('|')
				year = params.get('year')
				do = params.get('do')

		switch_url = 'https://www.360kan.com/cover/zongyilistv2?id=%s&site=%s&do=%s&year=%s' % (serverInfo['id'], site, do, year)
		httpData = getHttpData(switch_url).decode('unicode_escape')
		if not httpData: return

		if not year: # 获取年份
			reg = re.compile('<a class="js-year-item(?: current)?" data-year="(\d{4})"\s*href="#">', re.DOTALL)
			mat = reg.findall(httpData)
			yearList = mat[:]
			year = yearList[0]

		# 显示来源
		if len(serverInfo['playsite'])>1:
			item = xbmcgui.ListItem('[COLOR yellow][B]来源：[/B]%s[/COLOR]' % source)
			item.setArt({'poster': defaultPic})
			item_url = createUrl({'mode': 'series', 'change': 'source', 'cursource': source, 'url': url, 'title': title})
			xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

		# 显示年份
		totalYears = '|'.join(yearList)
		if len(yearList)>1:
			item = xbmcgui.ListItem('[COLOR yellow][B]年份：[/B]%s[/COLOR]' % year)
			item.setArt({'poster': defaultPic})
			item_url = createUrl({'mode': 'series', 'change': 'year', 'curyear': year, 'totalyears': totalYears, 'source': source, 'site': site, 'url': url, 'title': title})
			xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

		# 显示视频
		reg = re.compile("<a href='([^']+)' data-daochu=to=%s class='js-link'><div class='w-newfigure-imglink g-playicon js-playicon'> <img src='[^']*' data-src='[^']*' alt='([^']+)'  \\\\/><span class='w-newfigure-hint'>(.+?)<\\\\/span>" % escapeRegex(site), re.DOTALL)
		mat = reg.findall(httpData)
		if mat: mat = arrangeVideos(mat)
		videoList = mat[(page-1)*pageSize: min(page*pageSize, len(mat))]
		for entry in videoList:
			video_url = entry[0].replace(r'\/', '/')
			label = '%s %s' % (entry[2], entry[1])
			poster = getPoster(entry[0])

			item = xbmcgui.ListItem(label)
			item.setArt({'poster': poster})
			item.setInfo('video', infoLabels)
			item_url = createUrl({'mode': 'play', 'url': video_url, 'label': label, 'type': 'video'})
			item.addContextMenuItems([('解析方式…', 'RunPlugin(%s)' % createUrl({'mode': 'play', 'url': video_url, 'label': label, 'type': 'video', 'manual': 'true'}))])
			xbmcplugin.addDirectoryItem(pHandle, item_url, item, False)

		# 显示页数
		pageStr = ''
		totalPage = int((len(mat)+pageSize-1)/pageSize)
		if totalPage>1:
			item = xbmcgui.ListItem('[COLOR yellow][B]页数：[/B]第%d页[/COLOR]' % page)
			item.setArt({'poster': defaultPic})
			item_url = createUrl({'mode': 'series', 'change': 'page', 'curpage': str(page), 'totalpage': str(totalPage), 'source': source, 'site': site, 'year': year, 'totalyears': totalYears, 'do': do, 'url': url, 'title': title})
			xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

			pageStr = ' 第%d页' % page

	elif serverInfo['playtype'] == 'movie': # 电影
		change = params.get('change')
		if not change: # 首次进入
			page = 1

		else: # 非首次进入
			if change == 'page': # 改变页数
				curPage = int(params.get('curpage'))
				totalPage = int(params.get('totalpage'))
				pageList = []
				if curPage>1: pageList.append('上一页')
				for i in range(1, totalPage+1): pageList.append(str(i))
				if curPage<totalPage: pageList.append('下一页')
				select = xbmcgui.Dialog().select('改变页数', createSelect(pageList, -1, str(curPage)))
				if select == -1 or pageList[select] == str(curPage): return
				if pageList[select] == '上一页': page = curPage-1
				elif pageList[select] == '下一页': page = curPage+1
				else: page = int(pageList[select])

		# 显示视频
		reg = re.compile('<a data-daochu="to=([^"]*)" class="btn js-site ea-site ea-site-\\1" href="([^"]+)">(.+?)</a>', re.DOTALL)
		mat = reg.findall(httpData)

		videoList = mat[(page-1)*pageSize: min(page*pageSize, len(mat))]
		for entry in videoList:
			video_url = entry[1]
			poster = getPoster(entry[1])
			label = title
			if '(付费)' in entry[2]: label2 = '[COLOR red]%s[/COLOR]' % label
			else: label2 = label

			item = xbmcgui.ListItem(label2)
			item.setArt({'poster': poster})
			item.setInfo('video', infoLabels)
			item_url = createUrl({'mode': 'play', 'url': video_url, 'label': label, 'type': 'video'})
			item.addContextMenuItems([('解析方式…', 'RunPlugin(%s)' % createUrl({'mode': 'play', 'url': video_url, 'label': label, 'type': 'video', 'manual': 'true'}))])
			xbmcplugin.addDirectoryItem(pHandle, item_url, item, False)

		# 显示页数
		pageStr = ''
		totalPage = int((len(mat)+pageSize-1)/pageSize)
		if totalPage>1:
			item = xbmcgui.ListItem('[COLOR yellow][B]页数：[/B]第%d页[/COLOR]' % page)
			item.setArt({'poster': defaultPic})
			item_url = createUrl({'mode': 'series', 'change': 'page', 'curpage': str(page), 'totalpage': str(totalPage), 'url': url, 'title': title})
			xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

			pageStr = ' 第%d页' % page

	# 设置内容
	xbmcplugin.setContent(pHandle, 'videos')
	xbmcplugin.setPluginCategory(pHandle, title+pageStr)
	xbmcplugin.endOfDirectory(pHandle)

	# 设置视图
	forceview = __addon__.getSetting('forceview')
	if forceview == 'true':
		viewid = __addon__.getSetting('viewid')
		setView(viewid)

def showSearch():
	change = params.get('change')
	if not change: # 首次进入
		key = xbmcgui.Dialog().input('输入关键词')
		if not key: return
		url = 'https://so.360kan.com/index.php?kw=' + urllib.quote(key)

	else: # 非首次进入
		key = params.get('key')
		if change == 'subcate': # 改变子分类(普通)
			url = params.get('url')
			subCateInfo = simplejson.loads(params.get('subcateinfo'))
			subCateTitle = subCateInfo['name']
			subCateValue = subCateInfo['active']
			subCateList = subCateInfo['list']

			if subCateTitle == '时长': dataKey = 'du'
			elif subCateTitle == '更新时间': dataKey = 'pb'
			elif subCateTitle == '分类': dataKey = 'cat'
			elif subCateTitle == '来源': dataKey ='fr'

			select = xbmcgui.Dialog().select('改变%s' % subCateTitle, createSelect(subCateList, 1, subCateValue))
			if select == -1 or subCateList[select][1] == subCateValue: return
			dataValue = subCateList[select][0]

			if re.search('(%s=\d*)' % escapeRegex(dataKey), url): url = re.sub('%s=\d*' % escapeRegex(dataKey), '%s=%s' % (dataKey, dataValue), url)
			else: url = url + '&%s=%s' % (dataKey, dataValue)

			if re.search('(pageno=\d*)', url): url = re.sub('pageno=\d*', 'pageno=1', url)
			else: url = url + '&pageno=1'

		elif change == 'sort': # 改变排序(普通)
			url = params.get('url')
			sortInfo = simplejson.loads(params.get('sortinfo'))
			curSort = sortInfo['active']
			sortList = sortInfo['list']
			select = xbmcgui.Dialog().select('改变排序', createSelect(sortList, 1, curSort))
			if select == -1 or sortList[select][1] == curSort: return
			dataValue = sortList[select][0]

			if re.search('(st=\d*)', url): url = re.sub('st=\d*', 'st=%s' % dataValue, url)
			else: url = url + '&st=%s' % dataValue

			if re.search('(pageno=\d*)', url): url = re.sub('pageno=\d*', 'pageno=1', url)
			else: url = url + '&pageno=1'

		elif change == 'b_page': # 改变页数(普通)
			url = params.get('url')
			curPage = int(params.get('curpage'))
			totalPage = int(params.get('totalpage'))
			pageList = []
			if curPage>1: pageList.append('上一页')
			for i in range(1, totalPage+1): pageList.append(str(i))
			if curPage<totalPage: pageList.append('下一页')
			select = xbmcgui.Dialog().select('改变页数', createSelect(pageList, -1, str(curPage)))
			if select == -1 or pageList[select] == str(curPage): return
			if pageList[select] == '上一页': page = curPage-1
			elif pageList[select] == '下一页': page = curPage+1
			else: page = int(pageList[select])

			if re.search('(pageno=\d*)', url): url = re.sub('pageno=\d*', 'pageno=%d' % page, url)
			else: url = url + '&pageno=%d' % page

		elif change == 'tab': # 改变类别(专题)
			tabInfo = simplejson.loads(params.get('tabinfo'))
			curTab = tabInfo['active']
			tabList = tabInfo['list']
			select = xbmcgui.Dialog().select('改变类别', createSelect(tabList, 1, curTab))
			if select == -1 or tabList[select][1] == curTab: return
			url = 'https://so.360kan.com' + tabList[select][0]

		elif change == 'eb_page': # 改变页数(专题)
			pageInfo = simplejson.loads(params.get('pageinfo'))
			curPage = pageInfo['active']
			pageList = pageInfo['list']
			select = xbmcgui.Dialog().select('改变页数', createSelect(pageList, 1, curPage))
			if select == -1 or pageList[select][0] == '': return
			url = 'https://so.360kan.com' + pageList[select][0]

	httpData = getHttpData(url)
	if not httpData: return

	regex = re.compile('<div class="(.+?)-searchhead"(?: data-block="tj-searchhead" monitor-desc="searchhead" monitor-shortpv)?>', re.DOTALL)
	match = regex.search(httpData)
	if not match or match.group(1) not in ['b', 'eb']: # 未知搜索类型
		xbmcgui.Dialog().ok(__addonname__, '未知搜索类型 %s' % url)
		return

	elif match.group(1) == 'b': # 普通搜索类型
		# 显示子分类
		subCates = []
		regex = re.compile('<li class="m-head">(.+?)</li>(.+?)</ul>', re.DOTALL)
		match = regex.findall(httpData)
		for entry in match:
			subCateInfo = {}
			subCateInfo['name'] = entry[0]

			reg = re.compile('<li data-value="\d*?" class="m-item js-item-.*? m-active"><a href="javascript:;">(.+?)</a></li>', re.DOTALL)
			mat = reg.search(entry[1])
			subCateInfo['active'] = mat.group(1)

			reg = re.compile('<li data-value="(\d+?)" class="m-item js-item-[^"]*"><a href="javascript:;">(.+?)</a></li>', re.DOTALL)
			mat = reg.findall(entry[1])
			subCateInfo['list'] = mat[:]

			subCates.append(subCateInfo)

		for entry in subCates:
			item = xbmcgui.ListItem('[COLOR yellow][B]%s：[/B]%s[/COLOR]' % (entry['name'], entry['active']))
			item.setArt({'poster': defaultPic})
			item_url = createUrl({'mode': 'search', 'change': 'subcate', 'subcateinfo': simplejson.dumps(entry), 'url': url, 'key': key})
			xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

		# 显示排序
		regex = re.compile('<li data-value="\d*?" class="filterbar-item js-filterbar-item m-active"><a href="javascript:;">(.+?)</a></li>', re.DOTALL)
		match = regex.search(httpData)
		if match:
			sortInfo = {}
			sortInfo['active'] = match.group(1)

			reg = re.compile('<li data-value="(\d+?)" class="filterbar-item js-filterbar-item (?:m-active)?"><a href="javascript:;">(.+?)</a></li>', re.DOTALL)
			mat = reg.findall(httpData)
			sortInfo['list'] = mat[:]

			item = xbmcgui.ListItem('[COLOR yellow][B]排序：[/B]%s[/COLOR]' % sortInfo['active'])
			item.setArt({'poster': defaultPic})
			item_url = createUrl({'mode': 'search', 'change': 'sort', 'sortinfo': simplejson.dumps(sortInfo), 'url': url, 'key': key})
			xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

		# 显示结果
		regex = re.compile('<a href="([^"]+)" class="g-playicon js-playicon" title="([^"]+)" data-logger=\'ctype=detail\'  data-longrecord="[\d_]*">\s*<img src="([^"]+)" alt="\\2" />(.+?</p>)', re.DOTALL)
		match = regex.findall(httpData)
		for entry in match: # 专辑
			series_url = entry[0][21:]
			label = HTMLParser.HTMLParser().unescape(entry[1])
			poster = entry[2]

			infoLabels = {'plot': ''}
			reg = re.compile('<span class="playtype">(.+?)</span>', re.DOTALL)
			mat = reg.search(entry[3])
			if mat: infoLabels['plot'] += '类型：' + mat.group(1) + '\n'

			reg = re.compile('<span class="m-series">(.+?)</span>', re.DOTALL)
			mat = reg.search(entry[3])
			if mat: infoLabels['plot'] += '集数：' + mat.group(1) + '\n'

			reg = re.compile('<div class="m-score">(.+?)</div>', re.DOTALL)
			mat = reg.search(entry[3])
			if mat: infoLabels['plot'] += '评分：' + mat.group(1) + '\n'

			reg = re.compile("<li class='area'>\s*<b>地&nbsp;&nbsp;区&nbsp;：</b>(.+?)</li>", re.DOTALL)
			mat = reg.search(entry[3])
			if mat:
				regi = re.compile('<span>(.+?)</span>', re.DOTALL)
				mati = regi.findall(mat.group(1))
				if mati: infoLabels['plot'] += '地区：' + ' / '.join(mati) + '\n'

			reg = re.compile('<li class="actor">\s*<b>主&nbsp;&nbsp;演&nbsp;：</b>(.+?)</li>', re.DOTALL)
			mat = reg.search(entry[3])
			if mat:
				regi = re.compile('<a  href="[^"]*" title="([^"]+)" target="_self">', re.DOTALL)
				mati = regi.findall(mat.group(1))
				if mati: infoLabels['plot'] += '主演：' + ' / '.join(mati) + '\n'

			reg = re.compile('<i>简&nbsp;&nbsp;介&nbsp;：</i>(?:\s*<p>)?(.+?)</p>', re.DOTALL)
			mat = reg.search(entry[3])
			if mat: infoLabels['plot'] += '简介：' + mat.group(1).replace('\n', '').replace('\r', '').replace('　', '') + '\n'

			item = xbmcgui.ListItem(label)
			item.setArt({'poster': poster})
			item.setInfo('video', infoLabels)
			item_url = createUrl({'mode': 'series', 'url': series_url, 'title': label})
			item.addContextMenuItems([('采集方式…', 'RunPlugin(%s)' % createUrl({'mode': 'play', 'url': series_url, 'label': label, 'type': 'series'}))])
			xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

		regex = re.compile('<a href="([^"]+)"   data-posindex="" data-daochu="to=[^"]*" class="g-clear">\s*<div class="imgWrap g-playicon js-playicon">\s*<img data-src="([^"]+)" src="[^"]*" />\s*</div>\s*<div class="descWrap">\s*<p class="t1">(.+?)</p>(.+?</p>)', re.DOTALL)
		match = regex.findall(httpData)
		for entry in match: # 视频
			video_url = entry[0]
			label = HTMLParser.HTMLParser().unescape(re.sub('</?b>', '', entry[2]))
			poster = entry[1]

			infoLabels = {'plot': ''}
			reg = re.compile('<span class="(?:wemedia_name|first-desc ea-site ea-site-[^"]+)">(.+?)</span>', re.DOTALL)
			mat = reg.search(entry[3])
			if mat: infoLabels['plot'] += '来源：' + mat.group(1) + '\n'

			reg = re.compile('<span class="uploadTime">上传时间：(.+?)</span>', re.DOTALL)
			mat = reg.search(entry[3])
			if mat: infoLabels['plot'] += '上传：' + mat.group(1) + '\n'

			reg = re.compile('span class="uploadTime">时长：([\d:]+)</span>', re.DOTALL)
			mat = reg.search(entry[3])
			if mat: infoLabels['plot'] += '时长：' + mat.group(1) + '\n'

			reg = re.compile('<span class="playCount">(.+?)观看</span>', re.DOTALL)
			mat = reg.search(entry[3])
			if mat: infoLabels['plot'] += '观看：' + mat.group(1) + '\n'

			item = xbmcgui.ListItem(label)
			item.setArt({'poster': poster})
			item.setInfo('video', infoLabels)
			item_url = createUrl({'mode': 'play', 'url': video_url, 'label': label, 'type': 'video'})
			item.addContextMenuItems([('解析方式…', 'RunPlugin(%s)' % createUrl({'mode': 'play', 'url': video_url, 'label': label, 'type': 'video', 'manual': 'true'}))])
			xbmcplugin.addDirectoryItem(pHandle, item_url, item, False)

		# 显示页数
		pageStr = ''
		regex = re.compile('<script>\s*var serverdata ?= ?({.+?});\s*</script>', re.DOTALL)
		match = regex.search(httpData)
		serverInfo = jsonfy(match.group(1).replace("nores:''?1:0", 'nores:1').replace("nores:'1'?1:0", 'nores:1').decode('unicode_escape'))
		totalPage = serverInfo.get('totalPage')
		if totalPage and int(totalPage)>1:
			page = serverInfo.get('pageno')
			item = xbmcgui.ListItem('[COLOR yellow][B]页数：[/B]第%s页[/COLOR]' % page)
			item.setArt({'poster': defaultPic})
			item_url = createUrl({'mode': 'search', 'change': 'b_page', 'curpage': page, 'totalpage': totalPage, 'url': url, 'key': key})
			xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

			pageStr = ' 第%s页' % page

	elif match.group(1) == 'eb': # 专题搜索类型
		# 显示类别
		regex = re.compile('<li class="on"><a  target="_self" href="[^"]*">(.+?)</a></li>', re.DOTALL)
		match = regex.search(httpData)
		if match:
			tabInfo = {}
			tabInfo['active'] = match.group(1)

			reg = re.compile('<li (?:class="on")?><a  target="_self" href="([^"]+)">(.+?)</a></li>', re.DOTALL)
			mat = reg.findall(httpData)
			tabInfo['list'] = mat[:]

			item = xbmcgui.ListItem('[COLOR yellow][B]类别：[/B]%s[/COLOR]' % tabInfo['active'])
			item.setArt({'poster': defaultPic})
			item_url = createUrl({'mode': 'search', 'change': 'tab', 'tabinfo': simplejson.dumps(tabInfo), 'key': key})
			xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

		# 显示结果
		regex = re.compile("<a class='w-mfigure-imglink g-playicon js-playicon' href='([^']+)'> <img src='[^']*' data-src='([^']+)' alt='([^']+)'  />(.+?</h4>)", re.DOTALL)
		match = regex.findall(httpData)
		for entry in match: # 专辑
			series_url = entry[0][21:]
			label = HTMLParser.HTMLParser().unescape(re.sub('</?b>', '', entry[2]))
			poster = entry[1]

			infoLabels = {'plot': ''}
			reg = re.compile("<span class='w-mfigure-hint'>(/d{4})年</span>", re.DOTALL)
			mat = reg.search(entry[3])
			if mat: infoLabels['plot'] += '年代：' + mat.group(1) + '\n'
			else:
				reg = re.compile("<span class='w-mfigure-hint'>(.+?)</span>", re.DOTALL)
				mat = reg.search(entry[3])
				if mat: infoLabels['plot'] += '集数：' + mat.group(1) + '\n'

			reg = re.compile("<b class='w-mfigure-score'>(.+?)</b>", re.DOTALL)
			mat = reg.search(entry[3])
			if mat: infoLabels['plot'] += '评分：' + mat.group(1) + '\n'

			item = xbmcgui.ListItem(label)
			item.setArt({'poster': poster})
			item.setInfo('video', infoLabels)
			item_url = createUrl({'mode': 'series', 'url': series_url, 'title': label})
			item.addContextMenuItems([('采集方式…', 'RunPlugin(%s)' % createUrl({'mode': 'play', 'url': series_url, 'label': label, 'type': 'series'}))])
			xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

		regex = re.compile("<a class='w-sfigure-imglink g-playicon js-playicon' href='([^']+)' data-daochu=to=[^>]*> <img src='[^']*' data-src='([^']+)' alt='([^']+)'  />(.+?</a>)", re.DOTALL)
		match = regex.findall(httpData)
		for entry in match: # 视频
			video_url = entry[0]
			label = HTMLParser.HTMLParser().unescape(re.sub('</?b>', '', entry[2]))
			poster = entry[1]

			infoLabels = {'plot': ''}
			reg = re.compile("<span class='w-sfigure-lefthint'>(.+?)</span>", re.DOTALL)
			mat = reg.search(entry[3])
			if mat: infoLabels['plot'] += '来源：' + mat.group(1) + '\n'

			reg = re.compile("<span class='w-sfigure-righthint'>([\d:]+)</span>", re.DOTALL)
			mat = reg.search(entry[3])
			if mat: infoLabels['plot'] += '时长：' + mat.group(1) + '\n'

			item = xbmcgui.ListItem(label)
			item.setArt({'poster': poster})
			item.setInfo('video', infoLabels)
			item_url = createUrl({'mode': 'play', 'url': video_url, 'label': label, 'type': 'video'})
			item.addContextMenuItems([('解析方式…', 'RunPlugin(%s)' % createUrl({'mode': 'play', 'url': video_url, 'label': label, 'type': 'video', 'manual': 'true'}))])
			xbmcplugin.addDirectoryItem(pHandle, item_url, item, False)

		# 显示页数
		pageStr = ''
		regex = re.compile("<div monitor-desc='分页' id='js-ew-page' data-block='js-ew-page'  class='ew-page'>(.+?)</div>", re.DOTALL)
		match = regex.search(httpData)
		if match:
			pageInfo = {}
			reg = re.compile("<a target='_self' class='on'>(\d+)</a>", re.DOTALL)
			mat = reg.search(match.group(1))
			pageInfo['active'] = mat.group(1)

			pageInfo['list'] = []
			reg = re.compile("<a(.+?)target='_self'.*?>(.+?)</a>", re.DOTALL)
			mat = reg.findall(match.group(1))
			for entry in mat:
				pageIndex = entry[1].lstrip('&lt;').rstrip('&gt;')

				regi = re.compile("href='([^']+)'", re.DOTALL)
				mati = regi.search(entry[0])
				if mati: pageInfo['list'].append((mati.group(1), pageIndex))
				else: pageInfo['list'].append(('', pageIndex))

			item = xbmcgui.ListItem('[COLOR yellow][B]页数：[/B]第%s页[/COLOR]' % pageInfo['active'])
			item.setArt({'poster': defaultPic})
			item_url = createUrl({'mode': 'search', 'change': 'eb_page', 'pageinfo': simplejson.dumps(pageInfo), 'key': key})
			xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

			pageStr = ' 第%s页' % pageInfo['active']

	# 设置内容
	xbmcplugin.setContent(pHandle, 'albums')
	xbmcplugin.setPluginCategory(pHandle, key+pageStr)
	xbmcplugin.endOfDirectory(pHandle)

	# 设置视图
	forceview = __addon__.getSetting('forceview')
	if forceview == 'true':
		viewid = __addon__.getSetting('viewid')
		setView(viewid)

def showHistory():
	# 读取历史记录
	dataDir = getDataDir()
	filePath = os.path.join(dataDir, 'history.log')
	historyList = []
	if os.path.exists(filePath):
		fHandle = open(filePath, 'r')
		try:
			historyList = simplejson.load(fHandle)
		except simplejson.scanner.JSONDecodeError, e:
			xbmcgui.Dialog().ok(__addonname__, '历史记录为空或格式有误 %s' % str(e))
			pass
		fHandle.close()

	pageSize = 100
	totalPage = int((len(historyList)+pageSize-1)/pageSize)

	change = params.get('change')
	if not change: # 首次进入
		page = 1

	else: # 非首次进入
		if change == 'page': # 改变页数
			curPage = int(params.get('curpage'))
			pageList = []
			if curPage>1: pageList.append('上一页')
			for i in range(1, totalPage+1): pageList.append(str(i))
			if curPage<totalPage: pageList.append('下一页')
			select = xbmcgui.Dialog().select('改变页数', createSelect(pageList, -1, str(curPage)))
			if select == -1 or pageList[select] == str(curPage): return
			if pageList[select] == '上一页': page = curPage-1
			elif pageList[select] == '下一页': page = curPage+1
			else: page = int(pageList[select])

		elif change == 'refresh': # 刷新列表
			page = int(params.get('curpage'))

	# 显示视频
	videoList = historyList[(page-1)*pageSize: min(page*pageSize, len(historyList))]
	for i, entry in enumerate(videoList):
		video_url = entry.get('url')
		label = entry.get('label')
		type = entry.get('type')

		if None in [video_url, label, type]:
			if xbmcgui.Dialog().yesno(__addonname__, '第%s条历史记录格式有误，是否清除记录' % str(i+1)):
				os.remove(filePath)
				break
			else: continue

		menuItems = [('删除单条记录', 'RunPlugin(%s)' % createUrl({'mode': 'delete', 'index': str(i+(page-1)*pageSize), 'curpage': str(page-int(len(videoList)==1 and totalPage!=1))})), ('删除全部记录', 'RunPlugin(%s)' % createUrl({'mode': 'clear'}))]
		if type == 'series':
			poster = getPoster(video_url)
			isFolder = True
			item_url = createUrl({'mode': 'series', 'url': video_url, 'title': label})
			menuItems.append(('采集方式…', 'RunPlugin(%s)' % createUrl({'mode': 'play', 'url': video_url, 'label': label, 'type': 'series'})))
		elif type == 'video':
			poster = getPoster(video_url)
			isFolder = False
			item_url = createUrl({'mode': 'play', 'url': video_url, 'label': label, 'type': 'video'})
			menuItems.append(('解析方式…', 'RunPlugin(%s)' % createUrl({'mode': 'play', 'url': video_url, 'label': label, 'type': 'video', 'manual': 'true'})))
		elif type == 'tv':
			poster = getPoster('tv')
			isFolder = False
			item_url = createUrl({'mode': 'play', 'url': video_url, 'label': label})

		item = xbmcgui.ListItem(label)
		item.setArt({'poster': poster})
		item.addContextMenuItems(menuItems)
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, isFolder)

	# 显示页数
	pageStr = ''
	if totalPage>1:
		item = xbmcgui.ListItem('[COLOR yellow][B]页数：[/B]第%d页[/COLOR]' % page)
		item.setArt({'poster': defaultPic})
		item_url = createUrl({'mode': 'history', 'change': 'page', 'curpage': str(page)})
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

		pageStr = ' 第%d页' % page

	# 设置内容
	xbmcplugin.setContent(pHandle, 'videos')
	xbmcplugin.setPluginCategory(pHandle, '历史记录'+pageStr)
	xbmcplugin.endOfDirectory(pHandle)

	# 设置视图
	forceview = __addon__.getSetting('forceview')
	if forceview == 'true': setView('500')

def getInterface(type, url=None):
	interfaces = {'series': [('采集接口1', 'lib.kuyunzy'),
                             ('采集接口2', 'lib.zuidazy')],
                   'video': [('通用接口1', 'lib.ckmov'),
                             ('通用接口2', 'lib.i607p')],
                      'tv': [('直播接口',  'lib.tv')]}

	interfacesSpecial = {'www.iqiyi.com': [('专用接口(qiyi)', 'lib.qiyi')]}

	interfaceList = interfaces[type]
	if url:
		for key in interfacesSpecial:
			if key in url:
				interfaceList.extend(interfacesSpecial[key])
				break

	return interfaceList

def gatherVideo():
	key = xbmcgui.Dialog().input('输入关键词')
	if not key: return
	label = key

	interfaceList = getInterface('series')
	try:
		select = xbmcgui.Dialog().contextmenu(createSelect(interfaceList, 0))
	except AttributeError:
		select = xbmcgui.Dialog().select(label, createSelect(interfaceList, 0))
	if select == -1: return # 取消

	pDialog = xbmcgui.DialogProgress()
	pDialog.create(__addonname__)
	pDialog.update(50, '正在调用 [%s] 获取 [%s] 视频源' % (interfaceList[select][0], label))
	interface = __import__(interfaceList[select][1], fromlist=['getVideo'])
	getVideo = interface.getVideo
	sorttype = __addon__.getSetting('sorttype')
	video = getVideo(label, sorttype=sorttype)
	if pDialog.iscanceled(): return # 取消

	if video[0] == -1: return # 取消
	elif video[0] == 0: # 失败
		xbmcgui.Dialog().ok(__addonname__, video[1])
		return
	else: # 成功
		m3u = video[1]

		# 准备播放视频
		pDialog.update(100, '视频源 [%s] 获取成功，准备播放' % label)
		item = xbmcgui.ListItem(label)
		if pDialog.iscanceled(): return

		xbmc.Player().play(m3u, item) # 播放视频

	pDialog.close()

def playVideo():
	url = params.get('url')
	label = params.get('label')
	type = params.get('type', 'tv')

	# 获取视频播放信息
	if type == 'series': # 影院专辑
		interfaceList = getInterface('series')
		try:
			select = xbmcgui.Dialog().contextmenu(createSelect(interfaceList, 0))
		except AttributeError:
			select = xbmcgui.Dialog().select(label, createSelect(interfaceList, 0))
		if select == -1: return # 取消

		pDialog = xbmcgui.DialogProgress()
		pDialog.create(__addonname__)
		pDialog.update(50, '正在调用 [%s] 获取 [%s] 视频源' % (interfaceList[select][0], label))
		interface = __import__(interfaceList[select][1], fromlist=['getVideo'])
		getVideo = interface.getVideo
		sorttype = __addon__.getSetting('sorttype')
		video = getVideo(label, sorttype)
		if pDialog.iscanceled(): return # 取消

	elif type == 'video': # 影院单集
		interfaceList = getInterface('video', url)
		manual = params.get('manual')
		if manual: # 手动
			try:
				select = xbmcgui.Dialog().contextmenu(createSelect(interfaceList, 0))
			except AttributeError:
				select = xbmcgui.Dialog().select(label, createSelect(interfaceList, 0))
			if select == -1: return # 取消

			pDialog = xbmcgui.DialogProgress()
			pDialog.create(__addonname__)
			pDialog.update(50, '正在调用 [%s] 获取 [%s] 视频源' % (interfaceList[select][0], label))
			interface = __import__(interfaceList[select][1], fromlist=['getVideo'])
			getVideo = interface.getVideo
			video = getVideo(url)
			if pDialog.iscanceled(): return # 取消

		else: # 自动
			pDialog = xbmcgui.DialogProgress()
			pDialog.create(__addonname__)
			for i, entry in enumerate(interfaceList):
				pDialog.update(50, '(%d/%d) 正在调用 [%s] 获取 [%s] 视频源' % (i+1, len(interfaceList), entry[0], label))
				interface = __import__(entry[1], fromlist=['getVideo'])
				getVideo = interface.getVideo
				video = getVideo(url)
				if pDialog.iscanceled(): return # 取消

				if i<len(interfaceList)-1: # 非最后一个
					if video[0] == -1: return # 取消
					elif video[0] == 0: continue # 失败
					else: break # 成功

	elif type == 'tv': # 直播
		interfaceList = getInterface('tv')
		pDialog = xbmcgui.DialogProgress()
		pDialog.create(__addonname__)
		pDialog.update(50, '正在调用 [直播接口] 获取 [%s] 视频源' % label)
		interface = __import__(interfaceList[0][1], fromlist=['getVideo'])
		getVideo = interface.getVideo
		video = getVideo(url, label)
		if pDialog.iscanceled(): return # 取消

	if video[0] == -1: return # 取消
	elif video[0] == 0: # 失败
		xbmcgui.Dialog().ok(__addonname__, video[1])
		return
	else: # 成功
		m3u = video[1]
		poster = getPoster(url)

		# 准备播放视频
		pDialog.update(100, '视频源 [%s] 获取成功，准备播放' % label)
		item = xbmcgui.ListItem(label)
		item.setArt({'poster': poster})
		if pDialog.iscanceled(): return

		xbmc.Player().play(m3u, item) # 播放视频
		saveHistory({'url': url, 'label': label, 'type': type}) # 保存历史

	pDialog.close()

# 主程序
addon_url = sys.argv[0]
pHandle = int(sys.argv[1])
params = dict(urlparse.parse_qsl(sys.argv[2][1:]))
mode = params.get('mode')

defaultPic = os.path.join(getAddonDir(), 'media', 'default.png')

# 导航
if mode == None:
	showRoot()

# 分组
elif mode == 'group':
	showGroup()

# 频道
elif mode == 'channel':
	showChannel()

# 分类
elif mode == 'cate':
	showCate()

# 列表
elif mode == 'list':
	showList()

# 专辑
elif mode == 'series':
	showSeries()

# 搜索
elif mode == 'search':
	showSearch()

# 历史
elif mode == 'history':
	showHistory()

# 采集
elif mode == 'gather':
	gatherVideo()

# 播放
elif mode == 'play':
	playVideo()

# 删除单条记录
elif mode == 'delete':
	deleteHistory()

# 清除历史记录
elif mode == 'clear':
	clearHistory()

# 添加自定义频道
elif mode == 'add':
	addChannel()

# 删除自定义频道
elif mode == 'remove':
	removeChannel()