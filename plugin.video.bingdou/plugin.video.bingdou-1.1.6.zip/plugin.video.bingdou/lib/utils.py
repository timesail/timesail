# -*- coding: utf-8 -*-
import re

# 类
class Base64:
	_keyStr = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/='

	@staticmethod
	def encode(str):
		s = ''
		i = 0
		str = Base64._utf8_encode(str)
		while i < len(str):
			a = ord(str[i])
			i += 1
			b = ord(str[i])
			i += 1
			c = ord(str[i])
			i += 1
			d = a >> 2;
			e = (a & 3) << 4 | b >> 4
			f = (b & 15) << 2 | c >> 6
			g = c & 63
			if math.isnan(chr(b)):
				f = 64
				g = 64
			else:
				if math.isnan(chr(c)):
					g = 64
			s += Base64._keyStr[d] + Base64._keyStr[e] + Base64._keyStr[f] + Base64._keyStr[g]
		return s

	@staticmethod
	def decode(str):
		s = ''
		i = 0
		str = re.sub('[^A-Za-z0-9+/=]', '', str)
		while i < len(str):
			d = Base64._keyStr.index(str[i])
			i += 1
			e = Base64._keyStr.index(str[i])
			i += 1
			f = Base64._keyStr.index(str[i])
			i += 1
			g = Base64._keyStr.index(str[i])
			i += 1
			a = d << 2 | e >> 4
			b = (e & 15) << 4 | f >> 2
			c = (f & 3) << 6 | g
			s += chr(a)
			if f != 64:
				s += chr(b)
			if g != 64:
				s += chr(c)
		s = Base64._utf8_decode(s)
		return s

	@staticmethod
	def _utf8_encode(str):
		str = str.replace('rn', 'n');
		s = ''
		for a in range(len(str)):
			b = ord(str[a])
			if b < 128:
				s += chr(b)
			else:
				if b > 127 and b < 2048:
					s += chr(b >> 6 | 192)
					s += chr(b & 63 | 128)
				else:
					s += chr(b >> 12 | 224)
					s += chr(b >> 6 & 63 | 128)
					s += chr(b & 63 | 128)
		return s

	@staticmethod
	def _utf8_decode(str):
		s = ''
		a = 0
		b = 0
		c1 = 0
		c2 = 0
		while a < len(str):
			b = ord(str[a])
			if b < 128:
				s += chr(b)
				a += 1
			else:
				if b > 191 and b < 224:
					c2 = ord(str[a+1])
					s += chr((b & 31) << 6 | c2 & 63)
					a += 2
				else:
					c2 = ord(str[a+1])
					c3 = ord(str[a+2])
					s += chr((b & 15) << 12 | (c2 & 63) << 6 | c3 & 63)
					a += 3
		return s