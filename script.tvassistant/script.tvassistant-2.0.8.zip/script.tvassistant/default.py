# -*- coding: utf-8 -*-
from resources.lib.utils import *

# 检测iptvsimple
pvrid = "pvr.iptvsimple"
if not xbmc.getCondVisibility("System.HasAddon(%s)" % pvrid):
	xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "Addons.SetAddonEnabled", "params": {"addonid": "%s", "enabled": true}, "id": 1}' % pvrid)

if not xbmc.getCondVisibility("System.HasAddon(%s)" % pvrid):
	xbmc.executebuiltin("InstallAddon(%s)" % pvrid)
	sys.exit()

# 设置iptvsimple
pvrAddon = xbmcaddon.Addon(pvrid)
logoPath = os.path.join(addon_dir(), "media", "Channel Logos")
m3uPath = os.path.join(data_dir(), "channels.m3u")
epgPath = os.path.join(data_dir(), "epg.xml")
settingList = [("logoPathType", "0"), ("logoPath", logoPath), ("m3uPathType", "0"), ("m3uPath", m3uPath), ("epgPathType", "0"), ("epgPath", epgPath)]
for s in [("logoPathType", "0"), ("logoPath", logoPath), ("m3uPathType", "0"), ("m3uPath", m3uPath), ("epgPathType", "0"), ("epgPath", epgPath)]:
	if pvrAddon.getSetting(s[0]) == s[1]: settingList.remove(s)

if len(settingList) != 0:
	confirm = xbmcgui.Dialog().yesno(getString(30010), getString(30025))
	if not confirm: sys.exit()

	for s in settingList:
		pvrAddon.setSetting(s[0], s[1])

while True:
	select = xbmcgui.Dialog().select(getString(30010), [getString(30026), getString(30020), getString(30021), getString(30022), getString(30023), getString(30024)])
	if select == 0: # 管理直播源文件
		m3uManage()

	elif select == 1: # 配置直播源频道
		m3uMerge()

	elif select == 2: # 配置电子节目单
		openSettings()

	elif select == 3: # 配置PVR客户端
		pvrAddon.openSettings()

	elif select == 4: # 打开频道列表
		#m3uDisplay()
		xbmc.executebuiltin("ActivateWindow(videos,%s,return)" % m3uPath)
		break

	elif select == 5: # 打开IPTV电视
		xbmc.executebuiltin("ActivateWindow(tvchannels)")
		break

	elif select == -1: # 取消
		break