﻿# -*- coding: utf-8 -*-
import xbmc, xbmcgui, xbmcaddon
import sys, os, shutil, datetime, urllib2, urlparse, re, simplejson

if sys.getdefaultencoding() != 'utf-8':
	reload(sys)
	sys.setdefaultencoding('utf-8')

__addon__id__ = 'script.tvassistant'
__addon__     = xbmcaddon.Addon(__addon__id__)

allCHANNELS = [
	["cctv1",           "cctv", "CCTV1综合"],
	["cctv2",           "cctv", "CCTV2财经"],
	["cctv3",           "cctv", "CCTV3综艺"],
	["cctv4",           "cctv", "CCTV4中文国际"],
	["cctv5",           "cctv", "CCTV5体育"],
	["cctv5plus",       "cctv", "CCTV5+体育赛事"],
	["cctv6",           "cctv", "CCTV6电影"],
	["cctv7",           "cctv", "CCTV7军事农业"],
	["cctv8",           "cctv", "CCTV8电视剧"],
	["cctvjilu",        "cctv", "CCTV9纪录"],
	["cctv10",          "cctv", "CCTV10科教"],
	["cctv11",          "cctv", "CCTV11戏曲"],
	["cctv12",          "cctv", "CCTV12社会与法"],
	["cctv13",          "cctv", "CCTV13新闻"],
	["cctvchild",       "cctv", "CCTV14少儿"],
	["cctv15",          "cctv", "CCTV15音乐"],
	["anhui",           "cctv", "安徽卫视"],
	["btv1",            "cctv", "北京卫视"],
	["bingtuan",        "cctv", "兵团卫视"],
	["chongqing",       "cctv", "重庆卫视"],
	["dongfang",        "cctv", "东方卫视"],
	["dongnan",         "cctv", "东南卫视"],
	["gansu",           "cctv", "甘肃卫视"],
	["guangdong",       "cctv", "广东卫视"],
	["guangxi",         "cctv", "广西卫视"],
	["guizhou",         "cctv", "贵州卫视"],
	["hebei",           "cctv", "河北卫视"],
	["henan",           "cctv", "河南卫视"],
	["heilongjiang",    "cctv", "黑龙江卫视"],
	["hubei",           "cctv", "湖北卫视"],
	["hunan",           "cctv", "湖南卫视"],
	["jilin",           "cctv", "吉林卫视"],
	["jiangsu",         "cctv", "江苏卫视"],
	["jiangxi",         "cctv", "江西卫视"],
	["kangba",          "cctv", "康巴卫视"],
	["liaoning",        "cctv", "辽宁卫视"],
	["neimenggu",       "cctv", "内蒙古卫视"],
	["ningxia",         "cctv", "宁夏卫视"],
	["qinghai",         "cctv", "青海卫视"],
	["shandong",        "cctv", "山东卫视"],
	["shenzhen",        "cctv", "深圳卫视"],
	["shan1xi",         "cctv", "山西卫视"],
	["shan3xi",         "cctv", "陕西卫视"],
	["sichuan",         "cctv", "四川卫视"],
	["tianjin",         "cctv", "天津卫视"],
	["travel",          "cctv", "旅游卫视"],
	["xizang",          "cctv", "西藏卫视"],
	["xiamen",          "cctv", "厦门卫视"],
	["xianggangweishi", "cctv", "香港卫视"],
	["xinjiang",        "cctv", "新疆卫视"],
	["yanbian",         "cctv", "延边卫视"],
	["yunnan",          "cctv", "云南卫视"],
	["zhejiang",        "cctv", "浙江卫视"],
	#["haixia",          "HXWS",                                  "海峡卫视"],
	#["tvs2",            "tvs-2",                                 "TVS2南方卫视"],
	#["jinyingkt",       "HNTV-jinyingkatong",                    "金鹰卡通"],
	#["jinyingjs",       "hunanjinyingjishipindao",               "金鹰纪实"],
	#["xiaoxiang",       "HNTV-xiaoxiangdianying",                "潇湘电影"],
	#["dongfangdy",      "dongfangdianyingpindao-dianyingpindao", "东方电影"],
	#["btv10",           "BTV-10",                                "BTV卡酷少儿"],
	#["btv11",           "BTV-11hd",                              "BTV纪实"],
	#["jiajiakt",        "GDTV-6",                                "嘉佳卡通"],
	#["shanghaixw",      "SMG-xinwenzonghe",                      "上海新闻综合"],
	#["shanghaids",      "SMG-dianshiju",                         "上海电视剧"],
	#["shanghaixs",      "SMG-xingshang",                         "上海星尚"],
	#["shanghaicj",      "SMG-caijing",                           "上海财经"],
	#["shanghaijs",      "SMG-jishi",                             "上海纪实"],
	#["shanghaity",      "SMG-wuxingtiyu",                        "上海五星体育"],
	#["sichuanys",       "SCTV-yingshiwenyi",                     "四川影视文艺"],
	#["sichuanjj",       "SCTV-jingji",                           "四川经济"],
	#["sichuankj",       "SCTV-kejijiaoyu",                       "四川科技教育"],
	#["sichuangg",       "SCTV-gonggong",                         "四川公共"],
	#["sichuanwh",       "SCTV-wenhualvyou",                      "四川文化旅游"],
	#["sichuanfy",       "SCTV-funvertong",                       "四川妇女儿童"],
	#["liaoningys",      "LNTV-yingshiyule",                      "辽宁影视剧"],
	#["liaoningjj",      "LNTV-jingji",                           "辽宁经济"],
	#["liaoningty",      "LNTV-tiyu",                             "辽宁体育"],
	#["liaoningsh",      "LNTV-shenghuo",                         "辽宁生活"],
	#["liaoningjy",      "LNTV-jiaoyuqingshao",                   "辽宁教育青少"],
	#["liaoningbf",      "LNTV-beifang",                          "辽宁北方"],
	#["hebeijj",         "HEBTV-2",                               "河北经济"],
	#["hebeids",         "HEBTV-3",                               "河北都市"],
	#["hebeiys",         "HEBTV-4",                               "河北影视"],
	#["hebeise",         "HEBTV-5",                               "河北少儿科教"],
	#["hebeigg",         "HEBTV-6",                               "河北公共"],
	#["hebeinm",         "HEBTV-7",                               "河北农民"],
	#["shenzhendv",      "SHENZHENTV-dvshenghuo",                 "深圳DV生活"],
	#["cetv1",           "CETV-1HD",                              "教育1台"],
	#["sitvyx",          "youxifengyun",                          "SITV游戏风云"],
	#["sitvsh",          "shenghuoshishang",                      "SITV生活时尚"],
	#["sitvqc",          "jisuqiche",                             "SITV极速汽车"],
	#["sitvqjs",         "quanjishi",                             "SITV全纪实"],
	#["sitvjs",          "jinsepindao",                           "SITV金色频道"],
	["feicui",          "TVB-feicuitai",                         "TVB翡翠台"],
	["j5",              "TVB-j5tai",                             "TVB无线财经台"],
	["fenghuang",       "fhws",                                  "凤凰卫视"],
	["fenghuangzx",     "fenghuangzixuntai",                     "凤凰资讯"],
	["fenghuangxg",     "xianggangtai",                          "凤凰香港"],
	["fenghuangmz",     "meizhoutai",                            "凤凰美洲"],
	["fenghuangdy",     "fenghuangdianyingtai",                  "凤凰电影"],
	["aoya",            "ayws",                                  "澳亚卫视"],
	["aomenlh",         "amlhws",                                "澳门莲花"],
	["xingkong",        "STAR",                                  "星空卫视"],
	["nowhyj",          "nowkuanpin-huayujutai",                 "NOW华语剧"],
	["dongsencs",       "chaoshi",                               "东森超视"],
	["dongsenyy",       "youyoutai",                             "东森幼幼"],
	["weilaity",        "VIDEOLAND-tiyutai",                     "纬来体育"],
	["tvbsxw",          "TVBS-news",                             "TVBS新闻"],
	["huashizx",        "ctszx",                                 "华视资讯"],
	["minshixw",        "minshidianshitai-xinwentai",            "民视新闻"],
	["taiwan",          "twws",                                  "台湾卫视"],
	["sanlitw",         "SLTV-taiwantai",                        "三立台湾"],
	["sanlixw",         "SLTV-xinwentai",                        "三立新闻"],
	["feifanxw",        "USTV-xinwentai",                        "非凡新闻"],
	["yidianshixw",     "NextTV-xinwen",                         "壹新闻"],
]

def data_dir():
	dataDir = xbmc.translatePath( __addon__.getAddonInfo("profile")).decode("utf-8")
	if not os.path.exists(dataDir): os.makedirs(dataDir)
	return dataDir

def addon_dir():
	addonDir = xbmc.translatePath( __addon__.getAddonInfo("path")).decode("utf-8")
	return addonDir

def openSettings():
	__addon__.openSettings()

def getSetting(name):
	return __addon__.getSetting(name)

def setSetting(name,value):
	__addon__.setSetting(name,value)

def getString(string_id):
	return __addon__.getLocalizedString(string_id)

def formatDate(obj):
	return obj.strftime("%Y%m%d%H%M00 +0800")

def appendChannels(channelList):
	for entry in allCHANNELS:
		if getSetting(entry[0]) == "true":
			channelList.append(entry)

def compareEPG(channelList):
	epgfile = os.path.join(data_dir(), "epg.json")
	if os.path.exists(epgfile):
		cHandle = open(epgfile, "r")
		chns = simplejson.loads(cHandle.read().decode("utf-8"))
		cHandle.close()

		for entry in channelList:
			if not entry in chns: return False

		return True

	else: return False

def saveEPG(channelList):
	epgfile = os.path.join(data_dir(), "epg.json")
	cHandle = open(epgfile, "w")
	cHandle.write(simplejson.dumps(channelList, ensure_ascii=False))
	cHandle.close()

def appendInfoList(filePath, fileName, infoList, format=False):
	fHandle = open(filePath, "r")
	fileData = fHandle.read()
	fHandle.close()

	regex = re.compile('(#EXTINF:.*?),(.*?)\n(.*?)$', re.MULTILINE)
	match = regex.findall(fileData)
	for entry in match:
		reg = re.compile('tvg-id="(.*?)"', re.DOTALL)
		mat = reg.findall(entry[0])
		if len(mat) == 0: tvgID = ""
		else: tvgID = mat[0]

		reg = re.compile('tvg-logo="(.*?)"', re.DOTALL)
		mat = reg.findall(entry[0])
		if len(mat) == 0: tvgLogo = ""
		else: tvgLogo = mat[0]

		reg = re.compile('group-title="(.*?)"', re.DOTALL)
		mat = reg.findall(entry[0])
		if len(mat) == 0: groupTitle = ""
		else: groupTitle = mat[0]

		if format: tvgTitle = "%s(%s) [%s]" % (entry[1], entry[2].split("://")[0], fileName)
		else: tvgTitle = entry[1]
		infoList.append((tvgID, tvgLogo, groupTitle, tvgTitle, entry[2]))

def m3uMerge():
	# 读取直播源文件
	m3uDir = os.path.join(addon_dir(), "media", "Channel Lists")
	m3uTime = os.path.getmtime(m3uDir)
	m3uList = []
	for fileName in os.listdir(m3uDir):
		fileInfo = {}
		fileInfo["type"] = ""
		fileInfo["name"] = ""
		fileInfo["channels"] = []
		filePath = os.path.join(m3uDir, fileName)
		if os.path.getmtime(filePath) > m3uTime: m3uTime = os.path.getmtime(filePath)

		if os.path.isdir(filePath): # m3u文件夹
			fileInfo["type"] = "dir"
			fileInfo["name"] = fileName
			for fName in os.listdir(filePath):
				fPath = os.path.join(filePath, fName)
				if os.path.getmtime(fPath) > m3uTime: m3uTime = os.path.getmtime(fPath)
				if os.path.isfile(fPath) and fName.endswith(".m3u"):
					appendInfoList(fPath, "%s][%s" % (fName[:-4], fileName), fileInfo["channels"], True)

		if os.path.isfile(filePath) and fileName.endswith(".m3u"): # m3u文件
			fileInfo["type"] = "file"
			fileInfo["name"] = fileName[:-4]
			appendInfoList(filePath, fileName[:-4], fileInfo["channels"], True)

		if len(fileInfo["channels"]) != 0:
			fileInfo["channels"].sort(key=lambda x: (x[2], x[3]))
			m3uList.append(fileInfo)

	m3uList.sort(key=lambda x: (x["type"], x["name"]))

	# 读取已选直播源
	chnfile = os.path.join(data_dir(), "channels.json")
	if os.path.exists(chnfile) and os.path.getmtime(chnfile) > m3uTime:
		fHandle = open(chnfile, "r")
		selectInfo = simplejson.loads(fHandle.read().decode("utf-8"))
		fHandle.close()
	else: selectInfo = {}

	# 编辑直播源频道
	buildVersion = float(xbmc.getInfoLabel('System.BuildVersion').split(" ")[0].split("-")[0])
	modify = False
	while True:
		fList = ["%s [%d/%d]" % (entry["name"], len(selectInfo.get(str(i), [])), len(entry["channels"])) for i, entry in enumerate(m3uList)]
		fSelect = xbmcgui.Dialog().select(getString(30040), fList)
		if fSelect == -1: break

		if buildVersion<17: iSelect = xbmcgui.Dialog().select(getString(30041), [getString(30044), getString(30045), getString(30046)])
		else: iSelect = xbmcgui.Dialog().contextmenu([getString(30044), getString(30045), getString(30046)])
		if iSelect == -1: continue # 取消选择
		elif iSelect == 0: preList = selectInfo.get(str(fSelect), []) # 部分选择
		elif iSelect == 1: preList = range(len(m3uList[fSelect]["channels"])) # 全部选择
		elif iSelect == 2: preList = [] # 全部不选

		cList = [entry[3] for entry in m3uList[fSelect]["channels"]]
		if buildVersion<17: cSelect = xbmcgui.Dialog().multiselect(getString(30041), cList)
		else: cSelect = xbmcgui.Dialog().multiselect(getString(30041), cList, preselect=preList)
		if cSelect == None: continue

		selectInfo[str(fSelect)] = cSelect[:]
		modify = True

	if not modify: return

	# 合并直播源频道
	merge = xbmcgui.Dialog().yesno(getString(30010), getString(30042))
	if not merge: return

	selectChannels = []
	selectIDs = []
	for key, value in selectInfo.items():
		for v in value:
			selectChannels.append(m3uList[int(key)]["channels"][v])
			selectIDs.append(m3uList[int(key)]["channels"][v][0])
	selectChannels.sort(key=lambda x: (x[2], x[3]))

	# 生成m3u文件
	pDialog = xbmcgui.DialogProgress()
	pDialog.create(getString(30010))
	m3uPath = os.path.join(data_dir(), "channels.m3u")
	fHandle = open(m3uPath, "w")
	fHandle.write('#EXTM3U\n')
	for i, channel in enumerate(selectChannels):
		try:
			fHandle.write('#EXTINF:-1 tvg-id="%s" tvg-logo="%s" group-title="%s",%s\n' % (channel[0], channel[1], channel[2], channel[3]))
			fHandle.write('%s\n' % channel[4])
		except UnicodeError:
			fHandle.write('#EXTINF:-1 tvg-id="%s" tvg-logo="%s" group-title="%s",%s\n' % (channel[0].decode("gbk").encode("UTF-8"), channel[1].decode("gbk").encode("UTF-8"), channel[2].decode("gbk").encode("UTF-8"), channel[3].decode("gbk").encode("UTF-8")))
			fHandle.write('%s\n' % channel[4].decode("gbk").encode("UTF-8"))

		pStr = " (%02d/%02d) " % (i+1, len(selectChannels))
		pDialog.update(100*(i+1)/len(selectChannels), "{0}{1} {2}".format(pStr, getString(30032), channel[3]))
		#xbmc.sleep(100)
		if pDialog.iscanceled():
			fHandle.close()
			pDialog.close()
			return
	fHandle.close()
	pDialog.close()

	# 生成json文件
	fHandle = open(chnfile, "w")
	fHandle.write(simplejson.dumps(selectInfo, ensure_ascii=False))
	fHandle.close()

	# 设置epg节目单
	for channel in allCHANNELS:
		if channel[0] in selectIDs: setSetting(channel[0], "true")
		else: setSetting(channel[0], "false")

	ScriptPath = os.path.join(addon_dir(), "service.py")
	xbmc.executebuiltin("RunScript(%s)" % ScriptPath)

	xbmcgui.Dialog().ok(getString(30010), getString(30043).format(len(selectChannels)))

def m3uAdd():
	m3uFile = xbmcgui.Dialog().browseSingle(1, getString(30080), "files", ".m3u").decode("utf-8")
	if m3uFile == "": return

	m3uDir = os.path.join(addon_dir(), "media", "Channel Lists")
	if not os.path.exists(m3uDir): os.makedirs(m3uDir)

	if os.path.basename(m3uFile) in [entry.decode("utf-8") for entry in os.listdir(m3uDir)]:
		copy = xbmcgui.Dialog().yesno(getString(30010), getString(30082).format(os.path.basename(m3uFile)))
		if not copy: return

	shutil.copy(m3uFile, m3uDir)
	xbmcgui.Dialog().ok(getString(30010), getString(30081).format(os.path.basename(m3uFile)))

def m3uRemove():
	m3uDir = os.path.join(addon_dir(), "media", "Channel Lists", "")
	m3uFile = xbmcgui.Dialog().browseSingle(1, getString(30070), "files", ".m3u", defaultt=m3uDir).decode("utf-8")
	if os.path.basename(m3uFile) == "": return

	delete = xbmcgui.Dialog().yesno(getString(30010), getString(30071).format(os.path.basename(m3uFile)))
	if not delete: return

	os.remove(m3uFile)
	xbmcgui.Dialog().ok(getString(30010), getString(30072).format(os.path.basename(m3uFile)))

def txtToM3u():
	txtFile = xbmcgui.Dialog().browseSingle(1, getString(30090), "files", ".txt").decode("utf-8")
	if txtFile == "": return

	channelInfo = []
	fHandle = open(txtFile, "r")
	txtData = fHandle.read()
	fHandle.close()

	regex = re.compile('(.*?),(.*?)$', re.MULTILINE)
	match = regex.findall(txtData)
	for entry in match:
		channelInfo.append((entry[0], entry[1], urlparse.urlparse(entry[1])[1].split(":")[0]))

	channelInfo.sort(key=lambda x: (x[2], x[1]))

	outputDir = xbmcgui.Dialog().browseSingle(0, getString(30031), "files").decode("utf-8")
	if outputDir == "": return

	outputFile = os.path.join(outputDir, "%s.m3u" % os.path.basename(txtFile)[:-4])
	fHandle = open(outputFile, "w")
	fHandle.write('#EXTM3U\n')
	pDialog = xbmcgui.DialogProgress()
	pDialog.create(getString(30010))
	for i in range(len(channelInfo)):
		fHandle.write('#EXTINF:-1,%s\n' % channelInfo[i][0])
		fHandle.write('%s\n' % channelInfo[i][1])
		pStr = " (%02d/%02d) " % (i+1, len(channelInfo))
		pDialog.update(100*(i+1)/len(channelInfo), "{0}{1} {2}".format(pStr, getString(30032), channelInfo[i][0]))
		if pDialog.iscanceled():
			fHandle.close()
			pDialog.close()
			return
		xbmc.sleep(100)
	pDialog.close()
	fHandle.close()

	xbmcgui.Dialog().ok(getString(30010), getString(30091).format(len(channelInfo)))

def m3uSplit():
	m3uFile = xbmcgui.Dialog().browseSingle(1, getString(30030), "files", ".m3u").decode("utf-8")
	if m3uFile == "": return

	channelInfo = []
	fHandle = open(m3uFile, "r")
	m3uData = fHandle.read()
	fHandle.close()

	regex = re.compile('(#EXTINF:.*?),(.*?)\n(.*?)$', re.MULTILINE)
	match = regex.findall(m3uData)
	for entry in match:
		reg = re.compile('group-title="(.*?)"', re.DOTALL)
		mat = reg.findall(entry[0])
		if len(mat) == 0: groupTitle = ""
		else: groupTitle = mat[0]
		channelInfo.append((entry[0], entry[1], entry[2], urlparse.urlparse(entry[2])[1].split(":")[0], groupTitle))
	channelInfo.sort(key=lambda x: (x[3], x[2]))

	outputDir = xbmcgui.Dialog().browseSingle(0, getString(30031), "files").decode("utf-8")
	if outputDir == "": return

	i = 0
	pDialog = xbmcgui.DialogProgress()
	pDialog.create(getString(30010))
	while i != len(channelInfo):
		netloc = channelInfo[i][3]
		outputFile = os.path.join(outputDir, "%s.m3u" % netloc)
		fHandle = open(outputFile, "w")
		fHandle.write('#EXTM3U\n')
		while i != len(channelInfo) and channelInfo[i][3] == netloc:
			fHandle.write('%s,%s\n' % (channelInfo[i][0], channelInfo[i][1]))
			fHandle.write('%s\n' % channelInfo[i][2])

			pStr = " (%02d/%02d) " % (i+1, len(channelInfo))
			pDialog.update(100*(i+1)/len(channelInfo), "{0}{1} {2}".format(pStr, getString(30032), channelInfo[i][1]))
			if pDialog.iscanceled():
				fHandle.close()
				pDialog.close()
				return
			i += 1
		fHandle.close()
	pDialog.close()

	xbmcgui.Dialog().ok(getString(30010), getString(30033).format(len(channelInfo)))

def txtSplit():
	txtFile = xbmcgui.Dialog().browseSingle(1, getString(30030), "files", ".txt").decode("utf-8")
	if txtFile == "": return

	channelInfo = []
	fHandle = open(txtFile, "r")
	txtData = fHandle.read()
	fHandle.close()

	regex = re.compile('(.*?),(.*?)$', re.MULTILINE)
	match = regex.findall(txtData)
	for entry in match:
		channelInfo.append((entry[0], entry[1], urlparse.urlparse(entry[1])[1].split(":")[0]))

	channelInfo.sort(key=lambda x: (x[2], x[1]))

	outputDir = xbmcgui.Dialog().browseSingle(0, getString(30031), "files").decode("utf-8")
	if outputDir == "": return

	i = 0
	pDialog = xbmcgui.DialogProgress()
	pDialog.create(getString(30010))
	while i != len(channelInfo):
		netloc = channelInfo[i][2]
		outputFile = os.path.join(outputDir, "%s.m3u" % netloc)
		fHandle = open(outputFile, "w")
		fHandle.write('#EXTM3U\n')
		while i != len(channelInfo) and channelInfo[i][2] == netloc:
			fHandle.write('#EXTINF:-1,%s\n' % channelInfo[i][0])
			fHandle.write('%s\n' % channelInfo[i][1])

			pStr = " (%02d/%02d) " % (i+1, len(channelInfo))
			pDialog.update(100*(i+1)/len(channelInfo), "{0}{1} {2}".format(pStr, getString(30032), channelInfo[i][0]))
			if pDialog.iscanceled():
				fHandle.close()
				pDialog.close()
				return
			i += 1
		fHandle.close()
	pDialog.close()

	xbmcgui.Dialog().ok(getString(30010), getString(30033).format(len(channelInfo)))

def getDirList(dirPath, dirList):
	for fileName in os.listdir(dirPath):
		if os.path.isfile(os.path.join(dirPath, fileName)): dirList.append((dirPath, fileName))
		if os.path.isdir(os.path.join(dirPath, fileName)): getDirList(os.path.join(dirPath, fileName), dirList)

def m3uRename():
	compareDir = os.path.join(addon_dir(), "media", "Channel Lists")
	compareList = []
	getDirList(compareDir, compareList)

	renameDir = xbmcgui.Dialog().browseSingle(0, getString(30060), "files").decode("utf-8")
	if renameDir == "": return

	renameList = []
	getDirList(renameDir, renameList)

	i = 0
	for renameItem in renameList:
		for compareItem in compareList:
			if renameItem[1] == compareItem[1]:
				os.rename(os.path.join(renameItem[0], renameItem[1]), os.path.join(renameItem[0], "%s(%s)" % (renameItem[1], os.path.basename(compareItem[0]))))
				i += 1

	xbmcgui.Dialog().ok(getString(30010), getString(30061).format(i))

def m3uManage():
	list = [
		#getString(30055), # 转换直播源文件(txt->m3u)
		#getString(30052), # 拆分直播源文件(m3u)
		#getString(30053), # 拆分直播源文件(txt)
		#getString(30054), # 检测重名直播源
		getString(30050), # 添加直播源文件
		getString(30051) # 删除直播源文件
	]
	while True:
		select = xbmcgui.Dialog().select(getString(30026), list)
		if select == -1: break
		elif select == 0: m3uAdd()
		elif select == 1: m3uRemove()
		elif select == 2: txtToM3u()
		elif select == 3: m3uSplit()
		elif select == 4: txtSplit()
		elif select == 5: m3uRename()

def m3uDisplay():
	channels = []
	m3uName = "channels.m3u"
	m3uPath = os.path.join(data_dir(), m3uName)
	if os.path.exists(m3uPath):
		appendInfoList(m3uPath, m3uName, channels)

	while True:
		select = xbmcgui.Dialog().select(getString(30041), [channel[3] for channel in channels])
		if select == -1: break

		m3u = channels[select][4]
		item = xbmcgui.ListItem(channels[select][3])
		item.setArt({"thumb": os.path.join(addon_dir(), "media", "Channel Logos", channels[select][1])})

		xbmc.Player().play(m3u, item)
		break

def updateChannelCCTV(fHandle, channelID, channelName):
	dateInChina = (datetime.datetime.utcnow() + datetime.timedelta(hours=8)).replace(hour=0, minute=0) #UTC +0800

	#Get data
	try:
		request = urllib2.Request("http://api.cntv.cn/epg/epginfo?serviceId=tvcctv&c=%s&d=%s" % (channelID, dateInChina.strftime("%Y%m%d")))
		request.add_header("Referer", "http://tv.cntv.cn/epg")
		resp = urllib2.urlopen(request)
		data = resp.read().decode("utf-8")
		programmes = simplejson.loads(data)[channelID]['program']
		resp.close()
	except urllib2.HTTPError: return

	#Write channel data
	fHandle.write('  <channel id="{0}">\n'.format(channelID))
	fHandle.write('    <display-name lang="cn">{0}</display-name>\n'.format(channelName))
	fHandle.write('  </channel>\n'.format(channelID))

	#Write programme data
	for entry in programmes:
		startTime = datetime.datetime.fromtimestamp(entry['st'])
		stopTime  = datetime.datetime.fromtimestamp(entry['et'])

		fHandle.write('  <programme start="{0}" stop="{1}" channel="{2}">\n'.format(formatDate(startTime), formatDate(stopTime), channelID))
		fHandle.write('    <title lang="cn">{0}</title>\n'.format(entry['t'].encode("utf-8")))
		fHandle.write('  </programme>\n')

def updateChannelTVSOU(fHandle, channelID, siteID, channelName):
	dateInChina = (datetime.datetime.utcnow() + datetime.timedelta(hours=8)).replace(hour=0, minute=0) #UTC +0800

	#Get data
	try:
		request = urllib2.Request("https://www.tvsou.com/epg/%s" % (siteID))
		resp = urllib2.urlopen(request)
		data = resp.read().decode("utf-8")
		programmes = re.compile('<li class="relative cur.*?<span>([\d:]+)</span>.*?title="([^"]+)"', re.DOTALL).findall(data)
		resp.close()
	except urllib2.HTTPError: return

	#Write channel data
	fHandle.write('  <channel id="{0}">\n'.format(channelID))
	fHandle.write('    <display-name lang="cn">{0}</display-name>\n'.format(channelName))
	fHandle.write('  </channel>\n'.format(channelID))

	#Write programme data
	for i, entry in enumerate(programmes):
		startTime = dateInChina.replace(hour=int(entry[0].split(':')[0]), minute=int(entry[0].split(':')[1]))
		if i == len(programmes)-1:
			stopTime  = dateInChina.replace(hour=23, minute=59)
		else:
			stopTime  = dateInChina.replace(hour=int(programmes[i+1][0].split(':')[0]), minute=int(programmes[i+1][0].split(':')[1]))

		fHandle.write('  <programme start="{0}" stop="{1}" channel="{2}">\n'.format(formatDate(startTime), formatDate(stopTime), channelID))
		fHandle.write('    <title lang="cn">{0}</title>\n'.format(entry[1].encode("utf-8").strip()))
		fHandle.write('  </programme>\n')

def doUpdate(nowdate, epgfile, CHANNELS):
	fHandle = open(epgfile, "w")
	fHandle.write('<?xml version="1.0" encoding="utf-8" ?><tv><epgdate>{0}</epgdate>\n'.format(nowdate.strftime("%y%m%d")))

	pDialog = xbmcgui.DialogProgressBG()
	pDialog.create(getString(30010))
	pMonitor = xbmc.Monitor()
	for i, entry in enumerate(CHANNELS):
		if entry[1] == "cctv": updateChannelCCTV(fHandle, entry[0], entry[2])
		else: updateChannelTVSOU(fHandle, entry[0], entry[1], entry[2])

		pStr = " (%02d/%02d) " % (i+1, len(CHANNELS))
		pDialog.update(100*(i+1)/len(CHANNELS), "{0} {1}{2}".format(getString(30100).encode("utf-8"), entry[2], pStr))

		if pMonitor.abortRequested():
			pDialog.close()
			fHandle.write('<isComplete>False</isComplete></tv>')
			fHandle.close()
			return

	pDialog.close()
	fHandle.write('</tv>')
	fHandle.close()