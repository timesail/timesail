# -*- coding: utf-8 -*-
from resources.lib.utils import *

#Set a timer for the next update
nowdate = datetime.datetime.now()
delay = 24 * 60 - nowdate.hour * 60 - nowdate.minute
ScriptPath = os.path.join(addon_dir(), "service.py")
xbmc.executebuiltin("AlarmClock({0}, RunScript({1}), {2}, True)".format("EPGUpdate", ScriptPath, delay))

if getSetting("automatic") == "true":
	isExist = False
	isNonblank = False
	isUptodate = False
	isComplete = False
	isSameCHNs = False

	CHANNELS = []
	appendChannels(CHANNELS)

	epgfile = os.path.join(data_dir(), "epg.xml")
	isExist = os.path.exists(epgfile)
	if isExist:
		isNonblank = bool(os.path.getsize(epgfile))
		if isNonblank:
			fHandle = open(epgfile, "r")
			fLines = fHandle.readlines()
			fHandle.close()
			isUptodate = fLines[0].decode("utf-8").split("<epgdate>")[-1].split("</epgdate>")[0] == nowdate.strftime("%y%m%d")
			isComplete = fLines[-1] == "</tv>"
			if isNonblank and isComplete:
				isSameCHNs = compareEPG(CHANNELS)

	if not isExist or not isNonblank or not isUptodate or not isComplete or not isSameCHNs:
		doUpdate(nowdate, epgfile, CHANNELS)
		saveEPG(CHANNELS)