﻿# -*- coding: utf-8 -*-
import xbmc, xbmcgui, xbmcaddon
import sys, os, time

# 编码
if sys.getdefaultencoding() != 'utf-8':
	reload(sys)
	sys.setdefaultencoding('utf-8')

# 常数
__addonname__ = "缓存清理工具"
__addonid__   = "script.cachecleaner"
__addon__     = xbmcaddon.Addon(id=__addonid__)

# 函数
def logData(data, fileName):
	profile = xbmc.translatePath(__addon__.getAddonInfo('profile')).decode("utf-8")
	if not os.path.exists(profile): os.makedirs(profile)
	filePath = os.path.join(profile, fileName)
	fHandle = open(filePath, "w")
	fHandle.write(data)
	fHandle.close()

def formatSize(bytes):
	bytes = float(bytes)
	kb = bytes / 1024
	if kb >= 1024:
		mb = kb / 1024
		if mb >= 1024:
			gb = mb / 1024
			return "%.2fGB" % gb
		else: return "%.2fMB" % mb
	else: return "%.2fKB" % kb

# 打开设置
__addon__.openSettings()

# 获取设置
rangeList = ["全部", "大于", "小于"]
unitList = ["天", "小时", "分钟"]

range = __addon__.getSetting("range")
if range != "0":
	unit = __addon__.getSetting("unit")
	interval = int(__addon__.getSetting("interval"))
	if unit == "0": setSecs = interval*24*60*60
	elif unit == "1": setSecs = interval*60*60
	elif unit == "2": setSecs = interval*60
	tStr = "[%s%d%s]" % (rangeList[int(range)], interval, unitList[int(unit)])
else: tStr = "[%s]" % rangeList[int(range)]

# 扫描路径
pDialog = xbmcgui.DialogProgress()
pDialog.create(__addonname__+tStr, "扫描路径……")

s = 0
pathsList = []
thumb_dir = xbmc.translatePath("special://profile/Thumbnails").decode("utf-8")
for root, dirs, files in os.walk(thumb_dir, False):
	if root == thumb_dir: break
	if len(dirs) == 0 and len(files) == 0: pathsList.append(root)
	else: 
		t = 0
		for i, entry in enumerate(dirs):
			pStr = " (%d/%d)" % (i+1, len(dirs))
			pDialog.update(100*(i+1)/len(dirs), "正在扫描：" + entry + pStr)
			if pDialog.iscanceled(): break

			path = os.path.join(root, entry)
			if path in pathsList: t += 1

		for i, entry in enumerate(files):
			pStr = " (%d/%d)" % (i+1, len(files))
			pDialog.update(100*(i+1)/len(files), "正在扫描：" + entry + pStr)
			if pDialog.iscanceled(): break

			path = os.path.join(root, entry)
			nowTime = time.time()
			modifyTime = os.path.getmtime(path)
			intSecs = nowTime - modifyTime
			if range == "0":
				size = os.path.getsize(path)
				pathsList.append(path)
				s += size
				t += 1
			elif range == "1":
				if intSecs > setSecs:
					size = os.path.getsize(path)
					pathsList.append(path)
					s += size
					t += 1
			elif range == "2":
				if intSecs < setSecs:
					size = os.path.getsize(path)
					pathsList.append(path)
					s += size
					t += 1

		if t == len(dirs) + len(files): pathsList.append(root)

pDialog.close()
logData("\n".join(pathsList), "paths.log")

# 清理缓存
if len(pathsList) == 0:
	xbmcgui.Dialog().ok(__addonname__+tStr, "扫描路径%d个，占用空间%s，无需清理。" % (len(pathsList), formatSize(s)))
else:
	if xbmcgui.Dialog().yesno(__addonname__+tStr, "扫描路径%d个，占用空间%s，是否清理？" % (len(pathsList), formatSize(s))):
		pDialog = xbmcgui.DialogProgress()
		pDialog.create(__addonname__+tStr, "清理缓存……")

		r = 0
		f = 0
		s = 0
		removedList = []
		failedList = []
		for i, entry in enumerate(pathsList):
			pStr = " (%d/%d)" % (i+1, len(pathsList))
			pDialog.update(100*(i+1)/len(pathsList), "正在清理：" + os.path.basename(entry) + pStr)
			if pDialog.iscanceled(): break

			try:
				if os.path.isdir(entry):
					os.rmdir(entry)
				elif os.path.isfile(entry):
					size = os.path.getsize(entry)
					os.remove(entry)
					s += size
				else: raise

				r += 1
				removedList.append(entry)

			except Exception, e:
				f += 1
				failedList.append(str(e))
				pass

		pDialog.close()
		xbmcgui.Dialog().ok(__addonname__+tStr, "清理缓存%d个，出错%d个，释放空间%s。" % (r, f, formatSize(s)))
		logData("\n".join(removedList), "removed.log")
		logData("\n".join(failedList), "failed.log")