﻿# -*- coding: utf-8 -*-
import xbmc, xbmcgui, xbmcplugin, xbmcaddon
import urllib2, urllib, urlparse, re, sys, os, shutil, zlib, hashlib, time, simplejson, HTMLParser

# 编码
if sys.getdefaultencoding() != 'utf-8':
	reload(sys)
	sys.setdefaultencoding('utf-8')

# 常数
__addonname__ = "KiWi视频"
__addonid__   = "plugin.video.kiwi"
__addon__     = xbmcaddon.Addon(id=__addonid__)

# 函数
def logData(data, filePath="C:\Users\Administrator\Desktop\%s.txt" % __addonname__):
	filePath = filePath.decode("utf-8")
	fHandle = open(filePath, "w")
	fHandle.write(data)
	fHandle.close()

def dialog(str, type="ok"):
	if type == "ok": xbmcgui.Dialog().ok(__addonname__, str)
	elif type == "textviewer": xbmcgui.Dialog().textviewer(__addonname__, str)

def saveHistory(history):
	dataDir = getDataDir()
	filePath = os.path.join(dataDir, "history.log")
	if not os.path.exists(filePath): # 文件不存在则创建文件
		fHandle = open(filePath, "w")
		historyList = [history]

	else: # 文件存在则读取文件
		try:
			fHandle = open(filePath, "r+")
			historyList = simplejson.load(fHandle)
			if history in historyList: historyList.remove(history)
			historyList.insert(0, history)
			fHandle.seek(0, 0)
		except simplejson.scanner.JSONDecodeError: # 文件非json格式则重新创建文件
			fHandle = open(filePath, "w")
			historyList = [history]
			pass

	simplejson.dump(historyList, fHandle, ensure_ascii=False)
	fHandle.close()

def deleteHistory():
	index = int(params.get("index"))

	dataDir = getDataDir()
	filePath = os.path.join(dataDir, "history.log")
	fHandle = open(filePath, "r+")

	historyList = simplejson.load(fHandle)
	if xbmcgui.Dialog().yesno(__addonname__, "确定要删除历史记录 [%s] 吗" % historyList[index]["label"]):
		historyList.pop(index)
		fHandle.seek(0, 0)
		fHandle.truncate()
		simplejson.dump(historyList, fHandle, ensure_ascii=False)

		curPage = params.get("curPage")
		xbmc.executebuiltin("Container.Update(%s?mode=history&change=refresh&curPage=%s,replace)" % (addon_url, curPage))

	fHandle.close()

def clearHistory():
	dataDir = getDataDir()
	filePath = os.path.join(dataDir, "history.log")
	if os.path.exists(filePath):
		fHandle = open(filePath, "r")
		try:
			historyList = simplejson.load(fHandle)
			fHandle.close()
			if xbmcgui.Dialog().yesno(__addonname__, "历史记录共%d条，是否清除" % len(historyList)):
				os.remove(filePath)
				xbmcgui.Dialog().ok(__addonname__, "清除记录成功，共%d条" % len(historyList))

		except simplejson.scanner.JSONDecodeError:
			fHandle.close()
			if xbmcgui.Dialog().yesno(__addonname__, "历史记录为空或格式有误，是否清除"):
				os.remove(filePath)
				xbmcgui.Dialog().ok(__addonname__, "清除记录成功")

	else: xbmcgui.Dialog().ok(__addonname__, "历史记录不存在")

def addInterface():
	interfaceFile = xbmcgui.Dialog().browse(1, "选择要添加的解析接口文件", "files", ".py").decode("utf-8")
	if interfaceFile == "": return

	dataDir = getDataDir()
	interfaceDir = os.path.join(dataDir, "interface")
	if not os.path.exists(interfaceDir): os.makedirs(interfaceDir)

	fullName = os.path.basename(interfaceFile)
	shortName = re.sub(' ?\([\d\.]+\).py', '.py', fullName)
	if shortName in [entry.decode("utf-8") for entry in os.listdir(interfaceDir)]:
		copy = xbmcgui.Dialog().yesno(__addonname__, "解析接口文件 [%s] 已存在，是否更新" % shortName)
		if not copy: return
		else: os.remove(os.path.join(interfaceDir, shortName))

	shutil.copy(interfaceFile, interfaceDir)
	os.rename(os.path.join(interfaceDir, fullName), os.path.join(interfaceDir, shortName))
	xbmcgui.Dialog().ok(__addonname__, "成功添加解析接口文件 [%s]" % shortName)

def removeInterface():
	dataDir = getDataDir()
	interfaceDir = os.path.join(dataDir, "interface", "")

	interfaceFile = xbmcgui.Dialog().browse(1, "选择要删除的解析接口文件", "files", ".py", defaultt=interfaceDir).decode("utf-8")
	if os.path.basename(interfaceFile) == "": return

	delete = xbmcgui.Dialog().yesno(__addonname__, "确定要删除解析接口文件 [%s] 吗" % os.path.basename(interfaceFile))
	if not delete: return

	os.remove(interfaceFile)
	xbmcgui.Dialog().ok(__addonname__, "成功删除解析接口文件 [%s]" % os.path.basename(interfaceFile))

def manageInterface():
	list = ["添加解析接口", "删除解析接口"]
	while True:
		select = xbmcgui.Dialog().select("管理解析接口", list)
		if select == -1: break
		elif select == 0: addInterface()
		elif select == 1: removeInterface()

def addContextMenu(item, url, label, thumb):
	dataDir = getDataDir()
	interfaceDir = os.path.join(dataDir, "interface")
	if not os.path.exists(interfaceDir): os.makedirs(interfaceDir)

	interfaceItems = []
	for entry in os.listdir(interfaceDir):
		if os.path.isfile(os.path.join(interfaceDir, entry)) and entry.endswith(".py"):
			item_name = entry.decode("utf-8")[:-3]
			item_url = "%s?mode=call&interface=%s&url=%s&label=%s&thumb=%s" % (addon_url, item_name, url, label, thumb)
			interfaceItems.append((item_name, "RunPlugin(%s)" % item_url))

	if len(interfaceItems)>0: item.addContextMenuItems(interfaceItems)

def getDataDir():
	dataDir = xbmc.translatePath( __addon__.getAddonInfo("profile")).decode("utf-8")
	if not os.path.exists(dataDir): os.makedirs(dataDir)
	return dataDir

def getAddonDir():
	addonDir = xbmc.translatePath( __addon__.getAddonInfo("path")).decode("utf-8")
	return addonDir

def getHttpData(url):
	request = urllib2.Request(url)
	request.add_header('User-Agent', 'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0)')

	maxtimes = 10
	for t in range(maxtimes):
		try:
			response = urllib2.urlopen(request)
			httpData = response.read()
			break
		except Exception, e:
			if "11004" in str(e):
				if t<maxtimes-1: continue
				else: xbmcgui.Dialog().ok(__addonname__, "网络错误 %s %s %d次" % (url, str(e), maxtimes))
			else: xbmcgui.Dialog().ok(__addonname__, "网络错误 %s %s" % (url, str(e)))
			return

	if response.headers.get('content-encoding', None) == 'gzip':
		httpData = zlib.decompress(httpData, zlib.MAX_WBITS|32)

	response.close()
	return httpData

def createSelect(list, index, value):
	result = []
	if index == -1: #  一元列表
		for entry in list:
			if entry == value: result.append("[%s]" % value)
			else: result.append(entry)
	else: #  多元列表
		for entry in list:
			if entry[index] == value: result.append("[%s]" % value)
			else: result.append(entry[index])
	return result

def parseUrl(url):
	# /www/频道/分类-分类-分类-分类-分类------资费-年份--排序-页数-类别-iqiyi--状态.html
	regex = re.compile('/www/(\d+)/(\d*)-(\d*)-(\d*)-(\d*)-(\d*)------(\d*)-([\d_]*)--(\d+)-(\d+)-(\d+)-iqiyi--(\d*).html', re.DOTALL)
	match = regex.findall(url)
	urlInfo = {"chn": match[0][0], "cate": [match[0][1], match[0][2], match[0][3], match[0][4], match[0][5]], "pay": match[0][6], "year": match[0][7], "sort": match[0][8], "page": match[0][9], "tab": match[0][10], "status": match[0][11]}
	return urlInfo

def createUrl(urlInfo):
	# /www/频道/分类-分类-分类-分类-分类------资费-年份--排序-页数-类别-iqiyi--状态.html
	url = "/www/%s/%s-%s-%s-%s-%s------%s-%s--%s-%s-%s-iqiyi--%s.html" % (urlInfo["chn"], urlInfo["cate"][0], urlInfo["cate"][1], urlInfo["cate"][2], urlInfo["cate"][3], urlInfo["cate"][4], urlInfo["pay"], urlInfo["year"], urlInfo["sort"], urlInfo["page"], urlInfo["tab"], urlInfo["status"])
	return url

def sort_key(s):
	value = int(s[0].split("x")[0])
	if " " in s[0]: value -= 1
	return value

def formatSec(sec):
	m, s = divmod(sec, 60)
	h, m = divmod(m, 60)
	if h == 0: return "%02d:%02d" % (m, s)
	else: return "%02d:%02d:%02d" % (h, m, s)

def formatDate(date):
	return date[:4]+"-"+date[4:6]+"-"+date[6:]

def formatTime(timeStamp):
	return time.strftime("%Y-%m-%d", time.localtime(float(timeStamp/1000)))

def isDate(date):
	try:
		time.strptime(date, "%Y-%m-%d")
		return True
	except:
		return False

def showRoot():
	# 显示导航
	items = [("列表", "list"), ("专题", "topic"), ("热搜", "hot"), ("搜索", "search"), ("历史", "history")]
	for entry in items:
		item = xbmcgui.ListItem(entry[0])
		item.setArt({"poster": defaultPic})
		item_url = "%s?mode=%s" % (addon_url, entry[1])
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

	# 设置内容
	xbmcplugin.setContent(pHandle, "files")
	xbmcplugin.endOfDirectory(pHandle)

def showList():
	change = params.get("change")
	if change == None: # 首次进入
		url = "/www/1/-------------24-1-1-iqiyi--.html"
		urlInfo = parseUrl(url)
	else:
		url = params.get("url")
		httpData = getHttpData("http://list.iqiyi.com%s" % url)
		if httpData == None: return

		if change == "chn": # 改变频道
			curchn = params.get("curchn")
			regex = re.compile('<span\s*class="category-item.*?data-store-key="channelId"\s*data-id="(\d+)".*?class="category-text">(.+?)</span>', re.DOTALL)
			match = regex.findall(httpData)
			select = xbmcgui.Dialog().select("改变频道", createSelect(match, 1, curchn))
			if select == -1 or match[select][1] == curchn: return
			if match[select][0] == "10": url = "/www/10/1007-------------24-1-2-iqiyi--.html" # "10"片花,"1007"电影
			elif match[select][0] in ["25", "7", "16", "5", "28", "17", "13", "21", "26", "20"]: url = "/www/%s/-------------24-1-2-iqiyi--.html" % match[select][0]
			else: url = "/www/%s/-------------24-1-1-iqiyi--.html" % match[select][0]
			urlInfo = parseUrl(url)

		elif change == "sort": # 改变排序
			cursort = params.get("cursort")
			regex = re.compile('data-store-key="order"\s*data-id="(.*?)".*?class="category-text">(.+?)</span>', re.DOTALL)
			match = regex.findall(httpData)
			select = xbmcgui.Dialog().select("改变排序", createSelect(match, 1, cursort))
			if select == -1 or match[select][1] == cursort: return
			urlInfo = parseUrl(url)
			urlInfo["sort"] = match[select][0]
			urlInfo["page"] = "1"
			url = createUrl(urlInfo)

		elif change == "cate": # 改变分类
			cateIndex = params.get("cateindex")
			cateValue = params.get("catevalue")

			regex = re.compile('(<div class="category-list.*?data-store-key="threeCategory.*?</div>)', re.DOTALL)
			match = regex.findall(httpData)
			reg = re.compile('data-store-key="threeCategory.*?"(.*?)>.*?class="category-text">(.+?)</span>', re.DOTALL)
			mat = reg.findall(match[int(cateIndex)])

			IDList = []
			valueList = []
			for entry in mat:
				if entry[0] == "": IDList.append(entry[0])
				else: IDList.append(entry[0].strip()[9:-1])
				valueList.append(entry[1])

			select = xbmcgui.Dialog().select("改变分类", createSelect(valueList, -1, cateValue))
			if select == -1 or valueList[select] == cateValue: return

			urlInfo = parseUrl(url)
			for i in range(len(urlInfo["cate"])):
				if urlInfo["cate"][i] == "" or urlInfo["cate"][i] in IDList:
					urlInfo["cate"][i] = IDList[select]
					break

			urlInfo["cate"].sort(reverse=True)
			urlInfo["page"] = "1"
			url = createUrl(urlInfo)

		elif change == "year": # 改变年份
			curyear = params.get("curyear")
			regex = re.compile('data-store-key="year"\s*data-id="(.*?)".*?class="category-text">(.+?)</span>', re.DOTALL)
			match = regex.findall(httpData)
			select = xbmcgui.Dialog().select("改变年份", createSelect(match, 1, curyear))
			if select == -1 or match[select][1] == curyear: return
			urlInfo = parseUrl(url)
			urlInfo["year"] = match[select][0]
			urlInfo["page"] = "1"
			url = createUrl(urlInfo)

		elif change == "pay": # 改变资费
			curpay = params.get("curpay")
			regex = re.compile('data-store-key="isPay"\s*data-id="(.*?)".*?class="category-text">(.+?)</span>', re.DOTALL)
			match = regex.findall(httpData)
			select = xbmcgui.Dialog().select("改变资费", createSelect(match, 1, curpay))
			if select == -1 or match[select][1] == curpay: return
			urlInfo = parseUrl(url)
			urlInfo["pay"] = match[select][0]
			urlInfo["page"] = "1"
			url = createUrl(urlInfo)

		elif change == "status": # 改变状态
			curstatus = params.get("curstatus")
			regex = re.compile('data-store-key="isFinished"\s*data-id="(.*?)".*?class="category-text">(.+?)</span>', re.DOTALL)
			match = regex.findall(httpData)
			select = xbmcgui.Dialog().select("改变状态", createSelect(match, 1, curstatus))
			if select == -1 or match[select][1] == curstatus: return
			urlInfo = parseUrl(url)
			urlInfo["status"] = match[select][0]
			urlInfo["page"] = "1"
			url = createUrl(urlInfo)

		elif change == "tab": # 改变类别
			curtab = params.get("curtab")
			tabList = [("1", "专辑"), ("2", "视频")]
			select = xbmcgui.Dialog().select("改变类别", createSelect(tabList, 1, curtab))
			if select == -1 or tabList[select][1] == curtab: return
			urlInfo = parseUrl(url)
			urlInfo["tab"] = tabList[select][0]
			urlInfo["page"] = "1"
			url = createUrl(urlInfo)

		elif change == "page": # 改变页数
			curpage = params.get("curpage")
			regex = re.compile('data-store-key="page" data-id="(\d+)">([\d\.]+)</span>', re.DOTALL)
			match = regex.findall(httpData)
			select = xbmcgui.Dialog().select("改变页数", createSelect(match, 1, curpage))
			if select == -1 or match[select][1] == curpage: return
			urlInfo = parseUrl(url)
			urlInfo["page"] = match[select][0]
			url = createUrl(urlInfo)

	httpData = getHttpData("http://list.iqiyi.com%s" % url)
	if httpData == None: return

	# 显示频道
	chn = ""
	regex = re.compile('class="category-item  selected "\s*data-store-key="channelId.*?class="category-text">(.+?)</span>', re.DOTALL)
	match = regex.findall(httpData)
	if len(match)>0:
		chn = match[0]
		item = xbmcgui.ListItem("[COLOR yellow][B]频道：[/B]%s[/COLOR]" % chn)
		item.setArt({"poster": defaultPic})
		item_url = "%s?mode=list&change=chn&curchn=%s&url=%s" % (addon_url, chn, url)
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

	# 显示排序
	regex = re.compile('class="category-item   selected "\s*data-store-key="order.*?class="category-text">(.+?)</span>', re.DOTALL)
	match = regex.findall(httpData)
	if len(match)>0:
		item = xbmcgui.ListItem("[COLOR yellow][B]排序：[/B]%s[/COLOR]" % match[0])
		item.setArt({"poster": defaultPic})
		item_url = "%s?mode=list&change=sort&cursort=%s&url=%s" % (addon_url, match[0], url)
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

	# 显示分类
	regex = re.compile('class="category-item  selected "\s*data-store-key="threeCategory.*?class="category-text">(.+?)</span>', re.DOTALL)
	match = regex.findall(httpData)
	for i, entry in enumerate(match):
		item = xbmcgui.ListItem("[COLOR yellow][B]分类：[/B]%s[/COLOR]" % entry)
		item.setArt({"poster": defaultPic})
		item_url = "%s?mode=list&change=cate&cateindex=%d&catevalue=%s&url=%s" % (addon_url, i, entry, url)
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

	# 显示年份
	regex = re.compile('class="category-item  selected "\s*data-store-key="year.*?class="category-text">(.+?)</span>', re.DOTALL)
	match = regex.findall(httpData)
	if len(match)>0:
		item = xbmcgui.ListItem("[COLOR yellow][B]年份：[/B]%s[/COLOR]" % match[0])
		item.setArt({"poster": defaultPic})
		item_url = "%s?mode=list&change=year&curyear=%s&url=%s" % (addon_url, match[0], url)
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

	# 显示资费
	regex = re.compile('class="category-item  selected "\s*data-store-key="isPay.*?class="category-text">(.+?)</span>', re.DOTALL)
	match = regex.findall(httpData)
	if len(match)>0:
		item = xbmcgui.ListItem("[COLOR yellow][B]资费：[/B]%s[/COLOR]" % match[0])
		item.setArt({"poster": defaultPic})
		item_url = "%s?mode=list&change=pay&curpay=%s&url=%s" % (addon_url, match[0], url)
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

	# 显示状态
	regex = re.compile('class="category-item  selected "\s*data-store-key="isFinished.*?class="category-text">(.+?)</span>', re.DOTALL)
	match = regex.findall(httpData)
	if len(match)>0:
		item = xbmcgui.ListItem("[COLOR yellow][B]状态：[/B]%s[/COLOR]" % match[0])
		item.setArt({"poster": defaultPic})
		item_url = "%s?mode=list&change=status&curstatus=%s&url=%s" % (addon_url, match[0], url)
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

	# 还可以搜
	regex = re.compile('class="category-label-text">(还可以搜)</span>.*?class="category-list">(.+?)</div>', re.DOTALL)
	match = regex.findall(httpData)
	if len(match)>0:
		reg = re.compile('href="//so.iqiyi.com/so/q_(.+?)\?source=list"', re.DOTALL)
		mat = reg.findall(match[0][1])
		if len(mat)>0:
			item = xbmcgui.ListItem("[COLOR yellow][B]还可以搜：[/B]%s等[/COLOR]" % mat[0])
			item.setArt({"poster": defaultPic})
			item_url = "%s?mode=search&keys=%s" % (addon_url, ",".join(mat))
			xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

	# 显示视频
	if urlInfo["tab"] == "1":
		# 类别：专辑
		content = "movies"

		item = xbmcgui.ListItem("[COLOR yellow][B]类别：[/B]专辑[/COLOR]")
		item.setArt({"poster": defaultPic})
		item_url = "%s?mode=list&change=tab&curtab=专辑&url=%s" % (addon_url, url)
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

		regex = re.compile("data-original='(.+?' *data-index).*?src=\"(.+?)\" class=\"qy-mod-cover fadeOutIn-enter-active\">", re.DOTALL)
		match = regex.findall(httpData)
		for entry in match:
			originalInfo = simplejson.loads(entry[0].replace("'                     data-index", "").replace("\n", "").replace("\r", "").replace("　", ""))

			label = originalInfo["name"]
			if originalInfo.get("payMark"): label = "[COLOR red]%s[/COLOR]" % label # 付费

			if "http:" in entry[1]: poster = entry[1]
			else: poster = "http:%s" % entry[1]

			fanart = poster.replace("_260_360.jpg", "_720_405.jpg")
			if fanart == poster: fanart = None

			infoLabels = {}
			infoLabels["plot"] = ""
			if originalInfo.get("focus"): infoLabels["tagline"] = originalInfo.get("focus")
			if originalInfo.get("score"): infoLabels["plot"] += "[B]评分：[/B]"+str(originalInfo.get("score"))+"\n"
			if originalInfo.get("cast"):
				if originalInfo.get("cast").get("main_charactor"): infoLabels["plot"] += "[B]主演：[/B]"+" / ".join([ent["name"] for ent in originalInfo.get("cast").get("main_charactor")])+"\n"
				if originalInfo.get("cast").get("host"): infoLabels["plot"] += "[B]主持：[/B]"+" / ".join([ent["name"] for ent in originalInfo.get("cast").get("host")])+"\n"
				if originalInfo.get("cast").get("guest"): infoLabels["plot"] += "[B]嘉宾：[/B]"+" / ".join([ent["name"] for ent in originalInfo.get("cast").get("guest")])+"\n"
			if originalInfo.get("categories"): infoLabels["plot"] += "[B]类型：[/B]"+" / ".join([ent["name"] for ent in originalInfo.get("categories")])+"\n"
			if originalInfo.get("formatPeriod"): infoLabels["plot"] += "[B]上映：[/B]"+originalInfo.get("formatPeriod")+"\n"
			elif originalInfo.get("issueTime"): infoLabels["plot"] += "[B]上映：[/B]"+formatTime(originalInfo.get("issueTime"))+"\n"
			if originalInfo.get("meta"): infoLabels["plot"] += "[B]集数：[/B]"+originalInfo.get("meta")+"\n"
			if originalInfo.get("duration"): infoLabels["plot"] += "[B]片长：[/B]"+originalInfo.get("duration")+"\n"
			if originalInfo.get("description"): infoLabels["plot"] += "[B]简介：[/B]"+originalInfo.get("description")+"\n"

			item = xbmcgui.ListItem(HTMLParser.HTMLParser().unescape(label))
			item.setArt({"poster": poster, "fanart": fanart})
			item.setInfo("video", infoLabels)
			if originalInfo["playUrl"][21:23] == "a_": # 专辑
				item_url = "%s?mode=series&albumid=%s" % (addon_url, originalInfo["albumId"])
				xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)
			else: # 单集
				item_url = "%s?mode=play&url=%s&label=%s&thumb=%s" % (addon_url, originalInfo["playUrl"], label, poster)
				addContextMenu(item, originalInfo["playUrl"], label, fanart)
				xbmcplugin.addDirectoryItem(pHandle, item_url, item, False)

	elif urlInfo["tab"] == "2":
		# 类别：视频
		content = "videos"

		item = xbmcgui.ListItem("[COLOR yellow][B]类别：[/B]视频[/COLOR]")
		item.setArt({"poster": defaultPic})
		item_url = "%s?mode=list&change=tab&curtab=视频&url=%s" % (addon_url, url)
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

		regex = re.compile('class="qy-mod-li .*?<a title="(.+?)" class="qy-mod-link" href="(.+?)" target="_blank">\s*<img alt=".*?" src="(.+?)" class="qy-mod-cover fadeOutIn-enter-active">(.+?)<div class="icon-br"><span class="qy-mod-label">(.*?)</span></div>', re.DOTALL)
		match = regex.findall(httpData)
		for entry in match:
			label = entry[0]
			if entry[3].strip(): label = "[COLOR red]%s[/COLOR]" % label # 付费

			if "http:" in entry[2]: thumb = entry[2]
			else: thumb = "http:%s" % entry[2]

			if "http:" in entry[1]: video_url = entry[1]
			else: video_url = "http:%s" % entry[1]

			infoLabels = {}
			infoLabels["plot"] = ""
			if entry[4]: infoLabels["plot"] = "[B]片长：[/B]"+entry[4]+"\n"

			item = xbmcgui.ListItem(HTMLParser.HTMLParser().unescape(label))
			item.setArt({"thumb": thumb})
			item.setInfo("video", infoLabels)
			item_url = "%s?mode=play&url=%s&label=%s&thumb=%s" % (addon_url, video_url, label, thumb)
			addContextMenu(item, video_url, label, thumb)
			xbmcplugin.addDirectoryItem(pHandle, item_url, item, False)

	# 显示页数
	curPage = ""
	regex = re.compile('class="page  curPage " data-store-key="page.*?>(\d+)</span>', re.DOTALL)
	match = regex.findall(httpData)
	if len(match)>0:
		curPage = match[0]
		item = xbmcgui.ListItem("[COLOR yellow][B]页数：[/B]第%s页[/COLOR]" % curPage)
		item.setArt({"poster": defaultPic})
		item_url = "%s?mode=list&change=page&curpage=%s&url=%s" % (addon_url, curPage, url)
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)
		curPage = " 第%s页" % curPage

	# 设置内容 及 视图
	xbmcplugin.setContent(pHandle, content)
	xbmc.executebuiltin("container.SetViewMode(%d)" % viewSetting)
	xbmcplugin.setPluginCategory(pHandle, chn+curPage)
	xbmcplugin.endOfDirectory(pHandle)

def showTopic():
	change = params.get("change")
	if change == None: # 首次进入
		url = "http://www.iqiyi.com/lib/zhuanti/tese/"
	else:
		url = params.get("url")
		httpData = getHttpData(url)
		if httpData == None: return

		if change == "cate": # 改变分类
			curCate = params.get("curcate")
			regex = re.compile('<ul class="tab-normal(.+?)</ul>', re.DOTALL)
			match = regex.findall(httpData)
			reg = re.compile('<li.*?href="(.+?)" title="(.+?)"', re.DOTALL)
			mat = reg.findall(match[0])
			select = xbmcgui.Dialog().select("改变分类", createSelect(mat, 1, curCate))
			if select == -1 or mat[select][1] == curCate: return
			url = "http:%s" % mat[select][0]

	httpData = getHttpData(url)
	if httpData == None: return

	# 显示分类
	regex = re.compile('<li class="selected"><a href=".*?" title="(.+?)"', re.DOTALL)
	match = regex.findall(httpData)
	cate = match[0]
	item = xbmcgui.ListItem("[COLOR yellow][B]分类：[/B]%s[/COLOR]" % cate)
	item.setArt({"poster": defaultPic})
	item_url = "%s?mode=topic&change=cate&curcate=%s&url=%s" % (addon_url, cate, url)
	xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

	# 显示专题
	regex = re.compile('<div class="site-piclist_pic.*?title="(.+?)" href="(.+?)".*?src="(.+?)".*?class="site-piclist_info_describe">(.+?)</p>', re.DOTALL)
	match = regex.findall(httpData)
	for entry in match:
		if entry[1][16:19] != "lib": continue # 非lib不显示

		topic_url = "http:%s" % entry[1]
		label = entry[0]
		if "http:" in entry[2]: thumb = entry[2]
		else: thumb = "http:%s" % entry[2]

		infoLabels = {}
		infoLabels["tagline"] = HTMLParser.HTMLParser().unescape(entry[3])

		item = xbmcgui.ListItem(HTMLParser.HTMLParser().unescape(label))
		item.setArt({"thumb": thumb})
		item.setInfo("video", infoLabels)
		item_url = "%s?mode=content&url=%s" % (addon_url, topic_url)
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

	# 设置内容 及 视图
	xbmcplugin.setContent(pHandle, "videos")
	xbmc.executebuiltin("container.SetViewMode(%d)" % viewSetting)
	xbmcplugin.setPluginCategory(pHandle, cate)
	xbmcplugin.endOfDirectory(pHandle)

def showContent():
	url = params.get("url")
	change = params.get("change")
	if change == "page": # 改变页数
		curPage = params.get("curpage")
		httpData = getHttpData(url)
		if httpData == None: return

		regex = re.compile('<(?:a|span).*?data-key=".*?(?:href|class)="([^"]+?)">(.+?)</(?:a|span)>', re.DOTALL)
		match = regex.findall(httpData)
		if len(match)>0:
			select = xbmcgui.Dialog().select("改变页数", createSelect(match, 1, curPage))
			if select == -1 or match[select][1] == curPage: return
			if "http:" in match[select][0]: url = match[select][0]
			else: url = "http:%s" % match[select][0]
		else:
			xbmcgui.Dialog().ok(__addonname__, "当前没有其他页数")
			return

	httpData = getHttpData(url)
	if httpData == None: return

	# 显示视频
	regex = re.compile('<div class="mspecial-main-resume.*?<h1>(.+?)</h1>', re.DOTALL)
	match = regex.findall(httpData)
	topic = match[0]

	regex = re.compile('<p class="msl-img-array.*?>(.+?)</p>.*?src="(.+?)" alt="(.+?)".*?<p class="msld-performer">主演:(.+?)</p>.*?<p class="msld-watch">看点:(.+?)</p>.*?时间:(.+?)</p>.*?<p class="msld-profile">(.+?)</p>', re.DOTALL)
	match = regex.findall(httpData)

	for entry in match:
		key = entry[2]
		label = "%02d. %s" % (int(entry[0]), entry[2])
		if "http:" in entry[1]: poster = entry[1]
		else: poster = "http:%s" % entry[1]

		fanart = poster.replace("_180_236.jpg", "_720_405.jpg")
		if fanart == poster: fanart = None

		infoLabels = {}
		infoLabels["plot"] = ""

		reg = re.compile('">(.+?)</a>', re.DOTALL)
		mat = reg.findall(entry[3])
		if len(mat)>0: infoLabels["plot"] += "[B]主演：[/B]"+" / ".join(mat)+"\n"

		reg = re.compile('>(.+?)</a>', re.DOTALL)
		mat = reg.findall(entry[4])
		if len(mat)>0: infoLabels["plot"] += "[B]看点：[/B]"+" / ".join(mat)+"\n"

		if entry[5].strip() != "": infoLabels["plot"] += "[B]上映：[/B]"+entry[5].strip()+"\n"
		if entry[6].strip() != "": infoLabels["plot"] += "[B]简介：[/B]"+entry[6].strip()+"\n"

		item = xbmcgui.ListItem(HTMLParser.HTMLParser().unescape(label))
		item.setArt({"poster": poster, "fanart": fanart})
		item.setInfo("video", infoLabels)
		item_url = "%s?mode=search&key=%s" % (addon_url, key)
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

	# 显示页数
	curPage = ""
	regex = re.compile('<div class="mod-page mt50" data-ugcplayhistory-elem="pager.*?class="curPage">(\d+?)</span>', re.DOTALL)
	match = regex.findall(httpData)
	if len(match)>0:
		curPage = match[0]
		item = xbmcgui.ListItem("[COLOR yellow][B]页数：[/B]第%s页[/COLOR]" % curPage)
		item.setArt({"poster": defaultPic})
		item_url = "%s?mode=content&change=page&curpage=%s&url=%s" % (addon_url, curPage, url)
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)
		curPage = " 第%s页" % curPage


	# 设置内容 及 视图
	xbmcplugin.setContent(pHandle, "movies")
	xbmc.executebuiltin("container.SetViewMode(%d)" % viewSetting)
	xbmcplugin.setPluginCategory(pHandle, topic+curPage)
	xbmcplugin.endOfDirectory(pHandle)

def showHot():
	change = params.get("change")
	if change == None: # 首次进入
		url = "http://v.iqiyi.com/index/resou/index.html"
	else:
		url = params.get("url")
		httpData = getHttpData(url)
		if httpData == None: return

		if change == "cate": # 改变分类
			curCate = params.get("curcate")
			regex = re.compile('<li class="nav_item.*?href="(.+?)" title="(.+?)"', re.DOTALL)
			match = regex.findall(httpData)
			match = match[1:-1]
			select = xbmcgui.Dialog().select("改变分类", createSelect(match, 1, curCate))
			if select == -1 or match[select][1] == curCate: return
			url = match[select][0]

	httpData = getHttpData(url)
	if httpData == None: return

	# 显示分类
	regex = re.compile('<li class="nav_item selected.*?title="(.+?)"', re.DOTALL)
	match = regex.findall(httpData)
	cate = match[0]
	item = xbmcgui.ListItem("[COLOR yellow][B]分类：[/B]%s[/COLOR]" % cate)
	item.setArt({"poster": defaultPic})
	item_url = "%s?mode=hot&change=cate&curcate=%s&url=%s" % (addon_url, cate, url)
	xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

	# 显示关键词
	regex = re.compile('<table class="mod_top_list-table.*?<th>(.+?)</th>.*?<tbody data-ranklist-elem="list(.+?)</tbody>', re.DOTALL)
	match = regex.findall(httpData)
	type = match[0][0]

	regex = re.compile('data-ranklist-elem="rank">(.+?)</i>.*?target=\'_blank\'>(.+?)</a>.*?class="item_usrInfo(.+?)</td>', re.DOTALL)
	match = regex.findall(httpData)
	for entry in match:
		rank = "%02d. " % int(entry[0])
		key = entry[1]

		infoLabels = {}
		infoLabels["plot"] = ""

		em = ""
		reg = re.compile('<em class="c-999">(.+?)</em>', re.DOTALL)
		mat = reg.findall(entry[2])
		if len(mat)>0: em = mat[0].strip()+" "

		reg = re.compile("'>(.+?)</a>", re.DOTALL)
		mat = reg.findall(entry[2])
		if len(mat)>0: infoLabels["plot"] += "[B]%s：[/B]%s%s\n" % (type, em, " / ".join(mat))

		item = xbmcgui.ListItem(HTMLParser.HTMLParser().unescape(rank+key))
		item.setArt({"poster": defaultPic})
		item.setInfo("video", infoLabels)
		item_url = "%s?mode=search&key=%s" % (addon_url, key)
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

	# 设置内容
	xbmcplugin.setContent(pHandle, "files")
	xbmcplugin.setPluginCategory(pHandle, cate)
	xbmcplugin.endOfDirectory(pHandle)

def showSearch():
	change = params.get("change")
	key = params.get("key")
	keys = params.get("keys")
	if change == None: # 首次进入
		if key != None: pass
		elif keys != None:
			keyList = keys.split(",")
			select = xbmcgui.Dialog().select("还可以搜", keyList)
			if select == -1: return
			key = keyList[select]
		else:
			key = xbmcgui.Dialog().input("输入关键词")
			if key == "":return

		channel = "全部"
		url = "/so/q_%s" % urllib.quote(key)
	else:
		channel = params.get("channel")
		url = params.get("url").replace(key, urllib.quote(key)).replace(channel, urllib.quote(channel))
		httpData = getHttpData("http://so.iqiyi.com%s" % url)
		if httpData == None: return

		if change == "cate": # 改变分类
			cateTitle = params.get("catetitle")
			cateValue = params.get("catevalue")
			regex = re.compile('<div class="mod_sear_list.*?<h3>%s</h3>(.+?)</div>' % cateTitle, re.DOTALL)
			match = regex.findall(httpData)
			reg = re.compile('<li.*?href="([^"]+?)".*?title="(.+?)"', re.DOTALL)
			mat = reg.findall(match[0])
			select = xbmcgui.Dialog().select("改变%s" % cateTitle.strip("：").strip(":"), createSelect(mat, 1, cateValue))
			if select == -1 or mat[select][1] == cateValue: return
			if cateTitle == "频道:": channel = mat[select][1] # 频道中文url编码
			url = "/so/"+mat[select][0].replace(channel, urllib.quote(channel))

		elif change == "sort": # 改变排序
			curSort = params.get("cursort")
			regex = re.compile('<div class="mod_sear_select">(.+?)</div>', re.DOTALL)
			match = regex.findall(httpData)
			reg = re.compile('<a.*?href="([^"]+?)".*?title="(.*?)".*?name="sort">', re.DOTALL)
			mat = reg.findall(match[0])
			select = xbmcgui.Dialog().select("改变排序", createSelect(mat, 1, curSort))
			if select == -1 or mat[select][1] == curSort: return
			url = "/so/"+mat[select][0].replace(channel, urllib.quote(channel))

		elif change == "page": # 改变页数
			curPage = params.get("curpage")
			regex = re.compile('<(?:a|span) data-key=".*?(?:href|class)="([^"]+?)">(.+?)</(?:a|span)>', re.DOTALL)
			match = regex.findall(httpData)
			if len(match)>0:
				select = xbmcgui.Dialog().select("改变页数", createSelect(match, 1, curPage))
				if select == -1 or match[select][1] == curPage: return
				url = match[select][0].replace(channel, urllib.quote(channel))
			else:
				xbmcgui.Dialog().ok(__addonname__, "当前没有其他页数")
				return

	httpData = getHttpData("http://so.iqiyi.com%s" % url)
	if httpData == None: return

	# 显示分类
	cates = []
	regex = re.compile('<div class="mod_sear_list.*?<h3>(.+?)</h3>(.+?)</div>', re.DOTALL)
	match = regex.findall(httpData)
	if len(match)>0:
		for entry in match:
			reg = re.compile('<li class="selected"><a href="#" title="(.+?)"', re.DOTALL)
			mat = reg.findall(entry[1])
			cates.append((entry[0], mat[0]))

	for entry in cates:
		item = xbmcgui.ListItem("[COLOR yellow][B]%s[/B]%s[/COLOR]" % (entry[0], entry[1]))
		item.setArt({"poster": defaultPic})
		item_url = "%s?mode=search&key=%s&channel=%s&change=cate&catetitle=%s&catevalue=%s&url=%s" % (addon_url, key, channel, entry[0], entry[1], url)
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

	# 显示排序
	regex = re.compile(' <a class="link_sear_select selected" href="#" title="(.+?)"', re.DOTALL)
	match = regex.findall(httpData)
	if len(match)>0:
		item = xbmcgui.ListItem("[COLOR yellow][B]排序：[/B]%s[/COLOR]" % match[0])
		item.setArt({"poster": defaultPic})
		item_url = "%s?mode=search&key=%s&channel=%s&change=sort&cursort=%s&url=%s" % (addon_url, key, channel, match[0], url)
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

	# 显示视频
	regex = re.compile('<li class="list_item(.+?)>(.+?)</div>[ \n\r]*?</div>[ \n\r]*?</div>[ \n\r]*?</li>', re.DOTALL)
	match = regex.findall(httpData)

	items = []
	for entry in match:
		if "data-widget-aladdinpattern" in entry[1] or '<p class="viedo_rt "><span class="icon-live">直播中</span></p>' in entry[1]: continue # 文学/直播不显示
		elif "data-widget-intentrecognition" in entry[1]: # 意图识别标题
			reg = re.compile('<li class="intent-item-twoline(.+?)title="(.+?)".*?href *= *"(.+?)".*?src *= *"(.+?)"(.+?)</div>', re.DOTALL)
			mat = reg.findall(entry[1])
			for ent in mat:
				vInfo = ""
				regi = re.compile('<span class="icon-vInfo">(.+?)</span>', re.DOTALL)
				mati = regi.findall(ent[4])
				if len(mati)>0: vInfo = mati[0].strip()

				label = ent[1]
				if "http:" in ent[3]: thumb = ent[3]
				else: thumb = "http:%s" % ent[3]
				fanart = thumb.replace("_180_236.jpg", "_720_405.jpg")
				if fanart == thumb: fanart = None
				video_url = ent[2]

				regi = re.compile('data-widget-searchlist-albumid="(.+?)"', re.DOTALL)
				mati = regi.findall(ent[0])
				albumid = mati[0]

				infoLabels = {}
				infoLabels["plot"] = ""
				if vInfo != "": infoLabels["plot"] += "[B]集数 / 片长：[/B]"+vInfo+"\n"

				items.append((label, thumb, fanart, video_url, albumid, infoLabels))

		elif "<!--专辑（单）:singleEpisode-->" in entry[1] or "<!--专辑（多）:multiEpisode-->" in entry[1] or "<!--video-->" in entry[1]: # 专辑（单）:singleEpisode 或 专辑（多）:multiEpisode
			reg = re.compile('<a class="figure(.+?)href="(.+?)".*?title="(.+?)".*?src="(.+?)"(.+?)</div>', re.DOTALL)
			mat = reg.findall(entry[1])

			vInfo = ""
			regi = re.compile('<span class="icon-vInfo">(.+?)</span>', re.DOTALL)
			mati = regi.findall(mat[0][4])
			if len(mati)>0: vInfo = mati[0].strip()

			label = mat[0][2]
			if "http:" in mat[0][3]: thumb = mat[0][3]
			else: thumb = "http:%s" % mat[0][3]
			fanart = thumb.replace("_180_236.jpg", "_720_405.jpg")
			if fanart == thumb: fanart = None
			video_url = mat[0][1]

			albumid = "0"
			regi = re.compile('data-qidanadd-albumid="(.+?)"', re.DOTALL)
			mati = regi.findall(mat[0][0])
			if len(mati)>0: albumid = mati[0]

			infoLabels = {}
			infoLabels["plot"] = ""

			reg = re.compile('data-searchpingback-param="ptype=2-2".*?">(.+?)</a>', re.DOTALL)
			mat = reg.findall(entry[1])
			if len(mat)>0: infoLabels["plot"] += "[B]导演：[/B]"+mat[0]+"\n"

			reg = re.compile('data-searchpingback-param="ptype=2-1".*?">(.+?)</a>', re.DOTALL)
			mat = reg.findall(entry[1])
			if len(mat)>0: infoLabels["plot"] += "[B]主演：[/B]"+" / ".join(mat)+"\n"

			reg = re.compile('result_info_lbl">地区:.*?<span>(.+?)</span>', re.DOTALL)
			mat = reg.findall(entry[1])
			if len(mat)>0: infoLabels["plot"] += "[B]地区：[/B]"+mat[0].strip()+"\n"

			reg = re.compile('result_info_lbl">上映时间:.*?<span>(.+?)</span>', re.DOTALL)
			mat = reg.findall(entry[1])
			if len(mat)>0: infoLabels["plot"] += "[B]上映：[/B]"+mat[0].strip()+"\n"

			reg = re.compile('result_info_lbl">发布时间:.*?<em class="result_info_desc">(.+?)</em>', re.DOTALL)
			mat = reg.findall(entry[1])
			if len(mat)>0: infoLabels["plot"] += "[B]发布：[/B]"+mat[0]+"\n"

			reg = re.compile('result_info_lbl">来源:.*?<em class="result_info_desc">(.+?)</em>', re.DOTALL)
			mat = reg.findall(entry[1])
			if len(mat)>0: infoLabels["plot"] += "[B]来源：[/B]"+mat[0]+"\n"

			if vInfo != "": infoLabels["plot"] += "[B]集数 / 片长：[/B]"+vInfo+"\n"

			reg = re.compile('result_info_lbl">简介:.*?<span class="result_info_txt">(.+?)</span>', re.DOTALL)
			mat = reg.findall(entry[1])
			if len(mat)>0: infoLabels["plot"] += "[B]简介：[/B]"+HTMLParser.HTMLParser().unescape(mat[0]).strip()+"\n"

			reg = re.compile('data-detailinfo-elem="abstractinfo">(.+?)</span>', re.DOTALL)
			mat = reg.findall(entry[1])
			if len(mat)>0: infoLabels["plot"] += "[B]简介：[/B]"+mat[0]+"\n"

			items.append((label, thumb, fanart, video_url, albumid, infoLabels))

		elif "<!--star-->" in entry[1] or "<!--ugcVerifiedUser-->" in entry[1] or "<!-- 倒计时 -->" in entry[1]: # star 或 ugcVerifiedUser 或 onetree空资料页
			reg = re.compile('<a class="preview_figure.*?href="(.+?)".*?src="(.+?)".*?alt="(.+?)"(.+?)</p>(.+?)</li>', re.DOTALL)
			mat = reg.findall(entry[1])
			for ent in mat:
				vInfo = ""
				regi = re.compile('<span class="icon-vInfo">(.+?)</span>', re.DOTALL)
				mati = regi.findall(ent[3])
				if len(mati)>0: vInfo = mati[0].strip()

				label = ent[2]
				if "http:" in ent[1]: thumb = ent[1]
				else: thumb = "http:%s" % ent[1]
				fanart = thumb.replace("_180_236.jpg", "_720_405.jpg")
				if fanart == thumb: fanart = None
				video_url = ent[0]
				albumid = "0"

				infoLabels = {}
				infoLabels["plot"] = ""

				regi = re.compile('<em>饰演:(.+?)</em>', re.DOTALL)
				mati = regi.findall(ent[4])
				if len(mati)>0: infoLabels["plot"] += "[B]饰演：[/B]"+mati[0]+"\n"

				if vInfo != "": infoLabels["plot"] += "[B]集数 / 片长：[/B]"+vInfo+"\n"

				items.append((label, thumb, fanart, video_url, albumid, infoLabels))

		elif "<!--播单-->" in entry[1] or "<!--multiEpisodeWithDetail-->" in entry[1] or "<!--zongYi-->" in entry[1]: # 播单 或 multiEpisodeWithDetail 或 zongyi
			reg = re.compile('data-widget-searchlist-albumid="(.+?)"', re.DOTALL)
			mat = reg.findall(entry[0])
			albumid = mat[0]

			reg = re.compile('class="figure.*?href.*?"(.+?)".*?alt="(.+?)".*?src="(.+?)"', re.DOTALL)
			mat = reg.findall(entry[1])
			video_url = mat[0][0]
			label = mat[0][1]
			if "http:" in mat[0][2]: thumb = mat[0][2]
			else: thumb = "http:%s" % mat[0][2]
			fanart = thumb.replace("_180_236.jpg", "_720_405.jpg")
			if fanart == thumb: fanart = None

			infoLabels = {}
			infoLabels["plot"] = ""

			reg = re.compile('result_info_lbl">简介:.*?<span class="result_info_txt">(.+?)</span>', re.DOTALL)
			mat = reg.findall(entry[1])
			if len(mat)>0: infoLabels["plot"] += "[B]简介：[/B]"+HTMLParser.HTMLParser().unescape(mat[0]).strip()+"\n"

			items.append((label, thumb, fanart, video_url, albumid, infoLabels))

			reg = re.compile('<li class="album_item.*?href="([^"]+?)"[ \n\r]*?data-pb.*?title="(.+?)" data-tvlist-elem', re.DOTALL)
			mat = reg.findall(entry[1])
			for ent in mat:
				label = ent[1]
				video_url = ent[0]
				albumid = "0"

				items.append((label, thumb, fanart, video_url, albumid, infoLabels))

		else: xbmcgui.Dialog().ok(__addonname__, "当前搜索类型未知 %s" % entry[0])

	for entry in items:
		item = xbmcgui.ListItem(HTMLParser.HTMLParser().unescape(entry[0]))
		item.setArt({"thumb": entry[1], "fanart": entry[2]})
		item.setInfo("video", entry[5])
		if entry[3][7:9] == "so": continue # 外网不显示
		elif entry[3][21:29] == "playlist": # 播单
			item_url = "%s?mode=playlist&bodanid=%s&bodanname=%s" % (addon_url, entry[4], entry[0])
			xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)
		elif entry[3][21:23] == "a_" or entry[3][21:24] == "lib": # 专辑
			item_url = "%s?mode=series&albumid=%s" % (addon_url, entry[4])
			xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)
		else: # 单集
			item_url = "%s?mode=play&url=%s&label=%s&thumb=%s" % (addon_url, entry[3], entry[0], entry[1])
			addContextMenu(item, entry[3], entry[0], entry[2])
			xbmcplugin.addDirectoryItem(pHandle, item_url, item, False)

	# 显示页数
	curPage = ""
	regex = re.compile('<div class="mod-page" data-search-wrap="page.*?class="curPage">(\d+?)</span>', re.DOTALL)
	match = regex.findall(httpData)
	if len(match)>0:
		curPage = match[0]
		item = xbmcgui.ListItem("[COLOR yellow][B]页数：[/B]第%s页[/COLOR]" % curPage)
		item.setArt({"poster": defaultPic})
		item_url = "%s?mode=search&key=%s&channel=%s&change=page&curpage=%s&url=%s" % (addon_url, key, channel, curPage, url)
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)
		curPage = " 第%s页" % curPage

	# 设置内容 及 视图
	xbmcplugin.setContent(pHandle, "albums")
	xbmc.executebuiltin("container.SetViewMode(%d)" % viewSetting)
	xbmcplugin.setPluginCategory(pHandle, key+curPage)
	xbmcplugin.endOfDirectory(pHandle)

def showPlaylist():
	pageSize = 40
	bodanid = params.get("bodanid")
	change = params.get("change")
	if change == None: # 首次进入
		curPage = 1
	else: # 改变页数
		curPage = int(params.get("curPage"))
		totalPage = int(params.get("totalPage"))
		pageList = []
		if curPage>1: pageList.append("上一页")
		for i in range(1, totalPage+1): 
			if i == curPage: pageList.append("[%d]" % i)
			else: pageList.append(str(i))
		if curPage<totalPage: pageList.append("下一页")

		select = xbmcgui.Dialog().select("改变页数", pageList)
		if select == -1 or pageList[select] == "[%d]" % curPage: return
		if pageList[select] == "上一页": curPage = curPage-1
		elif pageList[select] == "下一页": curPage = curPage+1
		else: curPage = int(pageList[select])

	url = "http://pcw-api.iqiyi.com/album/bodan/bodanlistinfo?bodanId=%s&page=%d&size=%d" % (bodanid, curPage,pageSize)
	httpData = getHttpData(url)
	if httpData == None: return

	bodanInfo = simplejson.loads(httpData.replace("\n", "").replace("\r", "").replace("　", ""))
	playList = bodanInfo["data"]["playList"]
	for entry in playList: # 显示视频
		if entry.get("playUrl") != None: playUrl = entry.get("playUrl")
		else: playUrl = entry.get("albumUrl")

		label = entry["name"]
		if entry.get("payMark"): label = "[COLOR red]%s[/COLOR]" % label # 付费

		thumb = entry["imageUrl"]
		fanart = entry["imageUrl"].replace(".jpg", "_720_405.jpg")

		infoLabels = {}
		infoLabels["plot"] = ""

		if entry.get("focus"): infoLabels["tagline"] = entry["focus"]
		if entry.get("score"): infoLabels["plot"] += "[B]评分：[/B]"+str(entry["score"])+"\n"
		if entry.get("people"):
			if entry.get("people").get("director"):
				director = [ent["name"] for ent in entry["people"]["director"]]
				infoLabels["plot"] += "[B]导演：[/B]"+" / ".join(director)+"\n"
			if entry.get("people").get("main_charactor"):
				charactor = [ent["name"] for ent in entry["people"]["main_charactor"]]
				infoLabels["plot"] += "[B]主演：[/B]"+" / ".join(charactor)+"\n"
		if entry.get("period"): infoLabels["plot"] += "[B]上映：[/B]"+entry["period"]+"\n"
		if entry.get("duration"): infoLabels["plot"] += "[B]片长：[/B]"+entry["duration"]+"\n"
		if entry.get("description"): infoLabels["plot"] += "[B]简介：[/B]"+entry["description"]+"\n"

		item = xbmcgui.ListItem(HTMLParser.HTMLParser().unescape(label))
		item.setArt({"thumb": thumb, "fanart": fanart})
		item.setInfo("video", infoLabels)
		item_url = "%s?mode=play&url=%s&label=%s&thumb=%s" % (addon_url, playUrl, label, thumb)
		addContextMenu(item, playUrl, label, fanart)
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, False)

	# 显示页数
	bodanName = params.get("bodanname")
	totalCount = bodanInfo["data"]["totalCount"]
	totalPage = int((totalCount+pageSize-1)/pageSize)
	if totalPage>1:
		item = xbmcgui.ListItem("[COLOR yellow][B]页数：[/B]第%d页[/COLOR]" % curPage)
		item.setArt({"poster": defaultPic})
		item_url = "%s?mode=playlist&change=page&totalPage=%d&curPage=%d&bodanid=%s&bodanname=%s" % (addon_url, totalPage, curPage, bodanid, bodanName)
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)
		curPage = " 第%d页" % curPage
	else: curPage = ""

	# 设置内容 及 视图
	xbmcplugin.setContent(pHandle, "videos")
	xbmc.executebuiltin("container.SetViewMode(%d)" % 55)
	xbmcplugin.setPluginCategory(pHandle, bodanName+curPage)
	xbmcplugin.endOfDirectory(pHandle)

def showSeries():
	# 获取专辑信息
	albumid = int(params.get("albumid"))
	url = "http://cache.video.iqiyi.com/a/%d" % albumid
	httpData = getHttpData(url)
	if httpData == None: return

	albumInfo = simplejson.loads(httpData[httpData.find("=")+1:].replace("\n", "").replace("\r", "").replace("　", ""))
	if albumInfo["code"] != "A00000":
		xbmcgui.Dialog().ok(__addonname__, "当前专辑无法播放 %s" % albumInfo["code"])
		return

	albumData = albumInfo["data"]
	sourceid = albumData["sourceId"]
	if sourceid == 0: # 连续剧等
		viewMode = viewSetting
		p = params.get("p")
		if p == None: # 首次进入
			url = "http://cache.video.iqiyi.com/avlist/%s/" % albumid
		else: # 改变页数
			p = int(p)
			curPage = int(params.get("curPage"))
			totalPage = int(params.get("totalPage"))
			pageList = []
			if curPage>1: pageList.append("上一页")
			for i in range(1, totalPage+1): 
				if i == curPage: pageList.append("[%d]" % i)
				else: pageList.append(str(i))
			if curPage<totalPage: pageList.append("下一页")

			select = xbmcgui.Dialog().select("改变页数", pageList)
			if select == -1 or pageList[select] == "[%d]" % curPage: return
			if pageList[select] == "上一页": nextPage = curPage-1
			elif pageList[select] == "下一页": nextPage = curPage+1
			else: nextPage = int(pageList[select])
			url = "http://cache.video.iqiyi.com/avlist/%s/%d/" % (albumid, nextPage+p-1)

		httpData = getHttpData(url)
		if httpData == None: return

		# 调整页数
		videoList = simplejson.loads(httpData[httpData.find("=")+1:].replace("\n", "").replace("\r", "").replace("　", ""))
		if p == None: p = 1
		totalPage = videoList["data"]["pgt"]
		while p<totalPage and len(videoList["data"]["vlist"]) == 0:
			p += 1
			url = "http://cache.video.iqiyi.com/avlist/%s/%d/" % (albumid, p)
			httpData = getHttpData(url)
			if httpData == None: return

			videoList = simplejson.loads(httpData[httpData.find("=")+1:].replace("\n", "").replace("\r", "").replace("　", ""))

		# 显示视频
		for entry in videoList["data"]["vlist"]:
			playUrl = entry.get("vurl")
			thumb = entry["vpic"]

			if entry["vt"] in entry["vn"]: label = entry["vn"]
			else: label = "%s %s" % (entry["vn"], entry["vt"])
			if entry["payMark"] != 0: label = "[COLOR red]%s[/COLOR]" % label #付费

			infoLabels = {}
			infoLabels["plot"] = ""
			if entry.get("publishTime"): infoLabels["plot"] += "[B]上映：[/B]"+formatTime(entry["publishTime"])+"\n"
			if entry.get("timeLength"): infoLabels["plot"] += "[B]片长：[/B]"+formatSec(entry["timeLength"])+"\n"

			item = xbmcgui.ListItem(HTMLParser.HTMLParser().unescape(label))
			item.setArt({"thumb": thumb})
			item.setInfo("video", infoLabels)
			item_url = "%s?mode=play&url=%s&label=%s&thumb=%s" % (addon_url, playUrl, label, thumb)
			addContextMenu(item, playUrl, label, thumb)
			xbmcplugin.addDirectoryItem(pHandle, item_url, item, False)

		# 显示页数
		cateStr = ""
		if totalPage>1:
			curPage = int(videoList["data"]["pg"])-p+1
			item = xbmcgui.ListItem("[COLOR yellow][B]页数：[/B]第%d页[/COLOR]" % curPage)
			item.setArt({"poster": defaultPic})
			item_url = "%s?mode=series&totalPage=%d&curPage=%d&p=%d&albumid=%s" % (addon_url, totalPage-p+1, curPage, p, albumid)
			xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)
			cateStr = " 第%d页" % curPage

	else: # 综艺等 无翻页
		viewMode = 55
		albumType = albumInfo["data"]["albumType"]
		curYear = params.get("curyear")
		curMonth = params.get("curmonth")
		hasAll = params.get("hasall")
		if curYear == None: # 首次进入
			curYear = "全部"
			url = "http://cache.video.qiyi.com/sdvlst/%d/%d/" % (albumType, sourceid)
		else:
			url = "http://cache.video.iqiyi.com/sdlst/%d/%d/" % (albumType, sourceid)
			httpData = getHttpData(url)
			if httpData == None: return

			timeInfo = simplejson.loads(httpData[httpData.find("=")+1:].replace("\n", "").replace("\r", "").replace("　", ""))
			if curMonth == None: # 改变年份
				yearList = timeInfo["data"].keys()
				if hasAll == "True": yearList.append("全部")
				yearList.sort(reverse=True)

				select = xbmcgui.Dialog().select("改变年份", createSelect(yearList, -1, curYear))
				if select == -1 or yearList[select] == curYear: return
				curYear = yearList[select]
				if curYear == "全部":
					url = "http://cache.video.iqiyi.com/sdvlst/%d/%d/" % (albumType, sourceid)
				else:
					curMonth = "全部"
					url = "http://cache.video.iqiyi.com/sdvlst/%d/%d/%s/" % (albumType, sourceid, curYear)

			else: # 改变月份
				monthList = timeInfo["data"][curYear]
				if hasAll == "True": monthList.append("全部")
				monthList.sort(reverse=True)

				select = xbmcgui.Dialog().select("改变月份", createSelect(monthList, -1, curMonth))
				if select == -1 or monthList[select] == curMonth: return
				curMonth = monthList[select]
				if curMonth == "全部":
					url = "http://cache.video.iqiyi.com/sdvlst/%d/%d/%s/" % (albumType, sourceid, curYear)
				else:
					url = "http://cache.video.iqiyi.com/sdvlst/%d/%d/%s%s/" % (albumType, sourceid, curYear, curMonth)

		httpData = getHttpData(url)
		if httpData == None: return

		tvInfo = simplejson.loads(httpData[httpData.find("=")+1:].replace("\n", "").replace("\r", "").replace("　", ""))
		if tvInfo["code"] != "A00000": # 使用最近年份和月份
			url = "http://cache.video.iqiyi.com/sdlst/%d/%d/" % (albumType, sourceid)
			httpData = getHttpData(url)
			if httpData == None: return

			timeInfo = simplejson.loads(httpData[httpData.find("=")+1:].replace("\n", "").replace("\r", "").replace("　", ""))
			yearList = timeInfo["data"].keys()
			yearList.sort(reverse=True)
			curYear = yearList[0]

			monthList = timeInfo["data"][curYear]
			monthList.sort(reverse=True)
			curMonth = monthList[0]

			url = "http://cache.video.iqiyi.com/sdvlst/%d/%d/%s%s/" % (albumType, sourceid, curYear, curMonth)
			httpData = getHttpData(url)
			if httpData == None: return

			tvInfo = simplejson.loads(httpData[httpData.find("=")+1:].replace("\n", "").replace("\r", "").replace("　", ""))
			if tvInfo["code"] != "A00000":
				xbmcgui.Dialog().ok(__addonname__, "当前专辑无法播放 %s" % tvInfo["code"])
				return

			hasAll = "False"

		# 显示年份
		cateStr = ""
		if curYear != "全部" or curYear == "全部" and len(tvInfo["data"]) == 120:
			if curYear == "全部": yearLabel = "全部"
			else:
				yearLabel = curYear + "年"
				cateStr += " "
				cateStr += yearLabel
			item = xbmcgui.ListItem("[COLOR yellow][B]年份：[/B]%s[/COLOR]" % yearLabel)
			item.setArt({"poster": defaultPic})
			item_url = "%s?mode=series&curyear=%s&hasall=%s&albumid=%s" % (addon_url, curYear, hasAll, albumid)
			xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

		# 显示月份
		if curMonth != None:
			if curMonth != "全部" or curMonth == "全部" and len(tvInfo["data"]) == 120:
				if curMonth == "全部": monthLabel = "全部"
				else:
					monthLabel = str(int(curMonth)) + "月"
					cateStr += monthLabel
				item = xbmcgui.ListItem("[COLOR yellow][B]月份：[/B]%s[/COLOR]" % monthLabel)
				item.setArt({"poster": defaultPic})
				item_url = "%s?mode=series&curyear=%s&curmonth=%s&hasall=%s&albumid=%s" % (addon_url, curYear, curMonth, hasAll, albumid)
				xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

		# 显示视频
		for entry in tvInfo["data"]:
			playUrl = entry.get("vUrl")
			thumb = entry["tvPicUrl"]
			fanart = entry["tvPicUrl"].replace(".jpg", "_720_405.jpg")

			label = entry["tvYear"]+" "+entry["sName"]+" "+entry["shortTitle"]
			if entry["payMark"] != 0: label = "[COLOR red]%s[/COLOR]" % label #付费

			infoLabels = {}
			infoLabels["plot"] = ""
			if entry.get("tvFocus"): infoLabels["tagline"] = entry["tvFocus"]
			if entry.get("mActor"): infoLabels["plot"] += "[B]主演：[/B]"+entry["mActor"].replace(",", " / ")+"\n"
			if entry.get("tvYear"): infoLabels["plot"] += "[B]上映：[/B]"+entry["tvYear"]+"\n"
			if entry.get("timeLength"): infoLabels["plot"] += "[B]片长：[/B]"+formatSec(entry["timeLength"])+"\n"
			if entry.get("desc"): infoLabels["plot"] += "[B]简介：[/B]"+entry["desc"]+"\n"

			item = xbmcgui.ListItem(HTMLParser.HTMLParser().unescape(label))
			item.setArt({"thumb": thumb, "fanart": fanart})
			item.setInfo("video", infoLabels)
			item_url = "%s?mode=play&url=%s&label=%s&thumb=%s" % (addon_url, playUrl, label, thumb)
			addContextMenu(item, playUrl, label, fanart)
			xbmcplugin.addDirectoryItem(pHandle, item_url, item, False)

		curCate = ""

	# 设置内容 及 视图
	xbmcplugin.setContent(pHandle, "videos")
	xbmc.executebuiltin("container.SetViewMode(%d)" % viewMode)
	xbmcplugin.setPluginCategory(pHandle, albumInfo["data"]["tvName"]+cateStr)
	xbmcplugin.endOfDirectory(pHandle)

def showHistory():
	# 读取历史记录
	dataDir = getDataDir()
	filePath = os.path.join(dataDir, "history.log")
	historyList = []
	if os.path.exists(filePath):
		fHandle = open(filePath, "r")
		try:
			historyList = simplejson.load(fHandle)
		except simplejson.scanner.JSONDecodeError, e:
			xbmcgui.Dialog().ok(__addonname__, "历史记录为空或格式有误 %s" % str(e))
			pass
		fHandle.close()

	pageSize = 40
	totalPage = int((len(historyList)+pageSize-1)/pageSize)

	change = params.get("change")
	if change == None:  # 首次进入
		curPage = 1

	elif change == "page": # 改变页数
		curPage = int(params.get("curPage"))
		pageList = []
		if curPage>1: pageList.append("上一页")
		for i in range(1, totalPage+1): 
			if i == curPage: pageList.append("[%d]" % i)
			else: pageList.append(str(i))
		if curPage<totalPage: pageList.append("下一页")

		select = xbmcgui.Dialog().select("改变页数", pageList)
		if select == -1 or pageList[select] == "[%d]" % curPage: return
		if pageList[select] == "上一页": curPage = curPage-1
		elif pageList[select] == "下一页": curPage = curPage+1
		else: curPage = int(pageList[select])

	elif change == "refresh": # 刷新列表
		curPage = int(params.get("curPage"))

	# 显示视频
	videoList = historyList[(curPage-1)*pageSize: min(curPage*pageSize, len(historyList))]
	for i, entry in enumerate(videoList):
		try:
			if entry["interface"] == "": item = xbmcgui.ListItem(HTMLParser.HTMLParser().unescape(entry["label"]))
			else: item = xbmcgui.ListItem(HTMLParser.HTMLParser().unescape("%s<%s>" % (entry["label"], entry["interface"])))
			item.setArt({"thumb": entry["thumb"]})
			item.addContextMenuItems([("删除单条记录", "RunPlugin(%s?mode=delete&index=%d&curPage=%d)" % (addon_url, i+(curPage-1)*pageSize, curPage-int(len(videoList)==1 and totalPage!=1)))])
			if entry["interface"] == "": item_url = "%s?mode=play&url=%s&label=%s&thumb=%s&curPage=%d" % (addon_url, entry["url"], entry["label"], entry["thumb"], curPage)
			else: item_url = "%s?mode=call&interface=%s&url=%s&label=%s&thumb=%s&curPage=%d" % (addon_url, entry["interface"], entry["url"], entry["label"], entry["thumb"], curPage)
			xbmcplugin.addDirectoryItem(pHandle, item_url, item, False)
		except KeyError, e:
			xbmcgui.Dialog().ok(__addonname__, "历史记录格式有误 %s" % str(e))
			continue

	# 显示页数
	if totalPage>1:
		item = xbmcgui.ListItem("[COLOR yellow][B]页数：[/B]第%d页[/COLOR]" % curPage)
		item.setArt({"poster": defaultPic})
		item_url = "%s?mode=history&change=page&curPage=%d" % (addon_url, curPage)
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)
		curPage = " 第%d页" % curPage
	else: curPage = ""

	# 设置内容 及 视图
	xbmcplugin.setContent(pHandle, "videos")
	xbmc.executebuiltin("container.SetViewMode(%d)" % 500)
	xbmcplugin.setPluginCategory(pHandle, "历史记录"+curPage)
	xbmcplugin.endOfDirectory(pHandle)

def callInterface():
	interfaceName = params.get("interface")
	url = params.get("url")
	label = params.get("label")
	thumb = params.get("thumb")

	label = re.sub("\[COLOR red\]", "", label)
	label = re.sub("\[/COLOR\]", "", label)

	dataDir = getDataDir()
	historyPath = os.path.join(dataDir, "history.log")
	interfacePath = os.path.join(dataDir, "interface", interfaceName+".py")
	if not os.path.exists(interfacePath):
		xbmcgui.Dialog().ok(__addonname__, "解析接口文件 [%s] 不存在" % os.path.basename(interfacePath))
		return

	xbmc.executebuiltin("RunScript(%s,%s,%s,%s,%s)" % (interfacePath, historyPath, url, label, thumb)) # 调用接口

def playVideo():
	url = params.get("url")
	label = params.get("label")
	#thumb = params.get("thumb")

	# 获取视频基本信息
	httpData = getHttpData(url)
	if httpData == None: return

	regex = re.compile('<head itemprop="video"', re.DOTALL)
	match = regex.search(httpData)
	if match == None: # 网页动态生成
		reg = re.compile('<div class="cms-qipuId" data-qipuId="(.+?)"', re.DOTALL)
		mat = reg.findall(httpData)
		if len(mat) == 0:
			xbmcgui.Dialog().ok(__addonname__, "无法获取视频信息 %s" % url)
			return
		url = "http://www.iqiyi.com/v_%s.html" % mat[0]
		httpData = getHttpData(url)
		if httpData == None: return

	regex = re.compile('data-player-tvid="(.+?)" data-player-videoid="(.+?)"', re.DOTALL)
	match = regex.findall(httpData)
	if len(match) == 0:
		xbmcgui.Dialog().ok(__addonname__, "无法获取视频信息 %s" % url)
		return
	tvid = match[0][0]
	videoid = match[0][1]

	thumb = ""
	infoLabels = {"plot": ""}
	regex = re.compile('<script type="application/ld\\+json">.*?"description": "(.*?)",\s*"thumbnailUrl":"(.*?)".*?</script>', re.DOTALL)
	match = regex.findall(httpData)
	if len(match)>0:
		thumb = "http:" + match[0][1]
		infoLabels["plot"] = match[0][0].replace("\n", "").replace("\r", "").replace("　", "")

	# 获取视频播放信息
	t = int(time.time() * 1000)
	src = "76f90cbd92f94a2e925d83e8ccd22cb7"
	key = "d5fb4bd9d50c4be6948c97edd7254b0e"
	sc = hashlib.md5(str(t)+key+videoid).hexdigest()
	cache_url = "http://cache.m.iqiyi.com/tmts/{0}/{1}/?t={2}&sc={3}&src={4}".format(tvid,videoid,t,sc,src)
	httpData = getHttpData(cache_url)
	if httpData == None: return

	playInfo = simplejson.loads(httpData.replace("\n", "").replace("\r", "").replace("　", ""))

	# 选择不同清晰度的视频地址并播放
	if playInfo["code"] != "A00000":
		xbmcgui.Dialog().ok(__addonname__, "当前视频无法播放 %s" % playInfo["code"])
		return

	VRList = []
	videoLink = playInfo["data"]["vidl"]
	for i, entry in enumerate(videoLink):
		screenSize = entry.get("screenSize")
		fileFormat = entry.get("fileFormat")
		if fileFormat == None: VRList.append([screenSize, i])
		else: VRList.append([screenSize+" "+fileFormat, i])

	VRList.sort(key=sort_key, reverse=True)
	resolution = __addon__.getSetting("resolution")
	if resolution == "0": #每次询问
		selectList = [entry[0] for entry in VRList]
		select = xbmcgui.Dialog().select("选择清晰度", selectList)
		if select == -1: return
		index = VRList[select][1]
	elif resolution == "1": index = VRList[0][1] # 画质优先
	elif resolution == "2": index = VRList[-1][1] # 速度优先

	m3u = videoLink[index]["m3u"]
	item = xbmcgui.ListItem(HTMLParser.HTMLParser().unescape(label))
	item.setArt({"thumb": thumb})
	item.setInfo("video", infoLabels)
	xbmc.Player().play(m3u, item) # 播放视频
	saveHistory({"interface": "", "url": url, "label": label, "thumb": thumb}) # 保存历史

# 主程序
addon_url = sys.argv[0]
if sys.argv[1] == "clear": mode = "clear"
elif sys.argv[1] == "manage": mode = "manage"
else:
	pHandle = int(sys.argv[1])
	params = dict(urlparse.parse_qsl(urllib.unquote_plus(sys.argv[2][1:])))
	mode = params.get("mode")

defaultPic = os.path.join(getAddonDir(), "media", "default.png")

viewtype = __addon__.getSetting("viewtype")
if viewtype == "0": viewSetting = 54 # 信息墙
elif viewtype == "1": viewSetting = 500 # 海报墙
elif viewtype == "2": viewSetting = 55 # 宽列表

# 导航
if mode == None:
	showRoot()

# 列表
elif mode == "list":
	showList()

# 专题
elif mode == "topic":
	showTopic()

# 内容
elif mode == "content":
	showContent()

# 热搜
elif mode == "hot":
	showHot()

# 搜索
elif mode == "search":
	showSearch()

# 播单
elif mode == "playlist":
	showPlaylist()

# 专辑
elif mode == "series":
	showSeries()

# 历史
elif mode == "history":
	showHistory()

# 解析
elif mode == "call":
	callInterface()

# 播放
elif mode == "play":
	playVideo()

# 删除单条记录
elif mode == "delete":
	deleteHistory()

# 清除历史记录
elif mode == "clear":
	clearHistory()

# 管理解析接口
elif mode == "manage":
	manageInterface()