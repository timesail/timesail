﻿# -*- coding: utf-8 -*-
import xbmc, xbmcgui, xbmcplugin, xbmcaddon
import urllib, urlparse, re, sys, os, hashlib, time, HTMLParser
import simplejson

# 编码
if sys.getdefaultencoding() != 'utf-8':
	reload(sys)
	sys.setdefaultencoding('utf-8')

# 常数
__addonname__ = 'KiWi视频'
__addonid__   = 'plugin.video.kiwi'
__addon__     = xbmcaddon.Addon(id=__addonid__)

# 函数
def logData(data, filePath='C:\Users\Administrator\Desktop\%s.txt' % __addonname__):
	filePath = filePath.decode('utf-8')
	fHandle = open(filePath, 'w')
	fHandle.write(data)
	fHandle.close()

def dialog(str, type='ok'):
	if type == 'ok': xbmcgui.Dialog().ok(__addonname__, str)
	elif type == 'textviewer': xbmcgui.Dialog().textviewer(__addonname__, str)

def saveHistory(history):
	dataDir = getDataDir()
	filePath = os.path.join(dataDir, 'history.log')
	if not os.path.exists(filePath): # 文件不存在则创建文件
		fHandle = open(filePath, 'w')
		historyList = [history]

	else: # 文件存在则读取文件
		try:
			fHandle = open(filePath, 'r+')
			historyList = simplejson.load(fHandle)
			if history in historyList: historyList.remove(history)
			historyList.insert(0, history)
			fHandle.seek(0, 0)
		except simplejson.scanner.JSONDecodeError: # 文件非json格式则重新创建文件
			fHandle = open(filePath, 'w')
			historyList = [history]
			pass

	simplejson.dump(historyList, fHandle, ensure_ascii=False)
	fHandle.close()

def deleteHistory():
	dataDir = getDataDir()
	filePath = os.path.join(dataDir, 'history.log')
	if os.path.exists(filePath):
		fHandle = open(filePath, 'r+')
		try:
			historyList = simplejson.load(fHandle)
			index = int(params.get('index'))
			if xbmcgui.Dialog().yesno(__addonname__, '确定要删除历史记录 [%s] 吗' % historyList[index]['label']):
				historyList.pop(index)
				fHandle.seek(0, 0)
				fHandle.truncate()
				simplejson.dump(historyList, fHandle, ensure_ascii=False)

				page = params.get('curpage')
				xbmc.executebuiltin('Container.Update(%s,replace)' % createUrl({'mode': 'history', 'change': 'refresh', 'curpage': page}))

		except simplejson.scanner.JSONDecodeError:
			if xbmcgui.Dialog().yesno(__addonname__, '历史记录为空或格式有误，是否清除'):
				os.remove(filePath)
				xbmc.executebuiltin('Container.Update(%s,replace)' % createUrl({'mode': 'history'}))

	else: xbmcgui.Dialog().ok(__addonname__, '历史记录不存在')
	fHandle.close()

def clearHistory():
	dataDir = getDataDir()
	filePath = os.path.join(dataDir, 'history.log')
	if os.path.exists(filePath):
		fHandle = open(filePath, 'r')
		try:
			historyList = simplejson.load(fHandle)
			fHandle.close()
			if xbmcgui.Dialog().yesno(__addonname__, '历史记录共%d条，是否清除' % len(historyList)):
				os.remove(filePath)
				xbmc.executebuiltin('Container.Update(%s,replace)' % createUrl({'mode': 'history'}))

		except simplejson.scanner.JSONDecodeError:
			fHandle.close()
			if xbmcgui.Dialog().yesno(__addonname__, '历史记录为空或格式有误，是否清除'):
				os.remove(filePath)
				xbmc.executebuiltin('Container.Update(%s,replace)' % createUrl({'mode': 'history'}))

	else: xbmcgui.Dialog().ok(__addonname__, '历史记录不存在')

def getDataDir():
	dataDir = xbmc.translatePath( __addon__.getAddonInfo('profile')).decode('utf-8')
	if not os.path.exists(dataDir): os.makedirs(dataDir)
	return dataDir

def getAddonDir():
	addonDir = xbmc.translatePath( __addon__.getAddonInfo('path')).decode('utf-8')
	return addonDir

def getHttpData(url):
	import urllib2
	request = urllib2.Request(url)
	request.add_header('User-Agent', 'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0)')

	maxtimes = 10
	for t in range(maxtimes):
		try:
			response = urllib2.urlopen(request)
			httpData = response.read()
			break
		except Exception, e:
			if '11004' in str(e):
				if t<maxtimes-1: continue
				else: xbmcgui.Dialog().ok(__addonname__, '网络错误 %s %s %d次' % (url, str(e), maxtimes))
			else: xbmcgui.Dialog().ok(__addonname__, '网络错误 %s %s' % (url, str(e)))
			return

	if response.headers.get('content-encoding', None) == 'gzip':
		import zlib
		httpData = zlib.decompress(httpData, zlib.MAX_WBITS|32)

	response.close()
	return httpData

def postHttpData(url, data):
	import urllib2
	request = urllib2.Request(url, urllib.urlencode(data))
	request.add_header('User-Agent', 'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0)')

	maxtimes = 10
	for t in range(maxtimes):
		try:
			response = urllib2.urlopen(request)
			httpData = response.read()
			break
		except Exception, e:
			if '11004' in str(e):
				if t<maxtimes-1: continue
				else: xbmcgui.Dialog().ok(__addonname__, '网络错误 %s %s %d次' % (url, str(e), maxtimes))
			else: xbmcgui.Dialog().ok(__addonname__, '网络错误 %s %s' % (url, str(e)))
			return

	if response.headers.get('content-encoding', None) == 'gzip':
		import zlib
		httpData = zlib.decompress(httpData, zlib.MAX_WBITS|32)

	response.close()
	return httpData

def createSelect(list, index, value=None):
	result = []
	if index == -1: #  一元列表
		for entry in list:
			if entry == value: result.append('[%s]' % entry)
			else: result.append(entry)
	else: #  多元列表
		for entry in list:
			if entry[index] == value: result.append('[%s]' % entry[index])
			else: result.append(entry[index])
	return result

def parseUrl(url):
	# http://list.iqiyi.com/www/频道/分类-分类-分类-分类-分类------资费-年份--排序-页数-类别-iqiyi--状态.html
	regex = re.compile('http://list.iqiyi.com/www/(\d+)/(\d*)-(\d*)-(\d*)-(\d*)-(\d*)------(\d*)-([\d_]*)--(\d+)-(\d+)-(\d+)-iqiyi--(\d*).html', re.DOTALL)
	match = regex.findall(url)
	urlInfo = {'chn': match[0][0], 'cate': [match[0][1], match[0][2], match[0][3], match[0][4], match[0][5]], 'pay': match[0][6], 'year': match[0][7], 'sort': match[0][8], 'page': match[0][9], 'tab': match[0][10], 'status': match[0][11]}
	return urlInfo

def makeUrl(urlInfo):
	# /www/频道/分类-分类-分类-分类-分类------资费-年份--排序-页数-类别-iqiyi--状态.html
	url = 'http://list.iqiyi.com/www/%s/%s-%s-%s-%s-%s------%s-%s--%s-%s-%s-iqiyi--%s.html' % (urlInfo['chn'], urlInfo['cate'][0], urlInfo['cate'][1], urlInfo['cate'][2], urlInfo['cate'][3], urlInfo['cate'][4], urlInfo['pay'], urlInfo['year'], urlInfo['sort'], urlInfo['page'], urlInfo['tab'], urlInfo['status'])
	return url

def createUrl(urlInfo):
	url = '%s?' % addon_url
	for key, value in urlInfo.items():
		url += '%s=%s&' % (key, urllib.quote(value.encode('utf-8')))
	url = url[:-1]
	return url

def sort_key(s):
	value = int(s[0].split('x')[0])
	if ' ' in s[0]: value -= 1
	return value

def formatSec(sec):
	m, s = divmod(sec, 60)
	h, m = divmod(m, 60)
	if h == 0: return '%02d:%02d' % (m, s)
	else: return '%02d:%02d:%02d' % (h, m, s)

def formatDate(date):
	return date[:4]+'-'+date[4:6]+'-'+date[6:]

def formatTime(timeStamp):
	return time.strftime('%Y-%m-%d', time.localtime(float(timeStamp/1000)))

def isDate(date):
	try:
		time.strptime(date, '%Y-%m-%d')
		return True
	except:
		return False

def setView(viewid):
	xbmcgui.Dialog().yesno(__addonname__, '强制固定视图，视图代码 [%s]' % viewid, autoclose=1)
	xbmc.executebuiltin('Container.SetViewMode(%s)' % viewid)

def showRoot():
	# 显示导航
	items = [('列表', 'list'), ('专题', 'topic'), ('热搜', 'hot'), ('搜索', 'search'), ('历史', 'history')]
	for entry in items:
		item = xbmcgui.ListItem(entry[0])
		item.setArt({'poster': defaultPic})
		item_url = createUrl({'mode': entry[1]})
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

	# 设置内容
	xbmcplugin.setContent(pHandle, 'files')
	xbmcplugin.endOfDirectory(pHandle)

def showList():
	change = params.get('change')
	if not change: # 首次进入
		url = 'http://list.iqiyi.com/www/1/-------------24-1-1-iqiyi--.html'
		urlInfo = parseUrl(url)
	else: # 非首次进入
		if change == 'chn': # 改变频道
			chnInfo = simplejson.loads(params.get('chninfo'))
			curChn = chnInfo['active']
			chnList = chnInfo['list']
			select = xbmcgui.Dialog().select('改变频道', createSelect(chnList, 1, curChn))
			if select == -1 or chnList[select][1] == curChn: return

			if chnList[select][0] == '10': # "10"片花,"1007"电影
				url = 'http://list.iqiyi.com/www/10/1007-------------24-1-2-iqiyi--.html'
			elif chnList[select][0] in ['25', '7', '16', '5', '28', '17', '13', '21', '26', '20']:
				url = 'http://list.iqiyi.com/www/%s/-------------24-1-2-iqiyi--.html' % chnList[select][0]
			else:
				url = 'http://list.iqiyi.com/www/%s/-------------24-1-1-iqiyi--.html' % chnList[select][0]
			urlInfo = parseUrl(url)

		elif change == 'sort': # 改变排序
			sortInfo = simplejson.loads(params.get('sortinfo'))
			curSort = sortInfo['active']
			sortList = sortInfo['list']
			select = xbmcgui.Dialog().select('改变排序', createSelect(sortList, 1, curSort))
			if select == -1 or sortList[select][1] == curSort: return

			urlInfo = parseUrl(params.get('url'))
			urlInfo['sort'] = sortList[select][0]
			urlInfo['page'] = '1'
			url = makeUrl(urlInfo)

		elif change == 'cate': # 改变分类
			cateInfo = simplejson.loads(params.get('cateinfo'))
			cateValue = cateInfo['active']
			cateList = cateInfo['list']
			select = xbmcgui.Dialog().select('改变分类', createSelect(cateList, 1, cateValue))
			if select == -1 or cateList[select][1] == cateValue: return

			urlInfo = parseUrl(params.get('url'))
			IDList = [entry[0] for entry in cateList]
			for i in range(len(urlInfo['cate'])):
				if urlInfo['cate'][i] == '' or urlInfo['cate'][i] in IDList:
					urlInfo['cate'][i] = IDList[select]
					break
			urlInfo['cate'].sort(reverse=True)
			urlInfo['page'] = '1'
			url = makeUrl(urlInfo)

		elif change == 'year': # 改变年份
			yearInfo = simplejson.loads(params.get('yearinfo'))
			curYear = yearInfo['active']
			yearList = yearInfo['list']
			select = xbmcgui.Dialog().select('改变年份', createSelect(yearList, 1, curYear))
			if select == -1 or yearList[select][1] == curYear: return

			urlInfo = parseUrl(params.get('url'))
			urlInfo['year'] = yearList[select][0]
			urlInfo['page'] = '1'
			url = makeUrl(urlInfo)

		elif change == 'pay': # 改变资费
			payInfo = simplejson.loads(params.get('payinfo'))
			curPay = payInfo['active']
			payList = payInfo['list']
			select = xbmcgui.Dialog().select('改变资费', createSelect(payList, 1, curPay))
			if select == -1 or payList[select][1] == curPay: return

			urlInfo = parseUrl(params.get('url'))
			urlInfo['pay'] = payList[select][0]
			urlInfo['page'] = '1'
			url = makeUrl(urlInfo)

		elif change == 'status': # 改变状态
			statusInfo = simplejson.loads(params.get('statusinfo'))
			curStatus = statusInfo['active']
			statusList = statusInfo['list']
			select = xbmcgui.Dialog().select('改变状态', createSelect(statusList, 1, curStatus))
			if select == -1 or statusList[select][1] == curStatus: return

			urlInfo = parseUrl(params.get('url'))
			urlInfo['status'] = statusList[select][0]
			urlInfo['page'] = '1'
			url = makeUrl(urlInfo)

		elif change == 'tab': # 改变类别
			tabInfo = simplejson.loads(params.get('tabinfo'))
			curTab = tabInfo['active']
			tabList = tabInfo['list']
			select = xbmcgui.Dialog().select('改变类别', createSelect(tabList, 1, curTab))
			if select == -1 or tabList[select][1] == curTab: return

			urlInfo = parseUrl(params.get('url'))
			urlInfo['tab'] = tabList[select][0]
			urlInfo['page'] = '1'
			url = makeUrl(urlInfo)

		elif change == 'page': # 改变页数
			pageInfo = simplejson.loads(params.get('pageinfo'))
			curPage = pageInfo['active']
			pageList = pageInfo['list']
			select = xbmcgui.Dialog().select('改变页数', createSelect(pageList, 1, curPage))
			if select == -1 or pageList[select][1] == curPage: return

			urlInfo = parseUrl(params.get('url'))
			if pageList[select][0] == 'pre': urlInfo['page'] = str(int(curPage)-1) # 上一页
			elif pageList[select][0] == 'next': urlInfo['page'] = str(int(curPage)+1) # 下一页
			else: urlInfo['page'] = pageList[select][0] # 页数
			url = makeUrl(urlInfo)

	httpData = getHttpData(url)
	if not httpData: return

	# 显示频道
	regex = re.compile('class="category-item  selected "\s*data-store-key="channelId.*?class="category-text">(.+?)</span>', re.DOTALL)
	match = regex.search(httpData)
	if match:
		chnInfo = {}
		chnInfo['active'] = match.group(1)

		reg = re.compile('<span\s*class="category-item.*?data-store-key="channelId"\s*data-id="(\d+)".*?class="category-text">(.+?)</span>', re.DOTALL)
		mat = reg.findall(httpData)
		chnInfo['list'] = mat[:]

		item = xbmcgui.ListItem('[COLOR yellow][B]频道：[/B]%s[/COLOR]' % chnInfo['active'])
		item.setArt({'poster': defaultPic})
		item_url = createUrl({'mode': 'list', 'change': 'chn', 'chninfo': simplejson.dumps(chnInfo)})
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

	# 显示排序
	regex = re.compile('class="category-item   selected "\s*data-store-key="order.*?class="category-text">(.+?)</span>', re.DOTALL)
	match = regex.search(httpData)
	if match:
		sortInfo = {}
		sortInfo['active'] = match.group(1)

		reg = re.compile('data-store-key="order"\s*data-id="(.*?)".*?class="category-text">(.+?)</span>', re.DOTALL)
		mat = reg.findall(httpData)
		sortInfo['list'] = mat[:]

		item = xbmcgui.ListItem('[COLOR yellow][B]排序：[/B]%s[/COLOR]' % sortInfo['active'])
		item.setArt({'poster': defaultPic})
		item_url = createUrl({'mode': 'list', 'change': 'sort', 'sortinfo': simplejson.dumps(sortInfo), 'url': url})
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

	# 显示分类
	cates = []
	regex = re.compile('<div class="category-list">(\s*<span class="category-item (?: selected )?" data-store-key="threeCategory">.+?)</div>', re.DOTALL)
	match = regex.findall(httpData)
	for i, entry in enumerate(match):
		cateInfo = {}

		reg = re.compile('<span\s*class="category-item  selected "\s*data-store-key="threeCategory".*?>\s*<span class="category-text">(.+?)</span>\s*</span>', re.DOTALL)
		mat = reg.search(entry)
		cateInfo['active'] = mat.group(1)

		cateInfo['list'] = []
		reg = re.compile('<span\s*class="category-item (?: selected )?"\s*data-store-key="threeCategory"(.*?)>\s*<span class="category-text">(.+?)</span>\s*</span>', re.DOTALL)
		mat = reg.findall(entry)
		for ent in mat:
			regi = re.compile('data-id="(\d+)"', re.DOTALL)
			mati = regi.search(ent[0])
			if mati: cateInfo['list'].append((mati.group(1), ent[1]))
			else: cateInfo['list'].append(('', ent[1]))

		item = xbmcgui.ListItem('[COLOR yellow][B]分类：[/B]%s[/COLOR]' % cateInfo['active'])
		item.setArt({'poster': defaultPic})
		item_url = createUrl({'mode': 'list', 'change': 'cate', 'cateinfo': simplejson.dumps(cateInfo), 'url': url})
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

	# 显示年份
	regex = re.compile('class="category-item  selected "\s*data-store-key="year.*?class="category-text">(.+?)</span>', re.DOTALL)
	match = regex.search(httpData)
	if match:
		yearInfo = {}
		yearInfo['active'] = match.group(1)

		reg = re.compile('data-store-key="year"\s*data-id="(.*?)".*?class="category-text">(.+?)</span>', re.DOTALL)
		mat = reg.findall(httpData)
		yearInfo['list'] = mat[:]

		item = xbmcgui.ListItem('[COLOR yellow][B]年份：[/B]%s[/COLOR]' % yearInfo['active'])
		item.setArt({'poster': defaultPic})
		item_url = createUrl({'mode': 'list', 'change': 'year', 'yearinfo': simplejson.dumps(yearInfo), 'url': url})
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

	# 显示资费
	regex = re.compile('class="category-item  selected "\s*data-store-key="isPay.*?class="category-text">(.+?)</span>', re.DOTALL)
	match = regex.search(httpData)
	if match:
		payInfo = {}
		payInfo['active'] = match.group(1)

		reg = re.compile('data-store-key="isPay"\s*data-id="(.*?)".*?class="category-text">(.+?)</span>', re.DOTALL)
		mat = reg.findall(httpData)
		payInfo['list'] = mat[:]

		item = xbmcgui.ListItem('[COLOR yellow][B]资费：[/B]%s[/COLOR]' % payInfo['active'])
		item.setArt({'poster': defaultPic})
		item_url = createUrl({'mode': 'list', 'change': 'pay', 'payinfo': simplejson.dumps(payInfo), 'url': url})
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

	# 显示状态
	regex = re.compile('class="category-item  selected "\s*data-store-key="isFinished.*?class="category-text">(.+?)</span>', re.DOTALL)
	match = regex.search(httpData)
	if match:
		statusInfo = {}
		statusInfo['active'] = match.group(1)

		reg = re.compile('data-store-key="isFinished"\s*data-id="(.*?)".*?class="category-text">(.+?)</span>', re.DOTALL)
		mat = reg.findall(httpData)
		statusInfo['list'] = mat[:]

		item = xbmcgui.ListItem('[COLOR yellow][B]状态：[/B]%s[/COLOR]' % statusInfo['active'])
		item.setArt({'poster': defaultPic})
		item_url = createUrl({'mode': 'list', 'change': 'status', 'statusinfo': simplejson.dumps(statusInfo), 'url': url})
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

	# 还可以搜
	regex = re.compile('class="category-label-text">还可以搜</span>.*?class="category-list">(.+?)</div>', re.DOTALL)
	match = regex.search(httpData)
	if match:
		reg = re.compile('href="//so.iqiyi.com/so/q_(.+?)\?source=list"', re.DOTALL)
		mat = reg.findall(match.group(1))
		keys = mat[:]

		item = xbmcgui.ListItem('[COLOR yellow][B]还可以搜：[/B]%s等[/COLOR]' % keys[0])
		item.setArt({'poster': defaultPic})
		item_url = createUrl({'mode': 'search', 'keys': simplejson.dumps(keys)})
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

	if urlInfo['tab'] == '1': # 类别：专辑
		# 显示类别
		content = 'movies'

		tabInfo = {}
		tabInfo['active'] = '专辑'
		tabInfo['list'] = [('1', '专辑'), ('2', '视频')]

		item = xbmcgui.ListItem('[COLOR yellow][B]类别：[/B]%s[/COLOR]' % tabInfo['active'])
		item.setArt({'poster': defaultPic})
		item_url = createUrl({'mode': 'list', 'change': 'tab', 'tabinfo': simplejson.dumps(tabInfo), 'url': url})
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

		# 显示视频
		regex = re.compile('data-original=\'(.+?\' *data-index).*?src="([^"]+)" class="qy-mod-cover fadeOutIn-enter-active">', re.DOTALL)
		match = regex.findall(httpData)
		for entry in match:
			poster = entry[1]
			if not 'http' in poster: poster = 'http:' + poster

			fanart = poster.replace('_260_360.jpg', '_720_405.jpg')
			if fanart == poster: fanart = None

			originalInfo = simplejson.loads(entry[0].replace("'                     data-index", '').replace('\n', '').replace('\r', '').replace('　', ''))

			series_url = originalInfo['playUrl']
			label = HTMLParser.HTMLParser().unescape(originalInfo['name'])
			if originalInfo.get('payMark'): label2 = '[COLOR red]%s[/COLOR]' % label # 付费
			else: label2 = label

			infoLabels = {}
			infoLabels['plot'] = ''
			if originalInfo.get('focus'): infoLabels['tagline'] = originalInfo.get('focus')
			if originalInfo.get('score'): infoLabels['plot'] += '[B]评分：[/B]'+str(originalInfo.get('score'))+'\n'
			if originalInfo.get('cast'):
				if originalInfo.get('cast').get('main_charactor'): infoLabels['plot'] += '[B]主演：[/B]'+' / '.join([ent['name'] for ent in originalInfo.get('cast').get('main_charactor')])+'\n'
				if originalInfo.get('cast').get('host'): infoLabels['plot'] += '[B]主持：[/B]'+' / '.join([ent['name'] for ent in originalInfo.get('cast').get('host')])+'\n'
				if originalInfo.get('cast').get('guest'): infoLabels['plot'] += '[B]嘉宾：[/B]'+' / '.join([ent['name'] for ent in originalInfo.get('cast').get('guest')])+'\n'
			if originalInfo.get('categories'): infoLabels['plot'] += '[B]类型：[/B]'+' / '.join([ent['name'] for ent in originalInfo.get('categories')])+'\n'
			if originalInfo.get('formatPeriod'): infoLabels['plot'] += '[B]上映：[/B]'+originalInfo.get('formatPeriod')+'\n'
			elif originalInfo.get('issueTime'): infoLabels['plot'] += '[B]上映：[/B]'+formatTime(originalInfo.get('issueTime'))+'\n'
			if originalInfo.get('meta'): infoLabels['plot'] += '[B]更新：[/B]'+originalInfo.get('meta')+'\n'
			if originalInfo.get('duration'): infoLabels["plot"] += '[B]片长：[/B]'+originalInfo.get('duration')+'\n'
			if originalInfo.get('description'): infoLabels['plot'] += '[B]简介：[/B]'+originalInfo.get('description').replace('\n', '')+'\n'

			item = xbmcgui.ListItem(label2)
			item.setArt({'poster': poster, 'fanart': fanart})
			item.setInfo('video', infoLabels)
			if series_url[21:23] == 'a_': # 专辑
				albumid = originalInfo['albumId']
				item_url = createUrl({'mode': 'series', 'albumid': albumid})
				item.addContextMenuItems([('采集方式…', 'RunPlugin(%s)' % createUrl({'mode': 'play', 'url': series_url, 'label': label, 'thumb': poster, 'type': 'series'}))])
				xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)
			else: # 单集
				item_url = createUrl({'mode': 'play', 'url': series_url, 'label': label, 'thumb': poster})
				item.addContextMenuItems([('采集方式…', 'RunPlugin(%s)' % createUrl({'mode': 'play', 'url': series_url, 'label': label, 'thumb': poster, 'type': 'series'})), ('解析方式…', 'RunPlugin(%s)' % createUrl({'mode': 'play', 'url': series_url, 'label': label, 'thumb': poster, 'type': 'video'}))])
				xbmcplugin.addDirectoryItem(pHandle, item_url, item, False)

	elif urlInfo['tab'] == '2': # 类别：视频
		# 显示类别
		content = 'videos'

		tabInfo = {}
		tabInfo['active'] = '视频'
		tabInfo['list'] = [('1', '专辑'), ('2', '视频')]

		item = xbmcgui.ListItem('[COLOR yellow][B]类别：[/B]%s[/COLOR]' % tabInfo['active'])
		item.setArt({'poster': defaultPic})
		item_url = createUrl({'mode': 'list', 'change': 'tab', 'tabinfo': simplejson.dumps(tabInfo), 'url': url})
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

		# 显示视频
		regex = re.compile('class="qy-mod-li .*?<a title="([^"]+)" class="qy-mod-link" href="([^"]+)" target="_blank">\s*<img alt=".*?" src="([^"]+)" class="qy-mod-cover fadeOutIn-enter-active">(.+?)<div class="icon-br"><span class="qy-mod-label">(.*?)</span></div>', re.DOTALL)
		match = regex.findall(httpData)
		for entry in match:
			poster = entry[2]
			if not 'http' in poster: poster = 'http:' + poster

			label = HTMLParser.HTMLParser().unescape(entry[0])
			if entry[3].strip(): label2 = '[COLOR red]%s[/COLOR]' % label # 付费
			else: label2 = label

			video_url = entry[1]
			if not 'http' in video_url: video_url = 'http:' + video_url

			infoLabels = {}
			if entry[4]: infoLabels['plot'] = '[B]片长：[/B]'+entry[4]+'\n'

			item = xbmcgui.ListItem(label2)
			item.setArt({'poster': poster})
			item.setInfo('video', infoLabels)
			item_url = createUrl({'mode': 'play', 'url': video_url, 'label': label, 'thumb': poster})
			item.addContextMenuItems([('采集方式…', 'RunPlugin(%s)' % createUrl({'mode': 'play', 'url': video_url, 'label': label, 'thumb': poster, 'type': 'series'})), ('解析方式…', 'RunPlugin(%s)' % createUrl({'mode': 'play', 'url': video_url, 'label': label, 'thumb': poster, 'type': 'video'}))])
			xbmcplugin.addDirectoryItem(pHandle, item_url, item, False)

	# 显示页数
	pageStr = ''
	regex = re.compile('class="page  curPage " data-store-key="page.*?>(\d+)</span>', re.DOTALL)
	match = regex.search(httpData)
	if match:
		pageInfo = {}
		pageInfo['active'] = match.group(1)

		reg = re.compile('class="page (?: curPage |a1 )?" data-store-key="page" data-id="([^"]+)">(.+?)</span>', re.DOTALL)
		mat = reg.findall(httpData)
		pageInfo['list'] = mat[:]

		item = xbmcgui.ListItem('[COLOR yellow][B]页数：[/B]第%s页[/COLOR]' % pageInfo['active'])
		item.setArt({'poster': defaultPic})
		item_url = createUrl({'mode': 'list', 'change': 'page', 'pageinfo': simplejson.dumps(pageInfo), 'url': url})
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

		pageStr = ' 第%s页' % pageInfo['active']

	# 设置内容
	xbmcplugin.setContent(pHandle, content)
	xbmcplugin.setPluginCategory(pHandle, '列表'+pageStr)
	xbmcplugin.endOfDirectory(pHandle)

	# 设置视图
	forceview = __addon__.getSetting('forceview')
	if forceview == 'true':
		viewid = __addon__.getSetting('viewid')
		setView(viewid)

def showSeries():
	# 获取专辑信息
	albumid = params.get('albumid')
	url = 'http://cache.video.iqiyi.com/a/%s' % albumid
	httpData = getHttpData(url)
	if not httpData: return

	albumInfo = simplejson.loads(httpData[httpData.find('=')+1:].replace('\n', '').replace('\r', '').replace('　', ''))
	if albumInfo['code'] != 'A00000':
		xbmcgui.Dialog().ok(__addonname__, '当前专辑无法播放 %s' % albumInfo['code'])
		return

	albumData = albumInfo['data']
	sourceid = albumData['sourceId']
	if sourceid == 0: # 连续剧等
		viewid = __addon__.getSetting('viewid')
		p = params.get('p')
		if not p: # 首次进入
			url = 'http://cache.video.iqiyi.com/avlist/%s/' % albumid
		else: # 改变页数
			p = int(p)
			curPage = int(params.get('curPage'))
			totalPage = int(params.get('totalPage'))

			pageList = []
			if curPage>1: pageList.append('上一页')
			for i in range(1, totalPage+1): 
				if i == curPage: pageList.append('[%d]' % i)
				else: pageList.append(str(i))
			if curPage<totalPage: pageList.append('下一页')

			select = xbmcgui.Dialog().select('改变页数', pageList)
			if select == -1 or pageList[select] == '[%d]' % curPage: return
			if pageList[select] == '上一页': nextPage = curPage-1
			elif pageList[select] == '下一页': nextPage = curPage+1
			else: nextPage = int(pageList[select])
			url = 'http://cache.video.iqiyi.com/avlist/%s/%d/' % (albumid, nextPage+p-1)

		httpData = getHttpData(url)
		if not httpData: return

		# 调整页数
		videoList = simplejson.loads(httpData[httpData.find('=')+1:].replace('\n', '').replace('\r', '').replace('　', ''))
		if not p: p = 1
		totalPage = videoList['data']['pgt']
		while p<totalPage and not videoList['data']['vlist']:
			p += 1
			url = 'http://cache.video.iqiyi.com/avlist/%s/%d/' % (albumid, p)
			httpData = getHttpData(url)
			if not httpData: return

			videoList = simplejson.loads(httpData[httpData.find('=')+1:].replace('\n', '').replace('\r', '').replace('　', ''))

		# 显示视频
		for entry in videoList['data']['vlist']:
			playUrl = entry['vurl']
			poster = entry['vpic']

			if entry['vt'] in entry['vn']: label = entry['vn']
			else: label = '%s %s' % (entry['vn'], entry['vt'])
			if entry['payMark']: label2 = '[COLOR red]%s[/COLOR]' % label #付费
			else: label2 = label

			infoLabels = {}
			infoLabels['plot'] = ''
			if entry.get('publishTime'): infoLabels['plot'] += '[B]上映：[/B]'+formatTime(entry['publishTime'])+'\n'
			if entry.get('timeLength'): infoLabels['plot'] += '[B]片长：[/B]'+formatSec(entry['timeLength'])+'\n'

			item = xbmcgui.ListItem(label2)
			item.setArt({'poster': poster})
			item.setInfo('video', infoLabels)
			item_url = createUrl({'mode': 'play', 'url': playUrl, 'label': label, 'thumb': poster})
			item.addContextMenuItems([('采集方式…', 'RunPlugin(%s)' % createUrl({'mode': 'play', 'url': playUrl, 'label': label, 'thumb': poster, 'type': 'series'})), ('解析方式…', 'RunPlugin(%s)' % createUrl({'mode': 'play', 'url': playUrl, 'label': label, 'thumb': poster, 'type': 'video'}))])
			xbmcplugin.addDirectoryItem(pHandle, item_url, item, False)

		# 显示页数
		pageStr = ''
		if totalPage>1:
			curPage = int(videoList['data']['pg'])-p+1
			item = xbmcgui.ListItem('[COLOR yellow][B]页数：[/B]第%d页[/COLOR]' % curPage)
			item.setArt({'poster': defaultPic})
			item_url = createUrl({'mode': 'series', 'totalPage': str(totalPage-p+1), 'curPage': str(curPage), 'p': str(p), 'albumid': albumid})
			xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

			pageStr = ' 第%d页' % curPage

	else: # 综艺等 无翻页
		viewid = '55'
		albumType = albumInfo['data']['albumType']
		curYear = params.get('curyear')
		curMonth = params.get('curmonth')
		hasAll = params.get('hasall', 'True')
		if not curYear: # 首次进入
			curYear = '全部'
			url = 'http://cache.video.qiyi.com/sdvlst/%d/%d/' % (albumType, sourceid)
		else:
			url = 'http://cache.video.iqiyi.com/sdlst/%d/%d/' % (albumType, sourceid)
			httpData = getHttpData(url)
			if not httpData: return

			timeInfo = simplejson.loads(httpData[httpData.find('=')+1:].replace('\n', '').replace('\r', '').replace('　', ''))
			if not curMonth: # 改变年份
				yearList = timeInfo['data'].keys()
				if hasAll == 'True': yearList.append('全部')
				yearList.sort(reverse=True)
				select = xbmcgui.Dialog().select('改变年份', createSelect(yearList, -1, curYear))
				if select == -1 or yearList[select] == curYear: return

				curYear = yearList[select]
				if curYear == '全部':
					url = 'http://cache.video.iqiyi.com/sdvlst/%d/%d/' % (albumType, sourceid)
				else:
					curMonth = '全部'
					url = 'http://cache.video.iqiyi.com/sdvlst/%d/%d/%s/' % (albumType, sourceid, curYear)

			else: # 改变月份
				monthList = timeInfo['data'][curYear]
				if hasAll == 'True': monthList.append('全部')
				monthList.sort(reverse=True)
				select = xbmcgui.Dialog().select('改变月份', createSelect(monthList, -1, curMonth))
				if select == -1 or monthList[select] == curMonth: return

				curMonth = monthList[select]
				if curMonth == '全部':
					url = 'http://cache.video.iqiyi.com/sdvlst/%d/%d/%s/' % (albumType, sourceid, curYear)
				else:
					url = 'http://cache.video.iqiyi.com/sdvlst/%d/%d/%s%s/' % (albumType, sourceid, curYear, curMonth)

		httpData = getHttpData(url)
		if not httpData: return

		tvInfo = simplejson.loads(httpData[httpData.find('=')+1:].replace('\n', '').replace('\r', '').replace('　', ''))
		if tvInfo['code'] != 'A00000': # 使用最近年份和月份
			url = 'http://cache.video.iqiyi.com/sdlst/%d/%d/' % (albumType, sourceid)
			httpData = getHttpData(url)
			if not httpData: return

			timeInfo = simplejson.loads(httpData[httpData.find('=')+1:].replace('\n', '').replace('\r', '').replace('　', ''))
			yearList = timeInfo['data'].keys()
			yearList.sort(reverse=True)
			curYear = yearList[0]

			monthList = timeInfo['data'][curYear]
			monthList.sort(reverse=True)
			curMonth = monthList[0]

			url = 'http://cache.video.iqiyi.com/sdvlst/%d/%d/%s%s/' % (albumType, sourceid, curYear, curMonth)
			httpData = getHttpData(url)
			if not httpData: return

			tvInfo = simplejson.loads(httpData[httpData.find('=')+1:].replace('\n', '').replace('\r', '').replace('　', ''))
			if tvInfo['code'] != 'A00000':
				xbmcgui.Dialog().ok(__addonname__, '当前专辑无法播放 %s' % tvInfo['code'])
				return

			hasAll = 'False'

		# 显示年份
		pageStr = ''
		if curYear != '全部' or curYear == '全部' and len(tvInfo['data']) == 120:
			if curYear == '全部': yearLabel = '全部'
			else:
				yearLabel = curYear + '年'
				pageStr += ''
				pageStr += yearLabel
			item = xbmcgui.ListItem('[COLOR yellow][B]年份：[/B]%s[/COLOR]' % yearLabel)
			item.setArt({'poster': defaultPic})
			item_url = createUrl({'mode': 'series', 'curyear': curYear, 'hasall': hasAll, 'albumid': albumid})
			xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

		# 显示月份
		if curMonth:
			if curMonth != '全部' or curMonth == '全部' and len(tvInfo['data']) == 120:
				if curMonth == '全部': monthLabel = '全部'
				else:
					monthLabel = str(int(curMonth)) + '月'
					pageStr += monthLabel
				item = xbmcgui.ListItem('[COLOR yellow][B]月份：[/B]%s[/COLOR]' % monthLabel)
				item.setArt({'poster': defaultPic})
				item_url = createUrl({'mode': 'series', 'curyear': curYear, 'curmonth': curMonth, 'hasall': hasAll, 'albumid': albumid})
				xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

		# 显示视频
		for entry in tvInfo['data']:
			playUrl = entry.get('vUrl')
			poster = entry['tvPicUrl']
			fanart = poster.replace('.jpg', '_720_405.jpg')

			label = entry['tvYear']+' '+entry['sName']+' '+entry['shortTitle']
			if entry['payMark']: label2 = '[COLOR red]%s[/COLOR]' % label #付费
			else: label2 = label

			infoLabels = {}
			infoLabels['plot'] = ''
			if entry.get('tvFocus'): infoLabels['tagline'] = entry['tvFocus']
			if entry.get('mActor'): infoLabels['plot'] += '[B]主演：[/B]'+entry['mActor'].replace(',', ' / ')+'\n'
			if entry.get('tvYear'): infoLabels['plot'] += '[B]上映：[/B]'+entry['tvYear']+'\n'
			if entry.get('timeLength'): infoLabels['plot'] += '[B]片长：[/B]'+formatSec(entry['timeLength'])+'\n'
			if entry.get('desc'): infoLabels['plot'] += '[B]简介：[/B]'+entry['desc']+'\n'

			item = xbmcgui.ListItem(label2)
			item.setArt({'poster': poster, 'fanart': fanart})
			item.setInfo('video', infoLabels)
			item_url = createUrl({'mode': 'play', 'url': playUrl, 'label': label, 'thumb': poster})
			item.addContextMenuItems([('采集方式…', 'RunPlugin(%s)' % createUrl({'mode': 'play', 'url': playUrl, 'label': label, 'thumb': poster, 'type': 'series'})), ('解析方式…', 'RunPlugin(%s)' % createUrl({'mode': 'play', 'url': playUrl, 'label': label, 'thumb': poster, 'type': 'video'}))])
			xbmcplugin.addDirectoryItem(pHandle, item_url, item, False)

	# 设置内容
	xbmcplugin.setContent(pHandle, 'videos')
	xbmcplugin.setPluginCategory(pHandle, albumInfo['data']['tvName']+pageStr)
	xbmcplugin.endOfDirectory(pHandle)

	# 设置视图
	forceview = __addon__.getSetting('forceview')
	if forceview == 'true': setView(viewid)

def showPlaylist():
	pageSize = 40
	bodanid = params.get('bodanid')
	bodanName = params.get('bodanname')
	change = params.get('change')
	if not change: # 首次进入
		curPage = 1
	else: # 非首次进入
		if change == 'page': # 改变页数
			curPage = int(params.get('curPage'))
			totalPage = int(params.get('totalPage'))
			pageList = []
			if curPage>1: pageList.append('上一页')
			for i in range(1, totalPage+1): 
				if i == curPage: pageList.append('[%d]' % i)
				else: pageList.append(str(i))
			if curPage<totalPage: pageList.append('下一页')

			select = xbmcgui.Dialog().select('改变页数', pageList)
			if select == -1 or pageList[select] == '[%d]' % curPage: return
			if pageList[select] == '上一页': curPage = curPage-1
			elif pageList[select] == '下一页': curPage = curPage+1
			else: curPage = int(pageList[select])

	url = 'http://pcw-api.iqiyi.com/album/bodan/bodanlistinfo?bodanId=%s&page=%d&size=%d' % (bodanid, curPage,pageSize)
	httpData = getHttpData(url)
	if not httpData: return

	bodanInfo = simplejson.loads(httpData.replace('\n', '').replace('\r', '').replace('　', ''))
	playList = bodanInfo['data']['playList']
	for entry in playList: # 显示视频
		if entry.get('playUrl'): playUrl = entry.get('playUrl')
		else: playUrl = entry.get('albumUrl')

		label = HTMLParser.HTMLParser().unescape(entry['name'])
		if entry.get('payMark'): label2 = '[COLOR red]%s[/COLOR]' % label # 付费
		else: label2 = label

		poster = entry['imageUrl']
		fanart = entry['imageUrl'].replace('.jpg', '_720_405.jpg')

		infoLabels = {}
		infoLabels['plot'] = ''

		if entry.get('focus'): infoLabels['tagline'] = entry['focus']
		if entry.get('score'): infoLabels['plot'] += '[B]评分：[/B]'+str(entry['score'])+'\n'
		if entry.get('people'):
			if entry.get('people').get('director'):
				director = [ent['name'] for ent in entry['people']['director']]
				infoLabels['plot'] += '[B]导演：[/B]'+' / '.join(director)+'\n'
			if entry.get('people').get('main_charactor'):
				charactor = [ent['name'] for ent in entry['people']['main_charactor']]
				infoLabels['plot'] += '[B]主演：[/B]'+' / '.join(charactor)+'\n'
		if entry.get('period'): infoLabels['plot'] += '[B]上映：[/B]'+entry['period']+'\n'
		if entry.get('duration'): infoLabels['plot'] += '[B]片长：[/B]'+entry['duration']+'\n'
		if entry.get('description'): infoLabels['plot'] += '[B]简介：[/B]'+entry['description']+'\n'

		item = xbmcgui.ListItem(label2)
		item.setArt({'poster': poster, 'fanart': fanart})
		item.setInfo('video', infoLabels)
		item_url = createUrl({'mode': 'play', 'url': playUrl, 'label': label, 'thumb': poster})
		item.addContextMenuItems([('采集方式…', 'RunPlugin(%s)' % createUrl({'mode': 'play', 'url': playUrl, 'label': label, 'thumb': poster, 'type': 'series'})), ('解析方式…', 'RunPlugin(%s)' % createUrl({'mode': 'play', 'url': playUrl, 'label': label, 'thumb': poster, 'type': 'video'}))])
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, False)

	# 显示页数
	pageStr = ''
	totalCount = bodanInfo['data']['totalCount']
	totalPage = int((totalCount+pageSize-1)/pageSize)
	if totalPage>1:
		item = xbmcgui.ListItem('[COLOR yellow][B]页数：[/B]第%d页[/COLOR]' % curPage)
		item.setArt({'poster': defaultPic})
		item_url = createUrl({'mode': 'playlist', 'change': 'page', 'totalPage': str(totalPage), 'curPage': str(curPage), 'bodanid': bodanid, 'bodanname': bodanName})
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

		pageStr = ' 第%d页' % curPage

	# 设置内容
	xbmcplugin.setContent(pHandle, 'videos')
	xbmcplugin.setPluginCategory(pHandle, bodanName+pageStr)
	xbmcplugin.endOfDirectory(pHandle)

	# 设置视图
	forceview = __addon__.getSetting('forceview')
	if forceview == 'true': setView('55')

def showTopic():
	change = params.get('change')
	if change == None: # 首次进入
		url = 'http://www.iqiyi.com/lib/zhuanti/tese/'
	else: # 非首次进入
		if change == 'cate': # 改变分类
			cateInfo = params.get('cateinfo')
			curCate = cateInfo['active']
			cateList = cateInfo['list']
			select = xbmcgui.Dialog().select('改变分类', createSelect(cateList, 1, curCate))
			if select == -1 or cateList[select][1] == curCate: return
			url = 'http:' + cateList[select][0]

	httpData = getHttpData(url)
	if httpData == None: return

	# 显示分类
	cateInfo = {}

	regex = re.compile('<li class="selected"><a href=".*?" title="(.+?)"', re.DOTALL)
	match = regex.search(httpData)
	cateInfo['active'] = match.group(1)

	regex = re.compile('<ul class="tab-normal(.+?)</ul>', re.DOTALL)
	match = regex.search(httpData)
	reg = re.compile('<li.*?href="(.+?)" title="(.+?)"', re.DOTALL)
	mat = reg.findall(match.group(1))
	cateInfo['list'] = mat[:]

	item = xbmcgui.ListItem('[COLOR yellow][B]分类：[/B]%s[/COLOR]' % cateInfo['active'])
	item.setArt({'poster': defaultPic})
	item_url = createUrl({'mode': 'topic', 'change': 'cate', 'cateinfo': simplejson.dumps(cateInfo)})
	xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

	# 显示专题
	regex = re.compile('<div class="site-piclist_pic.*?title="(.+?)" href="(.+?)".*?src="(.+?)".*?class="site-piclist_info_describe">(.+?)</p>', re.DOTALL)
	match = regex.findall(httpData)
	for entry in match:
		if entry[1][16:19] != 'lib': continue # 非lib不显示

		topic_url = 'http:' + entry[1]
		label = HTMLParser.HTMLParser().unescape(entry[0])

		poster = entry[2]
		if not 'http:' in poster: poster = 'http:' + poster

		infoLabels = {}
		infoLabels['tagline'] = HTMLParser.HTMLParser().unescape(entry[3])

		item = xbmcgui.ListItem(label)
		item.setArt({'poster': poster})
		item.setInfo('video', infoLabels)
		item_url = createUrl({'mode': 'content', 'url': topic_url})
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

	# 设置内容
	xbmcplugin.setContent(pHandle, 'videos')
	xbmcplugin.setPluginCategory(pHandle, '专题')
	xbmcplugin.endOfDirectory(pHandle)

	# 设置视图
	forceview = __addon__.getSetting('forceview')
	if forceview == 'true':
		viewid = __addon__.getSetting('viewid')
		setView(viewid)

def showContent():
	change = params.get('change')
	if not change: # 首次进入
		url = params.get('url')
	else: # 非首次进入
		if change == 'page': # 改变页数
			pageInfo = simplejson.loads(params.get('pageinfo'))
			curPage = pageInfo['active']
			pageList = pageInfo['list']
			select = xbmcgui.Dialog().select('改变页数', createSelect(pageList, 1, curPage))
			if select == -1 or pageList[select][1] == curPage: return
			url = pageList[select][0]
			if not 'http:' in url: url = 'http:' + url

	httpData = getHttpData(url)
	if not httpData: return

	# 显示视频
	regex = re.compile('<div class="mspecial-main-resume.*?<h1>(.+?)</h1>', re.DOTALL)
	match = regex.search(httpData)
	topic = match.group(1)

	regex = re.compile('<p class="msl-img-array.*?>(.+?)</p>.*?src="(.+?)" alt="(.+?)".*?<p class="msld-performer">主演:(.+?)</p>.*?<p class="msld-watch">看点:(.+?)</p>.*?时间:(.+?)</p>.*?<p class="msld-profile">(.+?)</p>', re.DOTALL)
	match = regex.findall(httpData)
	for entry in match:
		rank = '%02d. ' % int(entry[0])
		key = HTMLParser.HTMLParser().unescape(entry[2])

		poster = entry[1]
		if not 'http:' in poster: poster = 'http:' + poster

		fanart = poster.replace('_180_236.jpg', '_720_405.jpg')
		if fanart == poster: fanart = None

		infoLabels = {}
		infoLabels['plot'] = ''

		reg = re.compile('">(.+?)</a>', re.DOTALL)
		mat = reg.findall(entry[3])
		if mat: infoLabels['plot'] += '[B]主演：[/B]'+' / '.join(mat)+'\n'

		reg = re.compile('>(.+?)</a>', re.DOTALL)
		mat = reg.findall(entry[4])
		if mat: infoLabels['plot'] += '[B]看点：[/B]'+' / '.join(mat)+'\n'

		if entry[5].strip(): infoLabels['plot'] += '[B]上映：[/B]'+entry[5].strip()+'\n'
		if entry[6].strip(): infoLabels['plot'] += '[B]简介：[/B]'+entry[6].strip()+'\n'

		item = xbmcgui.ListItem(rank+key)
		item.setArt({'poster': poster, 'fanart': fanart})
		item.setInfo('video', infoLabels)
		item_url = createUrl({'mode': 'search', 'key': key})
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

	# 显示页数
	pageStr = ''
	regex = re.compile('<div class="mod-page mt50" data-ugcplayhistory-elem="pager.*?class="curPage">(\d+?)</span>', re.DOTALL)
	match = regex.search(httpData)
	if match:
		pageInfo = {}
		pageInfo['active'] = match.group(1)

		reg = re.compile('<(?:a|span).*?data-key=".*?(?:href|class)="([^"]+?)">(.+?)</(?:a|span)>', re.DOTALL)
		mat = reg.findall(httpData)
		pageInfo['list'] = mat[:]

		item = xbmcgui.ListItem('[COLOR yellow][B]页数：[/B]第%s页[/COLOR]' % pageInfo['active'])
		item.setArt({'poster': defaultPic})
		item_url = createUrl({'mode': 'content', 'change': 'page', 'pageinfo': simplejson.dumps(pageInfo)})
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

		pageStr = ' 第%s页' % pageInfo['active']

	# 设置内容
	xbmcplugin.setContent(pHandle, 'movies')
	xbmcplugin.setPluginCategory(pHandle, topic+pageStr)
	xbmcplugin.endOfDirectory(pHandle)

	# 设置视图
	forceview = __addon__.getSetting('forceview')
	if forceview == 'true':
		viewid = __addon__.getSetting('viewid')
		setView(viewid)

def showHot():
	change = params.get('change')
	if not change: # 首次进入
		url = 'http://v.iqiyi.com/index/resou/index.html'
	else: # 非首次进入
		if change == 'chn': # 改变频道
			chnInfo = simplejson.loads(params.get('chninfo'))
			curChn = chnInfo['active']
			chnList = chnInfo['list']
			select = xbmcgui.Dialog().select('改变频道', createSelect(chnList, 1, curChn))
			if select == -1 or chnList[select][1] == curChn: return
			url = 'http://v.iqiyi.com' + chnList[select][0]

	httpData = getHttpData(url)
	if not httpData: return

	# 显示频道
	chnInfo = {}

	regex = re.compile('class="channel-item nuxt-link-exact-active nuxt-link-active selected"> (.+?) </a>', re.DOTALL)
	match = regex.search(httpData)
	chnInfo['active'] = HTMLParser.HTMLParser().unescape(match.group(1))

	regex = re.compile('<a href="([^"]+)" rseat="[^"]*" class="channel-item[^"]*"> (.+?) </a>', re.DOTALL)
	match = regex.findall(httpData)
	chnInfo['list'] = [(entry[0], HTMLParser.HTMLParser().unescape(entry[1])) for entry in match[1:]]

	item = xbmcgui.ListItem('[COLOR yellow][B]频道：[/B]%s[/COLOR]' % chnInfo['active'])
	item.setArt({'poster': defaultPic})
	item_url = createUrl({'mode': 'hot', 'change': 'chn', 'chninfo': simplejson.dumps(chnInfo)})
	xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

	# 显示关键词
	regex = re.compile('class="thead-box thead-box-2">(.+?)</div>', re.DOTALL)
	match = regex.search(httpData)
	type = HTMLParser.HTMLParser().unescape(match.group(1))

	regex = re.compile('class="title-nub No(\d+)".*?class="title-link">(.+?)</a>.*?class="qy-top-title-label">(.+?)</div>', re.DOTALL)
	match = regex.findall(httpData)
	for entry in match:
		rank = '%02d. ' % int(entry[0])
		key = HTMLParser.HTMLParser().unescape(entry[1])

		infoLabels = {}
		reg = re.compile('class="label-2">\s*(.+?)\s*<(?:span|!----)>', re.DOTALL)
		mat = reg.findall(entry[2])
		if mat: infoLabels['plot'] = '[B]%s：[/B]%s\n' % (type, HTMLParser.HTMLParser().unescape(' / '.join(mat)))

		item = xbmcgui.ListItem(rank+key)
		item.setArt({'poster': defaultPic})
		item.setInfo('video', infoLabels)
		item_url = createUrl({'mode': 'search', 'key': key})
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

	# 设置内容
	xbmcplugin.setContent(pHandle, 'files')
	xbmcplugin.setPluginCategory(pHandle, '热搜')
	xbmcplugin.endOfDirectory(pHandle)

def showSearch():
	key = params.get('key')
	keys = params.get('keys')
	change = params.get('change')
	if not change: # 首次进入
		if key: pass
		elif keys:
			keyList = simplejson.loads(keys)
			select = xbmcgui.Dialog().select('还可以搜', keyList)
			if select == -1: return
			key = keyList[select].encode('utf-8')
		else:
			key = xbmcgui.Dialog().input('输入关键词')
			if not key: return
		url = 'http://so.iqiyi.com/so/q_' + urllib.quote(key)
	else: # 非首次进入
		if change == 'cate': # 改变分类
			cateInfo = simplejson.loads(params.get('cateinfo'))
			cateTitle = cateInfo['name']
			cateValue = cateInfo['active']
			cateList = cateInfo['list']
			select = xbmcgui.Dialog().select('改变%s' % cateTitle.rstrip('：').rstrip(':'), createSelect(cateList, 1, cateValue))
			if select == -1 or cateList[select][1] == cateValue: return
			url = 'http://so.iqiyi.com/so/' + urllib.quote(urllib.unquote(str(cateList[select][0])))

		elif change == 'sort': # 改变排序
			sortInfo = simplejson.loads(params.get('sortinfo'))
			curSort = sortInfo['active']
			sortList = sortInfo['list']
			select = xbmcgui.Dialog().select('改变排序', createSelect(sortList, 1, curSort))
			if select == -1 or sortList[select][1] == curSort: return
			url = 'http://so.iqiyi.com/so/' + urllib.quote(urllib.unquote(str(sortList[select][0])))

		elif change == 'page': # 改变页数
			pageInfo = simplejson.loads(params.get('pageinfo'))
			curPage = pageInfo['active']
			pageList = pageInfo['list']
			select = xbmcgui.Dialog().select('改变页数', createSelect(pageList, 1, curPage))
			if select == -1 or pageList[select][1] == curPage: return
			url = 'http://so.iqiyi.com/so/q_' + urllib.quote(urllib.unquote(str(pageList[select][0])))

	httpData = getHttpData(url)
	if not httpData: return

	# 显示分类
	cates = []
	regex = re.compile('<div class="mod_sear_list.*?<h3>(.+?)</h3>(.+?)</div>', re.DOTALL)
	match = regex.findall(httpData)
	for entry in match:
		cateInfo = {}
		cateInfo['name'] = entry[0]

		reg = re.compile('<li class="selected"><a href="#" title="(.+?)"', re.DOTALL)
		mat = reg.search(entry[1])
		cateInfo['active'] = mat.group(1)

		reg = re.compile('<li.*?href="([^"]+?)".*?title="(.+?)"', re.DOTALL)
		mat = reg.findall(entry[1])
		cateInfo['list'] = mat[:]

		cates.append(cateInfo)

	for entry in cates:
		item = xbmcgui.ListItem('[COLOR yellow][B]%s[/B]%s[/COLOR]' % (entry['name'], entry['active']))
		item.setArt({'poster': defaultPic})
		item_url = createUrl({'mode': 'search', 'change': 'cate', 'cateinfo': simplejson.dumps(entry), 'key': key})
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

	# 显示排序
	regex = re.compile('<div class="mod_sear_select">(.+?)</div>', re.DOTALL)
	match = regex.search(httpData)
	if match:
		sortInfo = {}

		reg = re.compile(' <a class="link_sear_select selected" href="#" title="(.+?)"', re.DOTALL)
		mat = reg.search(match.group(1))
		sortInfo['active'] = mat.group(1)

		reg = re.compile('<a.*?href="([^"]+?)".*?title="(.*?)".*?name="sort">', re.DOTALL)
		mat = reg.findall(match.group(1))
		sortInfo['list'] = mat[:]

		item = xbmcgui.ListItem('[COLOR yellow][B]排序：[/B]%s[/COLOR]' % sortInfo['active'])
		item.setArt({'poster': defaultPic})
		item_url = createUrl({'mode': 'search', 'change': 'sort', 'sortinfo': simplejson.dumps(sortInfo), 'key': key})
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

	# 显示视频
	regex = re.compile('<li class="list_item(.+?)>(.+?)</div>[ \n\r]*?</div>[ \n\r]*?</div>[ \n\r]*?</li>', re.DOTALL)
	match = regex.findall(httpData)

	items = []
	for entry in match:
		if 'data-widget-aladdinpattern' in entry[1] or '<p class="viedo_rt "><span class="icon-live">直播中</span></p>' in entry[1]: continue # 文学/直播不显示
		elif 'data-widget-intentrecognition' in entry[1]: # 意图识别标题
			reg = re.compile('<li class="intent-item-twoline(.+?)title="(.+?)".*?href *= *"(.+?)".*?src *= *"(.+?)"(.+?)</div>', re.DOTALL)
			mat = reg.findall(entry[1])
			for ent in mat:
				regi = re.compile('data-widget-searchlist-albumid="(.+?)"', re.DOTALL)
				mati = regi.search(ent[0])
				albumid = mati.group(1)

				vInfo = ''
				regi = re.compile('<span class="icon-vInfo">(.+?)</span>', re.DOTALL)
				mati = regi.search(ent[4])
				if mati: vInfo = mati.group(1).strip()

				infoLabels = {}
				if vInfo: infoLabels['plot'] = '[B]集数 / 片长：[/B]'+vInfo+'\n'

				poster = ent[3]
				if not 'http:' in poster: poster = 'http:' + poster

				fanart = poster.replace('_180_236.jpg', '_720_405.jpg')
				if fanart == poster: fanart = None

				label = HTMLParser.HTMLParser().unescape(ent[1])
				video_url = ent[2]

				items.append((label, poster, fanart, video_url, albumid, infoLabels))

		elif '<!--专辑（单）:singleEpisode-->' in entry[1] or '<!--专辑（多）:multiEpisode-->' in entry[1] or '<!--video-->' in entry[1]: # 专辑（单）:singleEpisode 或 专辑（多）:multiEpisode
			reg = re.compile('<a class="figure(.+?)href="(.+?)".*?title="(.+?)".*?src="(.+?)"(.+?)</div>', re.DOTALL)
			mat = reg.search(entry[1])

			albumid = '0'
			regi = re.compile('data-qidanadd-albumid="(.+?)"', re.DOTALL)
			mati = regi.search(mat.group(1))
			if mati: albumid = mati.group(1)

			vInfo = ''
			regi = re.compile('<span class="icon-vInfo">(.+?)</span>', re.DOTALL)
			mati = regi.search(mat.group(5))
			if mati: vInfo = mati.group(1).strip()

			poster = mat.group(4)
			if not 'http:' in poster: poster = 'http:' + poster

			fanart = poster.replace('_180_236.jpg', '_720_405.jpg')
			if fanart == poster: fanart = None

			label = HTMLParser.HTMLParser().unescape(mat.group(3))
			video_url = mat.group(2)

			infoLabels = {}
			infoLabels['plot'] = ''

			reg = re.compile('data-searchpingback-param="ptype=2-2".*?">(.+?)</a>', re.DOTALL)
			mat = reg.search(entry[1])
			if mat: infoLabels['plot'] += '[B]导演：[/B]'+mat.group(1)+'\n'

			reg = re.compile('data-searchpingback-param="ptype=2-1".*?">(.+?)</a>', re.DOTALL)
			mat = reg.findall(entry[1])
			if mat: infoLabels['plot'] += '[B]主演：[/B]'+' / '.join(mat)+'\n'

			reg = re.compile('result_info_lbl">地区:.*?<span>(.+?)</span>', re.DOTALL)
			mat = reg.search(entry[1])
			if mat: infoLabels['plot'] += '[B]地区：[/B]'+mat.group(1).strip()+'\n'

			reg = re.compile('result_info_lbl">上映时间:.*?<span>(.+?)</span>', re.DOTALL)
			mat = reg.search(entry[1])
			if mat: infoLabels['plot'] += '[B]上映：[/B]'+mat.group(1).strip()+'\n'

			reg = re.compile('result_info_lbl">发布时间:.*?<em class="result_info_desc">(.+?)</em>', re.DOTALL)
			mat = reg.search(entry[1])
			if mat: infoLabels['plot'] += '[B]发布：[/B]'+mat.group(1)+'\n'

			reg = re.compile('result_info_lbl">来源:.*?<em class="result_info_desc">(.+?)</em>', re.DOTALL)
			mat = reg.search(entry[1])
			if mat: infoLabels['plot'] += '[B]来源：[/B]'+mat.group(1)+'\n'

			if vInfo: infoLabels['plot'] += '[B]集数 / 片长：[/B]'+vInfo+'\n'

			reg = re.compile('result_info_lbl">简介:.*?<span class="result_info_txt">(.+?)</span>', re.DOTALL)
			mat = reg.search(entry[1])
			if mat: infoLabels['plot'] += '[B]简介：[/B]'+HTMLParser.HTMLParser().unescape(mat.group(1).strip())+'\n'

			reg = re.compile('data-detailinfo-elem="abstractinfo">(.+?)</span>', re.DOTALL)
			mat = reg.search(entry[1])
			if mat: infoLabels['plot'] += '[B]简介：[/B]'+mat.group(1)+'\n'

			items.append((label, poster, fanart, video_url, albumid, infoLabels))

		elif '<!--star-->' in entry[1] or '<!--ugcVerifiedUser-->' in entry[1] or '<!-- 倒计时 -->' in entry[1]: # star 或 ugcVerifiedUser 或 onetree空资料页
			reg = re.compile('<a class="preview_figure.*?href="(.+?)".*?src="(.+?)".*?alt="(.+?)"(.+?)</p>(.+?)</li>', re.DOTALL)
			mat = reg.findall(entry[1])
			for ent in mat:
				vInfo = ''
				regi = re.compile('<span class="icon-vInfo">(.+?)</span>', re.DOTALL)
				mati = regi.search(ent[3])
				if mati: vInfo = mati.group(1).strip()

				poster = ent[1]
				if not 'http:' in poster: poster = 'http:' + poster

				fanart = poster.replace('_180_236.jpg', '_720_405.jpg')
				if fanart == poster: fanart = None

				label = HTMLParser.HTMLParser().unescape(ent[2])
				video_url = ent[0]
				albumid = '0'

				infoLabels = {}
				infoLabels['plot'] = ''

				regi = re.compile('<em>饰演:(.+?)</em>', re.DOTALL)
				mati = regi.search(ent[4])
				if mati: infoLabels['plot'] += '[B]饰演：[/B]'+mati.group(1)+'\n'

				if vInfo: infoLabels['plot'] += '[B]集数 / 片长：[/B]'+vInfo+'\n'

				items.append((label, poster, fanart, video_url, albumid, infoLabels))

		elif '<!--播单-->' in entry[1] or '<!--multiEpisodeWithDetail-->' in entry[1] or '<!--zongYi-->' in entry[1]: # 播单 或 multiEpisodeWithDetail 或 zongyi
			reg = re.compile('data-widget-searchlist-albumid="(.+?)"', re.DOTALL)
			mat = reg.search(entry[0])
			albumid = mat.group(1)

			reg = re.compile('class="figure.*?href.*?"(.+?)".*?alt="(.+?)".*?src="(.+?)"', re.DOTALL)
			mat = reg.search(entry[1])
			video_url = mat.group(1)
			label = HTMLParser.HTMLParser().unescape(mat.group(2))

			poster = mat.group(3)
			if not 'http:' in poster: poster = 'http:' + poster

			fanart = poster.replace('_180_236.jpg', '_720_405.jpg')
			if fanart == poster: fanart = None

			infoLabels = {}
			reg = re.compile('result_info_lbl">简介:.*?<span class="result_info_txt">(.+?)</span>', re.DOTALL)
			mat = reg.search(entry[1])
			if mat: infoLabels['plot'] = '[B]简介：[/B]'+HTMLParser.HTMLParser().unescape(mat.group(1).strip())+'\n'

			items.append((label, poster, fanart, video_url, albumid, infoLabels))

			reg = re.compile('<li class="album_item.*?href="([^"]+?)"[ \n\r]*?data-pb.*?title="(.+?)" data-tvlist-elem', re.DOTALL)
			mat = reg.findall(entry[1])
			for ent in mat:
				label = HTMLParser.HTMLParser().unescape(ent[1])
				video_url = ent[0]
				albumid = '0'

				items.append((label, poster, fanart, video_url, albumid, infoLabels))

		else: xbmcgui.Dialog().ok(__addonname__, '当前搜索类型未知 %s' % entry[0])

	for entry in items:
		label = entry[0]
		poster = entry[1]
		fanart = entry[2]
		video_url = entry[3]
		albumid = entry[4]
		infoLabels = entry[5]

		item = xbmcgui.ListItem(label)
		item.setArt({'poster': poster, 'fanart': fanart})
		item.setInfo('video', infoLabels)

		if video_url[7:9] == 'so': continue # 外网不显示
		elif video_url[21:29] == 'playlist': # 播单
			item_url = createUrl({'mode': 'playlist', 'bodanid': albumid, 'bodanname': label})
			item.addContextMenuItems([('采集方式…', 'RunPlugin(%s)' % createUrl({'mode': 'play', 'url': video_url, 'label': label, 'thumb': poster, 'type': 'series'}))])
			xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)
		elif video_url[21:23] == 'a_' or video_url[21:24] == 'lib': # 专辑
			item_url = createUrl({'mode': 'series', 'albumid': albumid})
			item.addContextMenuItems([('采集方式…', 'RunPlugin(%s)' % createUrl({'mode': 'play', 'url': video_url, 'label': label, 'thumb': poster, 'type': 'series'}))])
			xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)
		else: # 单集
			item_url = createUrl({'mode': 'play', 'url': video_url, 'label': label, 'thumb': poster})
			item.addContextMenuItems([('采集方式…', 'RunPlugin(%s)' % createUrl({'mode': 'play', 'url': video_url, 'label': label, 'thumb': poster, 'type': 'series'})), ('解析方式…', 'RunPlugin(%s)' % createUrl({'mode': 'play', 'url': video_url, 'label': label, 'thumb': poster, 'type': 'video'}))])
			xbmcplugin.addDirectoryItem(pHandle, item_url, item, False)

	# 显示页数
	pageStr = ''
	regex = re.compile('<div class="mod-page" data-search-wrap="page.*?class="curPage">(\d+?)</span>', re.DOTALL)
	match = regex.search(httpData)
	if match:
		pageInfo = {}
		pageInfo['active'] = match.group(1)

		reg = re.compile('<(?:a|span) data-key=".*?(?:href|class)="([^"]+?)">(.+?)</(?:a|span)>', re.DOTALL)
		mat = reg.findall(httpData)
		pageInfo['list'] = mat[:]

		item = xbmcgui.ListItem('[COLOR yellow][B]页数：[/B]第%s页[/COLOR]' % pageInfo['active'])
		item.setArt({'poster': defaultPic})
		item_url = createUrl({'mode': 'search', 'change': 'page', 'pageinfo': simplejson.dumps(pageInfo), 'key': key})
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

		pageStr = ' 第%s页' % pageInfo['active']

	# 设置内容
	xbmcplugin.setContent(pHandle, 'albums')
	xbmcplugin.setPluginCategory(pHandle, key+pageStr)
	xbmcplugin.endOfDirectory(pHandle)

	# 设置视图
	forceview = __addon__.getSetting('forceview')
	if forceview == 'true':
		viewid = __addon__.getSetting('viewid')
		setView(viewid)

def showHistory():
	# 读取历史记录
	dataDir = getDataDir()
	filePath = os.path.join(dataDir, 'history.log')
	historyList = []
	if os.path.exists(filePath):
		fHandle = open(filePath, 'r')
		try:
			historyList = simplejson.load(fHandle)
		except simplejson.scanner.JSONDecodeError, e:
			xbmcgui.Dialog().ok(__addonname__, '历史记录为空或格式有误 %s' % str(e))
			pass
		fHandle.close()

	pageSize = 100
	totalPage = int((len(historyList)+pageSize-1)/pageSize)

	change = params.get('change')
	if not change: # 首次进入
		page = 1

	else: # 非首次进入
		if change == 'page': # 改变页数
			curPage = int(params.get('curpage'))
			pageList = []
			if curPage>1: pageList.append('上一页')
			for i in range(1, totalPage+1): pageList.append(str(i))
			if curPage<totalPage: pageList.append('下一页')
			select = xbmcgui.Dialog().select('改变页数', createSelect(pageList, -1, str(curPage)))
			if select == -1 or pageList[select] == str(curPage): return
			if pageList[select] == '上一页': page = curPage-1
			elif pageList[select] == '下一页': page = curPage+1
			else: page = int(pageList[select])

		elif change == 'refresh': # 刷新列表
			page = int(params.get('curpage'))

	# 显示视频
	videoList = historyList[(page-1)*pageSize: min(page*pageSize, len(historyList))]
	for i, entry in enumerate(videoList):
		video_url = entry.get('url')
		label = entry.get('label')
		poster = entry.get('thumb')

		if None in [video_url, label, poster]:
			if xbmcgui.Dialog().yesno(__addonname__, '第%s条历史记录格式有误，是否清除记录' % str(i+1)):
				os.remove(filePath)
				break
			else: continue

		item = xbmcgui.ListItem(label)
		item.setArt({'poster': poster})
		item_url = createUrl({'mode': 'play', 'url': video_url, 'label': label, 'thumb': poster})
		item.addContextMenuItems([('删除单条记录', 'RunPlugin(%s)' % createUrl({'mode': 'delete', 'index': str(i+(page-1)*pageSize), 'curpage': str(page-int(len(videoList)==1 and totalPage!=1))})), ('删除全部记录', 'RunPlugin(%s)' % createUrl({'mode': 'clear'})), ('采集方式…', 'RunPlugin(%s)' % createUrl({'mode': 'play', 'url': video_url, 'label': label, 'thumb': poster, 'type': 'series'})), ('解析方式…', 'RunPlugin(%s)' % createUrl({'mode': 'play', 'url': video_url, 'label': label, 'thumb': poster, 'type': 'video'}))])
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, False)

	# 显示页数
	pageStr = ''
	if totalPage>1:
		item = xbmcgui.ListItem('[COLOR yellow][B]页数：[/B]第%d页[/COLOR]' % page)
		item.setArt({'poster': defaultPic})
		item_url = createUrl({'mode': 'history', 'change': 'page', 'curpage': str(page)})
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

		pageStr = ' 第%d页' % page

	# 设置内容
	xbmcplugin.setContent(pHandle, 'videos')
	xbmcplugin.setPluginCategory(pHandle, '历史'+pageStr)
	xbmcplugin.endOfDirectory(pHandle)

	# 设置视图
	forceview = __addon__.getSetting('forceview')
	if forceview == 'true': setView('500')

def getInterface(type):
	interfaces = {'series': [('采集接口1', 'lib.kuyunzy'),
                             ('采集接口2', 'lib.zuidazy')],
                   'video': [('解析接口1', 'lib.ckmov'),
                             ('解析接口2', 'lib.i607p')]}
	return interfaces[type]

def playVideo():
	infoLabels = {}
	url = params.get('url')
	label = params.get('label')
	poster = params.get('thumb')
	type = params.get('type')
	if type: # 调用接口
		interfaceList = getInterface(type)
		try:
			select = xbmcgui.Dialog().contextmenu(createSelect(interfaceList, 0))
		except AttributeError:
			select = xbmcgui.Dialog().select(label, createSelect(interfaceList, 0))
		if select == -1: return # 取消

		pDialog = xbmcgui.DialogProgress()
		pDialog.create(__addonname__)
		pDialog.update(50, '正在调用 [%s] 获取 [%s] 视频源' % (interfaceList[select][0], label))
		interface = __import__(interfaceList[select][1], fromlist=['getVideo'])
		getVideo = interface.getVideo
		sorttype = __addon__.getSetting('sorttype')
		video = getVideo(videoUrl=url, videoLabel=label, sorttype=sorttype)
		if pDialog.iscanceled(): return # 取消

		if video[0] == -1: return # 取消
		elif video[0] == 0: # 失败
			xbmcgui.Dialog().ok(__addonname__, video[1])
			return
		else: # 成功
			m3u = video[1]

	else: # 非调用接口
		# 获取视频基本信息
		pDialog = xbmcgui.DialogProgress()
		pDialog.create(__addonname__)
		pDialog.update(25, '正在获取 [%s] 视频源，请稍等' % label)
		httpData = getHttpData(url)
		if pDialog.iscanceled(): return
		if not httpData: return

		regex = re.compile('<head itemprop="video"', re.DOTALL)
		match = regex.search(httpData)
		if not match: # 网页动态生成
			reg = re.compile('<div class="cms-qipuId" data-qipuId="(.+?)"', re.DOTALL)
			mat = reg.search(httpData)
			if not mat:
				xbmcgui.Dialog().ok(__addonname__, '无法获取视频信息 %s' % url)
				return
			url = 'http://www.iqiyi.com/v_%s.html' % mat.group(1)
			pDialog.update(25, '正在获取 [%s] 视频源，请稍等' % label)
			httpData = getHttpData(url)
			if pDialog.iscanceled(): return
			if not httpData: return

		regex = re.compile('data-player-tvid="(.+?)" data-player-videoid="(.+?)"', re.DOTALL)
		match = regex.search(httpData)
		if not match:
			xbmcgui.Dialog().ok(__addonname__, '无法获取视频信息 %s' % url)
			return
		tvid = match.group(1)
		videoid = match.group(2)

		regex = re.compile('<script type="application/ld\\+json">.*?"description": "(.*?)",\s*"thumbnailUrl":"(.*?)".*?</script>', re.DOTALL)
		match = regex.search(httpData)
		if match:
			poster = 'http:' + match.group(2)
			infoLabels['plot'] = match.group(1).replace('\n', '').replace('\r', '').replace('　', '')

		# 获取视频播放信息
		t = int(time.time() * 1000)
		src = '76f90cbd92f94a2e925d83e8ccd22cb7'
		key = 'd5fb4bd9d50c4be6948c97edd7254b0e'
		sc = hashlib.md5(str(t)+key+videoid).hexdigest()
		cache_url = 'http://cache.m.iqiyi.com/tmts/{0}/{1}/?t={2}&sc={3}&src={4}'.format(tvid,videoid,t,sc,src)
		pDialog.update(50, '正在解析视频源 [%s] ，请稍等' % label)
		httpData = getHttpData(cache_url)
		if pDialog.iscanceled(): return
		if not httpData: return

		playInfo = simplejson.loads(httpData.replace('\n', '').replace('\r', '').replace('　', ''))

		# 选择不同清晰度的视频地址并播放
		if playInfo['code'] != 'A00000':
			xbmcgui.Dialog().ok(__addonname__, '当前视频无法播放 %s' % playInfo['code'])
			return

		VRList = []
		videoLink = playInfo['data']['vidl']
		for i, entry in enumerate(videoLink):
			screenSize = entry.get('screenSize')
			fileFormat = entry.get('fileFormat')
			if not fileFormat: VRList.append([screenSize, i])
			else: VRList.append([screenSize+' '+fileFormat, i])

		pDialog.update(75, '正在选择 [%s] 清晰度，请稍等' % label)
		VRList.sort(key=sort_key, reverse=True)
		resolution = __addon__.getSetting('resolution')
		if resolution == '0': #每次询问
			selectList = [entry[0] for entry in VRList]
			select = xbmcgui.Dialog().select('选择清晰度', selectList)
			if select == -1: return
			index = VRList[select][1]
		elif resolution == '1': index = VRList[0][1] # 画质优先
		elif resolution == '2': index = VRList[-1][1] # 速度优先
		m3u = videoLink[index]['m3u']

	# 准备播放视频
	pDialog.update(100, '视频源 [%s] 解析成功，准备播放' % label)
	item = xbmcgui.ListItem(label)
	item.setArt({'poster': poster})
	item.setInfo('video', infoLabels)
	if pDialog.iscanceled(): return

	xbmc.Player().play(m3u, item) # 播放视频
	if not type: saveHistory({'url': url, 'label': label, 'thumb': poster}) # 保存历史

	pDialog.close()

# 主程序
addon_url = sys.argv[0]
pHandle = int(sys.argv[1])
params = dict(urlparse.parse_qsl(sys.argv[2][1:]))
mode = params.get('mode')

defaultPic = os.path.join(getAddonDir(), 'media', 'default.png')

# 导航
if mode == None:
	showRoot()

# 列表
elif mode == 'list':
	showList()

# 专辑
elif mode == 'series':
	showSeries()

# 播单
elif mode == 'playlist':
	showPlaylist()

# 专题
elif mode == 'topic':
	showTopic()

# 内容
elif mode == 'content':
	showContent()

# 热搜
elif mode == 'hot':
	showHot()

# 搜索
elif mode == 'search':
	showSearch()

# 历史
elif mode == 'history':
	showHistory()

# 播放
elif mode == 'play':
	playVideo()

# 删除单条记录
elif mode == 'delete':
	deleteHistory()

# 清除历史记录
elif mode == 'clear':
	clearHistory()