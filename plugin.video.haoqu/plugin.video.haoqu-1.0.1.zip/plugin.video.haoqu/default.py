﻿# -*- coding: utf-8 -*-
import xbmc, xbmcgui, xbmcplugin, xbmcaddon, xbmcvfs
import urllib2, urllib, urlparse, re, sys, os, zlib, simplejson, HTMLParser

# 编码
if sys.getdefaultencoding() != 'utf-8':
	reload(sys)
	sys.setdefaultencoding('utf-8')

# 常数
__addonname__ = '好趣电视'
__addonid__   = 'plugin.video.haoqu'
__addon__     = xbmcaddon.Addon(id=__addonid__)

# 函数
def logData(data, filePath='C:\Users\Administrator\Desktop\%s.txt' % __addonname__):
	filePath = filePath.decode('utf-8')
	fHandle = open(filePath, 'w')
	fHandle.write(data)
	fHandle.close()

def dialog(str, type='ok'):
	if type == 'ok': xbmcgui.Dialog().ok(__addonname__, str)
	elif type == 'textviewer': xbmcgui.Dialog().textviewer(__addonname__, str)

def saveHistory(history):
	dataDir = getDataDir()
	filePath = os.path.join(dataDir, 'history.log')
	if not os.path.exists(filePath): # 文件不存在则创建文件
		fHandle = open(filePath, 'w')
		historyList = [history]

	else: # 文件存在则读取文件
		try:
			fHandle = open(filePath, 'r+')
			historyList = simplejson.load(fHandle)
			if history in historyList: historyList.remove(history)
			historyList.insert(0, history)
			fHandle.seek(0, 0)
		except simplejson.scanner.JSONDecodeError: # 文件非json格式则重新创建文件
			fHandle = open(filePath, 'w')
			historyList = [history]
			pass

	simplejson.dump(historyList, fHandle, ensure_ascii=False)
	fHandle.close()

def deleteHistory():
	index = int(params.get('index'))

	dataDir = getDataDir()
	filePath = os.path.join(dataDir, 'history.log')
	fHandle = open(filePath, 'r+')

	historyList = simplejson.load(fHandle)
	if xbmcgui.Dialog().yesno(__addonname__, '确定要删除历史记录 [%s] 吗' % historyList[index]['label']):
		historyList.pop(index)
		fHandle.seek(0, 0)
		fHandle.truncate()
		simplejson.dump(historyList, fHandle, ensure_ascii=False)

		page = params.get('curpage')
		xbmc.executebuiltin('Container.Update(%s,replace)' % createUrl({'mode': 'history', 'change': 'refresh', 'curpage': page}))

	fHandle.close()

def clearHistory():
	dataDir = getDataDir()
	filePath = os.path.join(dataDir, 'history.log')
	if os.path.exists(filePath):
		fHandle = open(filePath, 'r')
		try:
			historyList = simplejson.load(fHandle)
			fHandle.close()
			if xbmcgui.Dialog().yesno(__addonname__, '历史记录共%d条，是否清除' % len(historyList)):
				os.remove(filePath)
				xbmcgui.Dialog().ok(__addonname__, '清除记录成功，共%d条' % len(historyList))

		except simplejson.scanner.JSONDecodeError:
			fHandle.close()
			if xbmcgui.Dialog().yesno(__addonname__, '历史记录为空或格式有误，是否清除'):
				os.remove(filePath)
				xbmcgui.Dialog().ok(__addonname__, '清除记录成功')

	else: xbmcgui.Dialog().ok(__addonname__, '历史记录不存在')

def addChannel():
	m3uFile = xbmcgui.Dialog().browse(1, '选择要添加的自定义频道M3U文件', 'files', '.m3u').decode('utf-8')
	if not m3uFile: return

	dataDir = getDataDir()
	m3uDir = os.path.join(dataDir, 'M3U')
	if not os.path.exists(m3uDir): os.makedirs(m3uDir)

	m3uName = os.path.basename(m3uFile)
	if m3uName in [entry.decode('utf-8') for entry in os.listdir(m3uDir)]:
		copy = xbmcgui.Dialog().yesno(__addonname__, 'M3U文件 [%s] 已存在，是否更新' % m3uName)
		if not copy: return

	xbmcvfs.copy(m3uFile, os.path.join(m3uDir, m3uName))
	xbmcgui.Dialog().ok(__addonname__, '成功添加M3U文件 [%s]' % m3uName)

def removeChannel():
	dataDir = getDataDir()
	m3uDir = os.path.join(dataDir, 'M3U', '')

	m3uFile = xbmcgui.Dialog().browse(1, '选择要删除的自定义频道M3U文件', 'files', '.m3u', defaultt=m3uDir).decode('utf-8')
	m3uName = os.path.basename(m3uFile)
	if not m3uName: return

	delete = xbmcgui.Dialog().yesno(__addonname__, '确定要删除M3U文件 [%s] 吗' % m3uName)
	if not delete: return

	os.remove(m3uFile)
	xbmcgui.Dialog().ok(__addonname__, '成功删除M3U文件 [%s]' % m3uName)

def manageChannel():
	list = ['添加自定义频道', '删除自定义频道']
	while True:
		select = xbmcgui.Dialog().select('管理自定义频道', list)
		if select == -1: break
		elif select == 0: addChannel()
		elif select == 1: removeChannel()

def getDataDir():
	dataDir = xbmc.translatePath( __addon__.getAddonInfo('profile')).decode('utf-8')
	if not os.path.exists(dataDir): os.makedirs(dataDir)
	return dataDir

def getAddonDir():
	addonDir = xbmc.translatePath( __addon__.getAddonInfo('path')).decode('utf-8')
	return addonDir

def getHttpData(url, notify=True, charset='gbk', redirect=False):
	request = urllib2.Request(url)
	request.add_header('User-Agent', 'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0)')

	maxtimes = 10
	for t in range(maxtimes):
		try:
			response = urllib2.urlopen(request)
			httpData = response.read()
			reUrl = response.geturl()
			break
		except Exception, e:
			if '11004' in str(e):
				if t<maxtimes-1: continue
				else:
					if notify: xbmcgui.Dialog().ok(__addonname__, '网络错误 %s %s %d次' % (url, str(e), maxtimes))
			else:
				if notify: xbmcgui.Dialog().ok(__addonname__, '网络错误 %s %s' % (url, str(e)))
			return

	if response.headers.get('content-encoding', None) == 'gzip':
		httpData = zlib.decompress(httpData, zlib.MAX_WBITS|32)

	response.close()
	httpData = httpData.decode(charset, 'ignore')
	if redirect: return (reUrl, httpData)
	else: return httpData

def getUrl(playUrl, playType):
	if not playType or playUrl in ['/static/js/play/stop.html', '/static/js/play/noplay.html']: return

	elif playType in ['m3u8', 'flv']: m3u = playUrl

	elif playType == 'iframe':
		if playUrl.startswith('http://player.haoqu.net/swf.html?id='):
			playUrl = dict(urlparse.parse_qsl(urlparse.urlparse(playUrl).query)).get('id')
			m3u = getUrl(playUrl, 'iframe')

		elif playUrl.startswith('http://player.haoqu.net/m3u8.html?id='):
			m3u = playUrl.split('m3u8.html?id=')[1]

		elif playUrl.startswith('http://player.haoqu.net/alim3u8.html?id='):
			m3u = playUrl.split('alim3u8.html?id=')[1]

		elif playUrl.startswith('http://player.haoqu.net/ali.html?id='):
			m3u = playUrl.split('ali.html?id=')[1]

		elif playUrl.startswith('http://g.alicdn.com/de/prismplayer-flash/1.2.16/PrismPlayer.swf?vurl='): # 阿里线路
			m3u = playUrl.split('PrismPlayer.swf?vurl=')[1]

		elif playUrl.startswith('http://www.p5w.net/tradingday/swfs/qjwjyrlive.swf?src='): # 官方线路
			m3u = playUrl.split('qjwjyrlive.swf?src=')[1]

		elif playUrl.startswith('http://player.haoqu.net/cctv888.html?id='): # 直播 + 回看
			url = playUrl
			httpData = getHttpData(url, False)
			if not httpData: return

			regex = re.compile('src="(.+?)"', re.DOTALL)
			match = regex.search(httpData)
			if not match: return

			chanelSrc = match.group(1)
			channelID = dict(urlparse.parse_qsl(urlparse.urlparse(playUrl).query)).get('id')
			m3u = chanelSrc.replace("'+id+'", channelID)

		elif playUrl.startswith('http://p.18kf.net/mg2/m3u8.php?k=migu&url='): # MG多线
			url = playUrl
			httpData = getHttpData(url, False, 'utf-8')
			if not httpData: return

			regex = re.compile('var u = "(.+?)",', re.DOTALL)
			match = regex.search(httpData)
			if not match: return

			m3u = match.group(1)

		elif playUrl.startswith('http://player.haoqu.net/hoge/'): # 官方线路
			url = playUrl
			reUrl, httpData = getHttpData(url, False, 'utf-8', True)
			if not httpData: return

			if reUrl != playUrl: m3u = reUrl.split('m3u8.html?id=')[1]
			else:
				regex = re.compile('var video=\["(.+?)"\];', re.DOTALL)
				match = regex.search(httpData)
				if not match: return

				m3u = match.group(1)

		elif playUrl.startswith('http://player.66zhibo.net/hoge/'): # 官方线路
			url = playUrl
			reUrl, httpData = getHttpData(url, False, 'utf-8', True)
			if not httpData: return

			if reUrl != playUrl: m3u = reUrl.split('m3u8.html?id=')[1]
			else:
				regex = re.compile('var video=\["(.+?)"\];', re.DOTALL)
				match = regex.search(httpData)
				if not match: return

				m3u = match.group(1)

		elif playUrl.startswith('http://player.haoqu.net/00/allook'): # All线路
			url = playUrl
			httpData = getHttpData(url, False, 'utf-8')
			if not httpData: return

			regex = re.compile('innerHTML = \'<video src="([^"]+)"', re.DOTALL)
			match = regex.search(httpData)
			if not match: return

			m3u = match.group(1)

		elif playUrl.startswith('https://channel.gztv.com/'): # 广州官播线路
			url = playUrl
			httpData = getHttpData(url, False, 'utf-8')
			if not httpData: return

			regex = re.compile("var standardUrl='(.+?)';", re.DOTALL)
			match = regex.search(httpData)
			if not match: return

			m3u = match.group(1)

		elif playUrl.startswith('http://www.cctbn.com/'): # 中国交通官方高清
			url = playUrl
			httpData = getHttpData(url, False, 'utf-8')
			if not httpData: return

			regex = re.compile("var id = (\d+);\s*\$\.ajax\(\{\s*url: '(.+?)' \+ id,", re.DOTALL)
			match = regex.search(httpData)
			if not match: return

			url = match.group(2) + match.group(1)
			httpData = getHttpData(url, False, 'utf-8')
			if not httpData: return

			playInfo = simplejson.loads(httpData[1:-1])[0]
			m3u = playInfo['m3u8url']

		elif playUrl.startswith('http://player.hunantv.com/'): # 芒果高清
			url = 'http://mpplive.api.mgtv.com/v1/epg/turnplay/getLiveBuss?version=PCweb_1.0&platform=4'
			httpData = getHttpData(url, False, 'utf-8')
			if not httpData: return

			liveBussInfo = simplejson.loads(httpData)
			bussID = liveBussInfo['data']['buss_id']
			chanelID = dict(urlparse.parse_qsl(urlparse.urlparse(playUrl).query)).get('channel_id')
			url = 'http://mpp.liveapi.mgtv.com/v1/epg/turnplay/getLivePlayUrlMPP?version=PCweb_1.0&platform=4&buss_id=%s&channel_id=%s' % (bussID, chanelID)
			httpData = getHttpData(url, False, 'utf-8')
			if not httpData: return

			livePlayInfo = simplejson.loads(httpData)
			if livePlayInfo['msg'] != '成功': return

			m3u = livePlayInfo['data']['url']

		elif playUrl.startswith('http://116.199.5.51:8114/'): m3u = playUrl # 珠江宽频

		elif playUrl.startswith('http://player.haoqu.net/hoge.html?id='): return # GRTN直播不能播放？swf参数显示问题

		elif playUrl.startswith('http://player.haoqu.net/cutv.html?id='): return # CU线路不能播放？

		elif playUrl.startswith('http://player.haoqu.net/qk.php?u='): return # QK多线不能播放？

		elif playUrl.startswith('http://player.haoqu.net/qq.html?id='): return # QQ高清不能播放？

		elif playUrl.startswith('http://67.230.188.214/play.html?id='): return # 官播线路不能播放？

		elif playUrl.startswith('http://player.haoqu.net/play.html?id='): return # 官方线路不能播放？

		elif playUrl.startswith('http://player.haoqu.net/ckplayer.html?id='): return # 安徽官方FLV不能播放？

		elif playUrl.startswith('http://player.haoqu.net/iframe.html?id='): return # 外部地址不能播放

		elif playUrl.startswith('http://player.haoqu.net/00/migujs/migu.html?id='): return # MG线路不能播放？

		elif playUrl.startswith('http://24htv.ucoz.com/wltv/lb/play.html?id='): return # MG标清不能播放

		elif playUrl.startswith('http://player.haoqu.net/outplay2/?id='): return # 外部地址不能播放

		elif playUrl.startswith('http://player.haoqu.net/outplay/?id='): return # 外部地址不能播放

		elif playUrl.startswith('http://player.66zhibo.net/outplay/?id='): return # 官网直播不能播放

		elif playUrl.startswith('http://www.haoqu.net/out/2/'): return # 官网直播不能播放？

		elif playUrl.startswith('http://player.haoqu.net/outplay/tv/'): return # 多线高清不能播放？

		elif playUrl.startswith('http://player.haoqu.net/prov/'): return # 外部地址不能播放

		elif playUrl.startswith('http://player.haoqu.net/17/'): return # 官方线路不能播放

		elif playUrl.startswith('http://app.cjyun.org/'): return # 湖北快乐成长官方线路不能播放

		elif playUrl.startswith('http://www.sktv.com.cn/'): return # 蛇口官方播放器不能播放

		elif playUrl.startswith('http://www.thwlgbds.org.cn:8787/'): return # 通化官方播放器不能播放

		elif playUrl.startswith('http://mas.vtibet.com/'): return # 西藏官方播放器不能播放

		elif playUrl.startswith('http://www.mytaizhou.net/'): return # 泰州站外直播不能播放

		elif playUrl.startswith('http://www.csztv.com/'): return # 苏州官网直播不能播放

		elif playUrl.startswith('http://www.jdtv.sh.cn/'): return # 嘉定官方直播不能播放

		elif playUrl.startswith('http://www.aqbtv.cn:8080/'): return # 安庆官方直播不能播放

		elif playUrl.startswith('http://www.anqiutv.com:9080/'): return # 安丘官播线路不能播放

		elif playUrl.startswith('http://www.ncntv.com.cn:8787/'): return # 南充官播线路不能播放

		elif playUrl.startswith('http://app.jnnews.tv/'): return # 济宁官网直播不能播放

		elif playUrl.startswith('http://www.hznet.tv:7575/'): return # 荷泽官网直播不能播放

		elif playUrl.startswith('https://tv.huijiayou.cn/'): return # 贵州家有购物官网直播不能播放

		elif playUrl.startswith('http://www.rzw.com.cn/'): return # 日照站外直播不能播放

		elif playUrl.startswith('http://www.qthtv.com:8080/'): return # 七台河官方播放器不能播放

		elif playUrl.startswith('http://player.cncnews.cn/'): return # 新华社cnc官方线路不能播放

		elif playUrl.startswith('http://vodmall.imbc.com/'): return # 韩国mbc官方线路不能播放

		elif playUrl.startswith('https://myk.kbs.co.kr/'): return # 韩国kbs官方线路不能播放

		elif playUrl.startswith('http://www.kan-tv.com/'): return # 韩国sbs官方线路不能播放

		elif playUrl.startswith('http://123.207.42.38/'): return # IN线路不能播放

		else: return

	else: return

	return m3u

def createSelect(list, index, value):
	result = []
	if index == -1: #  一元列表
		for entry in list:
			if entry == value: result.append('[%s]' % value)
			else: result.append(entry)
	else: #  多元列表
		for entry in list:
			if entry[index] == value: result.append('[%s]' % value)
			else: result.append(entry[index])
	return result

def createUrl(urlInfo):
	url = '%s?' % addon_url
	for key, value in urlInfo.items():
		url += '%s=%s&' % (key, urllib.quote(value.encode('utf-8')))
	url.rstrip('&')
	return url

def arrangeList(originalList):
	newList = []
	for entry in originalList:
		if entry not in newList:
			newList.append(entry)
	return newList

def escapeRegex(originalStr):
	regexStr = '$()*+.[]?\^{}|'
	newStr = ''
	for entry in originalStr:
		if entry in regexStr:
			newStr += '\\'
		newStr += entry
	return newStr

def showRoot():
	# 显示导航
	items = [('按地区', 'area'), ('按类型', 'type'), ('历史记录', 'history')]

	# 判断有无自定义频道
	dataDir = getDataDir()
	m3uDir = os.path.join(dataDir, 'M3U')
	if os.path.exists(m3uDir):
		m3uList = [entry.decode('utf-8') for entry in os.listdir(m3uDir) if entry.endswith('.m3u')]
		if m3uList: items.insert(2, ('自定义', 'custom'))

	for entry in items:
		item = xbmcgui.ListItem(entry[0])
		item.setArt({'poster': defaultPic})
		item_url = createUrl({'mode': entry[1]})
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

	# 设置内容
	xbmcplugin.setContent(pHandle, 'files')
	xbmcplugin.endOfDirectory(pHandle)

def showArea():
	url = 'http://www.haoqu.net/zhibo/'
	httpData = getHttpData(url)
	if not httpData: return

	# 显示地区
	regex = re.compile('<li date-id="\d+" class="item"><a href="(/\d+/[^"]*)">(.+?)</a></li>', re.DOTALL)
	match = regex.findall(httpData)
	for entry in match:
		label = HTMLParser.HTMLParser().unescape(entry[1])
		area_url = entry[0]
		item = xbmcgui.ListItem(label)
		item.setArt({'poster': defaultPic})
		item_url = createUrl({'mode': 'channel', 'url': area_url, 'cate': label})
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

	# 设置内容
	xbmcplugin.setContent(pHandle, 'files')
	xbmcplugin.setPluginCategory(pHandle, '按地区')
	xbmcplugin.endOfDirectory(pHandle)

def showType():
	url = 'http://www.haoqu.net/zhibo/'
	httpData = getHttpData(url)
	if not httpData: return

	# 显示类型
	regex = re.compile('<li date-id="c\d+"  class="item"><a href="\.\./\.\.(/zhibo/.+?/)">(.+?)</a></li>', re.DOTALL)
	match = regex.findall(httpData)
	for entry in match:
		label = HTMLParser.HTMLParser().unescape(entry[1])
		type_url = entry[0]
		item = xbmcgui.ListItem(label)
		item.setArt({'poster': defaultPic})
		item_url = createUrl({'mode': 'channel', 'url': type_url, 'cate': label})
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

	# 设置内容
	xbmcplugin.setContent(pHandle, 'files')
	xbmcplugin.setPluginCategory(pHandle, '按类型')
	xbmcplugin.endOfDirectory(pHandle)

def showCustom():
	# 显示自定义频道M3U文件
	dataDir = getDataDir()
	m3uDir = os.path.join(dataDir, 'M3U')
	if os.path.exists(m3uDir):
		m3uList = [entry.decode('utf-8') for entry in os.listdir(m3uDir) if entry.endswith('.m3u')]
		for entry in m3uList:
			label = entry.rstrip('.m3u')
			item = xbmcgui.ListItem(label)
			item.setArt({'poster': defaultPic})
			item_url = createUrl({'mode': 'channel', 'm3u': label, 'cate': label})
			xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

	# 设置内容
	xbmcplugin.setContent(pHandle, 'files')
	xbmcplugin.setPluginCategory(pHandle, '自定义频道')
	xbmcplugin.endOfDirectory(pHandle)

def showChannel():
	pageSize = 100

	url = params.get('url')
	m3u = params.get('m3u')
	cate = params.get('cate')
	change = params.get('change')
	if url: # 显示直播频道
		if not change: # 首次进入
			page = 1

		elif change == 'page': # 改变页数
			curPage = int(params.get('curpage'))
			totalPage = int(params.get('totalpage'))
			pageList = []
			if curPage>1: pageList.append('上一页')
			for i in range(1, totalPage+1): pageList.append(str(i))
			if curPage<totalPage: pageList.append('下一页')
			select = xbmcgui.Dialog().select('改变页数', createSelect(pageList, -1, str(curPage)))
			if select == -1 or pageList[select] == str(curPage): return
			if pageList[select] == '上一页': page = curPage-1
			elif pageList[select] == '下一页': page = curPage+1
			else: page = int(pageList[select])

		if url.startswith('http'): pass
		else: url = 'http://www.haoqu.net' + url
		httpData = getHttpData(url)
		if not httpData: return

		# 显示视频
		regex = re.compile('<li class="p-item"> <a href="(.+?)" class="thumb-outer" title=".*?"(?: target="_blank")?> <img class=\'thumb\' src=\'(.+?)\' alt=\'(.+?)\'/> <span class="t"><strong class="s">\\3</strong></span> </a> </li>', re.DOTALL)
		match = regex.findall(httpData)

		reg = re.compile('<a href="/zhibo/([^/]+)/index_(\d+)\.html">\\2</a><a href="/zhibo/\\1/index_\d+\.html">[^\d]+</a>', re.DOTALL)
		mat = reg.search(httpData)
		if mat: # 有多页的
			lastPage = int(mat.group(2))
			for i in range(2, lastPage+1):
				tempUrl = url + 'index_%d.html' % i
				httpData = getHttpData(tempUrl)
				if not httpData: return

				reg = re.compile('<li class="p-item"> <a href="(.+?)" class="thumb-outer" title=".*?"(?: target="_blank")?> <img class=\'thumb\' src=\'(.+?)\' alt=\'(.+?)\'/> <span class="t"><strong class="s">\\3</strong></span> </a> </li>', re.DOTALL)
				mat = reg.findall(httpData)
				match.extend(mat)

		videoList = match[(page-1)*pageSize: min(page*pageSize, len(match))]
		for entry in videoList:
			video_url = entry[0]
			poster = entry[1]
			if poster.startswith('http'): pass
			else: poster = 'http://www.haoqu.net' + poster
			label = HTMLParser.HTMLParser().unescape(entry[2])

			item = xbmcgui.ListItem(label)
			item.setArt({'poster': poster})
			item_url = createUrl({'mode': 'play', 'url': video_url, 'label': label, 'thumb': poster})
			xbmcplugin.addDirectoryItem(pHandle, item_url, item, False)

		# 显示页数
		totalPage = int((len(match)+pageSize-1)/pageSize)
		if totalPage>1:
			item = xbmcgui.ListItem('[COLOR yellow][B]页数：[/B]第%d页[/COLOR]' % page)
			item.setArt({'poster': defaultPic})
			item_url = createUrl({'mode': 'channel', 'change': 'page', 'curpage': str(page), 'totalpage': str(totalPage), 'url': url, 'cate': cate})
			xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

			cate += ' 第%d页' % page

	if m3u: # 显示自定义频道
		if not change: # 首次进入
			page = 1

		elif change == 'page': # 改变页数
			curPage = int(params.get('curpage'))
			totalPage = int(params.get('totalpage'))
			pageList = []
			if curPage>1: pageList.append('上一页')
			for i in range(1, totalPage+1): pageList.append(str(i))
			if curPage<totalPage: pageList.append('下一页')
			select = xbmcgui.Dialog().select('改变页数', createSelect(pageList, -1, str(curPage)))
			if select == -1 or pageList[select] == str(curPage): return
			if pageList[select] == '上一页': page = curPage-1
			elif pageList[select] == '下一页': page = curPage+1
			else: page = int(pageList[select])

		dataDir = getDataDir()
		m3uFile = os.path.join(dataDir, 'M3U', '%s.m3u' % m3u)
		if not os.path.exists(m3uFile):
			xbmcgui.Dialog().ok(__addonname__, '文件错误 %s' % m3uFile)
			return

		fHandle = open(m3uFile, 'r')
		m3uData = fHandle.read()
		fHandle.close()

		# 显示视频
		regex = re.compile('#EXTINF:.*?,(.*?)$', re.MULTILINE)
		match = regex.findall(m3uData)
		channelList = arrangeList(match)
		videoList = channelList[(page-1)*pageSize: min(page*pageSize, len(channelList))]
		for entry in videoList:
			video_url = m3uFile
			label = entry
			poster = customPic

			item = xbmcgui.ListItem(label)
			item.setArt({'poster': poster})
			item_url = createUrl({'mode': 'play', 'url': video_url, 'label': label, 'thumb': poster})
			xbmcplugin.addDirectoryItem(pHandle, item_url, item, False)

		# 显示页数
		totalPage = int((len(channelList)+pageSize-1)/pageSize)
		if totalPage>1:
			item = xbmcgui.ListItem('[COLOR yellow][B]页数：[/B]第%d页[/COLOR]' % page)
			item.setArt({'poster': defaultPic})
			item_url = createUrl({'mode': 'channel', 'change': 'page', 'curpage': str(page), 'totalpage': str(totalPage), 'm3u': m3u, 'cate': cate})
			xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

			cate += ' 第%d页' % page

	# 设置内容
	xbmcplugin.setContent(pHandle, 'videos')
	xbmc.executebuiltin('container.SetViewMode(500)')
	xbmcplugin.setPluginCategory(pHandle, cate)
	xbmcplugin.endOfDirectory(pHandle)

def showHistory():
	# 读取历史记录
	dataDir = getDataDir()
	filePath = os.path.join(dataDir, 'history.log')
	historyList = []
	if os.path.exists(filePath):
		fHandle = open(filePath, 'r')
		try:
			historyList = simplejson.load(fHandle)
		except simplejson.scanner.JSONDecodeError, e:
			xbmcgui.Dialog().ok(__addonname__, '历史记录为空或格式有误 %s' % str(e))
			pass
		fHandle.close()

	pageSize = 100
	totalPage = int((len(historyList)+pageSize-1)/pageSize)

	change = params.get('change')
	if change == None:  # 首次进入
		page = 1

	elif change == 'page': # 改变页数
		curPage = int(params.get('curpage'))
		pageList = []
		if curPage>1: pageList.append('上一页')
		for i in range(1, totalPage+1): pageList.append(str(i))
		if curPage<totalPage: pageList.append('下一页')
		select = xbmcgui.Dialog().select('改变页数', createSelect(pageList, -1, str(curPage)))
		if select == -1 or pageList[select] == str(curPage): return
		if pageList[select] == '上一页': page = curPage-1
		elif pageList[select] == '下一页': page = curPage+1
		else: page = int(pageList[select])

	elif change == 'refresh': # 刷新列表
		page = int(params.get('curpage'))

	# 显示视频
	videoList = historyList[(page-1)*pageSize: min(page*pageSize, len(historyList))]
	for i, entry in enumerate(videoList):
		url = entry.get('url', ' ')
		label = entry.get('label', ' ')
		poster = entry.get('thumb', ' ')

		item = xbmcgui.ListItem(label)
		item.setArt({'poster': poster})
		item.addContextMenuItems([('删除单条记录', 'RunPlugin(%s)' % createUrl({'mode': 'delete', 'index': str(i+(page-1)*pageSize), 'curpage': str(page-int(len(videoList)==1 and totalPage!=1))}))])
		item_url = createUrl({'mode': 'play', 'url': url, 'label': label, 'thumb': poster})
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, False)

	# 显示页数
	cate = '历史记录'
	if totalPage>1:
		item = xbmcgui.ListItem('[COLOR yellow][B]页数：[/B]第%d页[/COLOR]' % page)
		item.setArt({'poster': defaultPic})
		item_url = createUrl({'mode': 'history', 'change': 'page', 'curpage': str(page)})
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

		cate += ' 第%d页' % page

	# 设置内容 及 视图
	xbmcplugin.setContent(pHandle, 'videos')
	xbmc.executebuiltin('container.SetViewMode(500)')
	xbmcplugin.setPluginCategory(pHandle, cate)
	xbmcplugin.endOfDirectory(pHandle)

def playVideo():
	videoUrl = params.get('url')
	videoLabel = params.get('label')
	videoThumb = params.get('thumb')

	if videoUrl.endswith('.html'): # 直播频道
		# 获取视频信号源
		url = 'http://www.haoqu.net' + videoUrl
		httpData = getHttpData(url)
		if not httpData: return

		regex = re.compile('<li data-player="(\d+)" class="tab-item btn btn-syc(?: btn-syc-select)?"><span class="s">(.+?)</span></li>', re.DOTALL)
		match = regex.findall(httpData)

		playList = []
		pDialog = xbmcgui.DialogProgress()
		pDialog.create(videoLabel)
		for i, entry in enumerate(match):
			pDialog.update(100*(i+1)/len(match), '(%d/%d) 正在解析信号源 [%s]' % (i+1, len(match), entry[1]))
			if pDialog.iscanceled(): return # 取消

			url = 'http://www.haoqu.net/e/extend/tv.php?id=' + entry[0]
			httpData = getHttpData(url, False)
			if not httpData: continue

			reg = re.compile("signal = '(.+?)';", re.DOTALL)
			mat = reg.search(httpData)
			if not mat: continue

			playLabel, playUrl, playType = mat.group(1).split('$')
			m3u = getUrl(playUrl, playType)
			if not m3u: continue

			playList.append((playLabel, m3u))
		pDialog.close()

		# 选择视频信号源
		if len(playList) == 0:
			xbmcgui.Dialog().ok(__addonname__, '暂无信号源，请尝试从好趣网打开视频 %s' % videoUrl)
			return
		elif len(playList) == 1: select = 0
		elif len(playList) > 1:
			select = xbmcgui.Dialog().select(videoLabel, [entry[0] for entry in playList])
			if select == -1: return
		m3u = playList[select][1]

	elif videoUrl.endswith('.m3u'): # 自定义频道
		if not os.path.exists(videoUrl):
			xbmcgui.Dialog().ok(__addonname__, '文件错误 %s' % videoUrl)
			return
		fHandle = open(videoUrl, 'r')
		m3uData = fHandle.read()
		fHandle.close()

		regex = re.compile('#EXTINF:.*?,%s\n(.*?)$' % escapeRegex(videoLabel), re.MULTILINE)
		match = regex.findall(m3uData)
		sourceList = arrangeList(match)
		if len(sourceList) == 0:
			xbmcgui.Dialog().ok(__addonname__, '文件错误 %s' % videoUrl)
			return
		elif len(sourceList) == 1: select = 0
		elif len(sourceList) > 1:
			select = xbmcgui.Dialog().select(videoLabel, ['源%d' % (i+1) for i in range(len(sourceList))])
			if select == -1: return
		m3u = sourceList[select]

	#dialog(m3u, 'textviewer')
	#return

	item = xbmcgui.ListItem(videoLabel)
	xbmc.Player().play(m3u, item) # 播放视频
	saveHistory({'url': videoUrl, 'label': videoLabel, 'thumb': videoThumb}) # 保存历史

# 主程序
addon_url = sys.argv[0]
if sys.argv[1] == 'clear': mode = 'clear'
elif sys.argv[1] == 'manage': mode = 'manage'
else:
	pHandle = int(sys.argv[1])
	params = dict(urlparse.parse_qsl(sys.argv[2][1:]))
	mode = params.get('mode')

defaultPic = os.path.join(getAddonDir(), 'media', 'default.png')
customPic = os.path.join(getAddonDir(), 'media', 'custom.png')

# 导航
if mode == None:
	showRoot()

# 地区
elif mode == 'area':
	showArea()

# 类型
elif mode == 'type':
	showType()

# 自定义
elif mode == 'custom':
	showCustom()

# 频道
elif mode == 'channel':
	showChannel()

# 历史
elif mode == 'history':
	showHistory()

# 播放
elif mode == 'play':
	playVideo()

# 删除单条记录
elif mode == 'delete':
	deleteHistory()

# 清除历史记录
elif mode == 'clear':
	clearHistory()

# 管理自定义频道
elif mode == 'manage':
	manageChannel()