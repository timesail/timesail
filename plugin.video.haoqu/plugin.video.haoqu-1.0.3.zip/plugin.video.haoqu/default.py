﻿# -*- coding: utf-8 -*-
import xbmc, xbmcgui, xbmcplugin, xbmcaddon, xbmcvfs
import urllib, urlparse, re, sys, os, HTMLParser
import simplejson

# 编码
if sys.getdefaultencoding() != 'utf-8':
	reload(sys)
	sys.setdefaultencoding('utf-8')

# 常数
__addonname__ = '好趣电视'
__addonid__   = 'plugin.video.haoqu'
__addon__     = xbmcaddon.Addon(id=__addonid__)

# 函数
def logData(data, filePath='C:\Users\Administrator\Desktop\%s.txt' % __addonname__):
	filePath = filePath.decode('utf-8')
	fHandle = open(filePath, 'w')
	fHandle.write(data)
	fHandle.close()

def dialog(str, type='ok'):
	if type == 'ok': xbmcgui.Dialog().ok(__addonname__, str)
	elif type == 'textviewer': xbmcgui.Dialog().textviewer(__addonname__, str)

def saveHistory(history):
	dataDir = getDataDir()
	filePath = os.path.join(dataDir, 'history.log')
	if not os.path.exists(filePath): # 文件不存在则创建文件
		fHandle = open(filePath, 'w')
		historyList = [history]

	else: # 文件存在则读取文件
		try:
			fHandle = open(filePath, 'r+')
			historyList = simplejson.load(fHandle)
			if history in historyList: historyList.remove(history)
			historyList.insert(0, history)
			fHandle.seek(0, 0)
		except simplejson.scanner.JSONDecodeError: # 文件非json格式则重新创建文件
			fHandle = open(filePath, 'w')
			historyList = [history]
			pass

	simplejson.dump(historyList, fHandle, ensure_ascii=False)
	fHandle.close()

def deleteHistory():
	dataDir = getDataDir()
	filePath = os.path.join(dataDir, 'history.log')
	if os.path.exists(filePath):
		fHandle = open(filePath, 'r+')
		try:
			historyList = simplejson.load(fHandle)
			index = int(params.get('index'))
			if xbmcgui.Dialog().yesno(__addonname__, '确定要删除历史记录 [%s] 吗' % historyList[index]['label']):
				historyList.pop(index)
				fHandle.seek(0, 0)
				fHandle.truncate()
				simplejson.dump(historyList, fHandle, ensure_ascii=False)

				page = params.get('curpage')
				xbmc.executebuiltin('Container.Update(%s,replace)' % createUrl({'mode': 'history', 'change': 'refresh', 'curpage': page}))

		except simplejson.scanner.JSONDecodeError:
			if xbmcgui.Dialog().yesno(__addonname__, '历史记录为空或格式有误，是否清除'):
				os.remove(filePath)
				xbmc.executebuiltin('Container.Update(%s,replace)' % createUrl({'mode': 'history'}))

	else: xbmcgui.Dialog().ok(__addonname__, '历史记录不存在')
	fHandle.close()

def clearHistory():
	dataDir = getDataDir()
	filePath = os.path.join(dataDir, 'history.log')
	if os.path.exists(filePath):
		fHandle = open(filePath, 'r')
		try:
			historyList = simplejson.load(fHandle)
			fHandle.close()
			if xbmcgui.Dialog().yesno(__addonname__, '历史记录共%d条，是否清除' % len(historyList)):
				os.remove(filePath)
				xbmc.executebuiltin('Container.Update(%s,replace)' % createUrl({'mode': 'history'}))

		except simplejson.scanner.JSONDecodeError:
			fHandle.close()
			if xbmcgui.Dialog().yesno(__addonname__, '历史记录为空或格式有误，是否清除'):
				os.remove(filePath)
				xbmc.executebuiltin('Container.Update(%s,replace)' % createUrl({'mode': 'history'}))

	else: xbmcgui.Dialog().ok(__addonname__, '历史记录不存在')

def addChannel():
	m3uFile = xbmcgui.Dialog().browse(1, '选择要添加的自定义频道M3U文件', 'files', '.m3u').decode('utf-8')
	if not m3uFile: return

	dataDir = getDataDir()
	m3uDir = os.path.join(dataDir, 'M3U')
	if not os.path.exists(m3uDir): os.makedirs(m3uDir)

	m3uName = os.path.basename(m3uFile)
	if m3uName in [entry.decode('utf-8') for entry in os.listdir(m3uDir)]:
		copy = xbmcgui.Dialog().yesno(__addonname__, 'M3U文件 [%s] 已存在，是否更新' % m3uName)
		if not copy: return

	xbmcvfs.copy(m3uFile, os.path.join(m3uDir, m3uName))
	xbmcgui.Dialog().ok(__addonname__, '成功添加M3U文件 [%s]' % m3uName)
	xbmc.executebuiltin('Container.Update(%s,replace)' % createUrl({'mode': 'custom'}))

def removeChannel():
	dir = params.get('dir')
	m3u = params.get('m3u')

	m3uFile = os.path.join(dir, m3u).decode('utf-8')
	if not os.path.exists(m3uFile):
		xbmcgui.Dialog().ok(__addonname__, '文件错误 %s' % m3uFile)
		return

	delete = xbmcgui.Dialog().yesno(__addonname__, '确定要删除M3U文件 [%s] 吗' % m3u)
	if not delete: return

	os.remove(m3uFile)
	#xbmcgui.Dialog().ok(__addonname__, '成功删除M3U文件 [%s]' % m3u)
	xbmc.executebuiltin('Container.Update(%s,replace)' % createUrl({'mode': 'custom'}))

def getDataDir():
	dataDir = xbmc.translatePath( __addon__.getAddonInfo('profile')).decode('utf-8')
	if not os.path.exists(dataDir): os.makedirs(dataDir)
	return dataDir

def getAddonDir():
	addonDir = xbmc.translatePath( __addon__.getAddonInfo('path')).decode('utf-8')
	return addonDir

def getHttpData(url, notify=True, charset='gbk', redirect=False):
	import urllib2
	request = urllib2.Request(url)
	request.add_header('User-Agent', 'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0)')

	maxtimes = 10
	for t in range(maxtimes):
		try:
			response = urllib2.urlopen(request)
			httpData = response.read()
			reUrl = response.geturl()
			break
		except Exception, e:
			if '11004' in str(e):
				if t<maxtimes-1: continue
				else:
					if notify: xbmcgui.Dialog().ok(__addonname__, '网络错误 %s %s %d次' % (url, str(e), maxtimes))
			else:
				if notify: xbmcgui.Dialog().ok(__addonname__, '网络错误 %s %s' % (url, str(e)))
			return

	if response.headers.get('content-encoding', None) == 'gzip':
		import zlib
		httpData = zlib.decompress(httpData, zlib.MAX_WBITS|32)

	response.close()
	httpData = httpData.decode(charset, 'ignore')
	if redirect: return (reUrl, httpData)
	else: return httpData

def getUrl(playUrl, playType):
	if not playType or playUrl in ['/static/js/play/stop.html', '/static/js/play/noplay.html']: return

	elif playType in ['m3u8', 'flv']: m3u = playUrl

	elif playType == 'iframe':
		if playUrl.startswith('http://player.haoqu.net/swf.html?id='):
			playUrl = dict(urlparse.parse_qsl(urlparse.urlparse(playUrl).query)).get('id')
			m3u = getUrl(playUrl, 'iframe')

		elif playUrl.startswith('http://player.haoqu.net/m3u8.html?id='):
			m3u = playUrl.split('m3u8.html?id=')[1]

		elif playUrl.startswith('http://player.haoqu.net/alim3u8.html?id='):
			m3u = playUrl.split('alim3u8.html?id=')[1]

		elif playUrl.startswith('http://player.haoqu.net/ali.html?id='):
			m3u = playUrl.split('ali.html?id=')[1]

		elif playUrl.startswith('http://player.ioioz.com/m3u8.html?id='): # 珠江宽频
			m3u = playUrl.split('m3u8.html?id=')[1]

		elif playUrl.startswith('http://g.alicdn.com/de/prismplayer-flash/1.2.16/PrismPlayer.swf?vurl='): # 阿里线路
			m3u = playUrl.split('PrismPlayer.swf?vurl=')[1]

		elif playUrl.startswith('http://www.p5w.net/tradingday/swfs/qjwjyrlive.swf?src='): # 官方线路
			m3u = playUrl.split('qjwjyrlive.swf?src=')[1]

		elif playUrl.startswith('http://player.haoqu.net/cctv888.html?id='): # 直播 + 回看
			url = playUrl
			httpData = getHttpData(url, False)
			if not httpData: return

			regex = re.compile('src="(.+?)"', re.DOTALL)
			match = regex.search(httpData)
			if not match: return

			chanelSrc = match.group(1)
			channelID = dict(urlparse.parse_qsl(urlparse.urlparse(playUrl).query)).get('id')
			m3u = chanelSrc.replace("'+id+'", channelID)

		elif playUrl.startswith('http://p.18kf.net/mg2/m3u8.php?k=migu&url='): # MG多线
			url = playUrl
			httpData = getHttpData(url, False, 'utf-8')
			if not httpData: return

			regex = re.compile('var u = "(.+?)",', re.DOTALL)
			match = regex.search(httpData)
			if not match: return

			m3u = match.group(1)

		elif playUrl.startswith('http://player.haoqu.net/hoge/'): # 官方线路
			url = playUrl
			reUrl, httpData = getHttpData(url, False, 'utf-8', True)
			if not httpData: return

			if reUrl != playUrl: m3u = reUrl.split('m3u8.html?id=')[1]
			else:
				regex = re.compile('var video=\["(.+?)"\];', re.DOTALL)
				match = regex.search(httpData)
				if not match: return

				m3u = match.group(1)

		elif playUrl.startswith('http://player.66zhibo.net/hoge/'): # 官方线路
			url = playUrl
			reUrl, httpData = getHttpData(url, False, 'utf-8', True)
			if not httpData: return

			if reUrl != playUrl: m3u = reUrl.split('m3u8.html?id=')[1]
			else:
				regex = re.compile('var video=\["(.+?)"\];', re.DOTALL)
				match = regex.search(httpData)
				if not match: return

				m3u = match.group(1)

		elif playUrl.startswith('http://player.haoqu.net/00/allook'): # All线路
			url = playUrl
			httpData = getHttpData(url, False, 'utf-8')
			if not httpData: return

			regex = re.compile('innerHTML = \'<video src="([^"]+)"', re.DOTALL)
			match = regex.search(httpData)
			if not match: return

			m3u = match.group(1)

		elif playUrl.startswith('https://channel.gztv.com/'): # 广州官播线路
			url = playUrl
			httpData = getHttpData(url, False, 'utf-8')
			if not httpData: return

			regex = re.compile("var standardUrl='(.+?)';", re.DOTALL)
			match = regex.search(httpData)
			if not match: return

			m3u = match.group(1)

		elif playUrl.startswith('http://www.cctbn.com/'): # 中国交通官方高清
			url = playUrl
			httpData = getHttpData(url, False, 'utf-8')
			if not httpData: return

			regex = re.compile("var id = (\d+);\s*\$\.ajax\(\{\s*url: '(.+?)' \+ id,", re.DOTALL)
			match = regex.search(httpData)
			if not match: return

			url = match.group(2) + match.group(1)
			httpData = getHttpData(url, False, 'utf-8')
			if not httpData: return

			playInfo = simplejson.loads(httpData[1:-1])[0]
			m3u = playInfo['m3u8url']

		elif playUrl.startswith('http://player.hunantv.com/'): # 芒果高清
			url = 'http://mpplive.api.mgtv.com/v1/epg/turnplay/getLiveBuss?version=PCweb_1.0&platform=4'
			httpData = getHttpData(url, False, 'utf-8')
			if not httpData: return

			liveBussInfo = simplejson.loads(httpData)
			bussID = liveBussInfo['data']['buss_id']
			chanelID = dict(urlparse.parse_qsl(urlparse.urlparse(playUrl).query)).get('channel_id')
			url = 'http://mpp.liveapi.mgtv.com/v1/epg/turnplay/getLivePlayUrlMPP?version=PCweb_1.0&platform=4&buss_id=%s&channel_id=%s' % (bussID, chanelID)
			httpData = getHttpData(url, False, 'utf-8')
			if not httpData: return

			livePlayInfo = simplejson.loads(httpData)
			if livePlayInfo['msg'] != '成功': return

			m3u = livePlayInfo['data']['url']

		elif playUrl.startswith('http://116.199.5.51:8114/'): m3u = playUrl # 珠江宽频

		elif playUrl.startswith('http://player.haoqu.net/hoge.html?id='): return # GRTN直播不能播放？swf参数显示问题

		elif playUrl.startswith('http://player.haoqu.net/cutv.html?id='): return # CU线路不能播放？

		elif playUrl.startswith('http://player.haoqu.net/qk.php?u='): return # QK多线不能播放？

		elif playUrl.startswith('http://player.haoqu.net/qq.html?id='): return # QQ高清不能播放？

		elif playUrl.startswith('http://67.230.188.214/play.html?id='): return # 官播线路不能播放？

		elif playUrl.startswith('http://player.haoqu.net/play.html?id='): return # 官方线路不能播放？

		elif playUrl.startswith('http://player.haoqu.net/ckplayer.html?id='): return # 安徽官方FLV不能播放？

		elif playUrl.startswith('http://player.haoqu.net/iframe.html?id='): return # 外部地址不能播放

		elif playUrl.startswith('http://player.haoqu.net/00/migujs/migu.html?id='): return # MG线路不能播放？

		elif playUrl.startswith('http://24htv.ucoz.com/wltv/lb/play.html?id='): return # MG标清不能播放

		elif playUrl.startswith('http://player.haoqu.net/outplay2/?id='): return # 外部地址不能播放

		elif playUrl.startswith('http://player.haoqu.net/outplay/?id='): return # 外部地址不能播放

		elif playUrl.startswith('http://player.66zhibo.net/outplay/?id='): return # 官网直播不能播放

		elif playUrl.startswith('http://www.haoqu.net/out/2/'): return # 官网直播不能播放？

		elif playUrl.startswith('http://player.haoqu.net/outplay/tv/'): return # 多线高清不能播放？

		elif playUrl.startswith('http://player.haoqu.net/prov/'): return # 外部地址不能播放

		elif playUrl.startswith('http://player.haoqu.net/17/'): return # 官方线路不能播放

		elif playUrl.startswith('http://app.cjyun.org/'): return # 湖北快乐成长官方线路不能播放

		elif playUrl.startswith('http://www.sktv.com.cn/'): return # 蛇口官方播放器不能播放

		elif playUrl.startswith('http://www.thwlgbds.org.cn:8787/'): return # 通化官方播放器不能播放

		elif playUrl.startswith('http://mas.vtibet.com/'): return # 西藏官方播放器不能播放

		elif playUrl.startswith('http://www.mytaizhou.net/'): return # 泰州站外直播不能播放

		elif playUrl.startswith('http://www.csztv.com/'): return # 苏州官网直播不能播放

		elif playUrl.startswith('http://www.jdtv.sh.cn/'): return # 嘉定官方直播不能播放

		elif playUrl.startswith('http://www.aqbtv.cn:8080/'): return # 安庆官方直播不能播放

		elif playUrl.startswith('http://www.anqiutv.com:9080/'): return # 安丘官播线路不能播放

		elif playUrl.startswith('http://www.ncntv.com.cn:8787/'): return # 南充官播线路不能播放

		elif playUrl.startswith('http://app.jnnews.tv/'): return # 济宁官网直播不能播放

		elif playUrl.startswith('http://www.hznet.tv:7575/'): return # 荷泽官网直播不能播放

		elif playUrl.startswith('https://tv.huijiayou.cn/'): return # 贵州家有购物官网直播不能播放

		elif playUrl.startswith('http://www.rzw.com.cn/'): return # 日照站外直播不能播放

		elif playUrl.startswith('http://www.qthtv.com:8080/'): return # 七台河官方播放器不能播放

		elif playUrl.startswith('http://player.cncnews.cn/'): return # 新华社cnc官方线路不能播放

		elif playUrl.startswith('http://vodmall.imbc.com/'): return # 韩国mbc官方线路不能播放

		elif playUrl.startswith('https://myk.kbs.co.kr/'): return # 韩国kbs官方线路不能播放

		elif playUrl.startswith('http://www.kan-tv.com/'): return # 韩国sbs官方线路不能播放

		elif playUrl.startswith('http://123.207.42.38/'): return # IN线路不能播放

		else: return

	else: return

	return m3u

def createSelect(list, index, value):
	result = []
	if index == -1: #  一元列表
		for entry in list:
			if entry == value: result.append('[%s]' % entry)
			else: result.append(entry)
	else: #  多元列表
		for entry in list:
			if entry[index] == value: result.append('[%s]' % entry[index])
			else: result.append(entry[index])
	return result

def createUrl(urlInfo):
	url = '%s?' % addon_url
	for key, value in urlInfo.items():
		url += '%s=%s&' % (key, urllib.quote(value.encode('utf-8')))
	url = url[:-1]
	return url

def arrangeList(originalList):
	newList = []
	for entry in originalList:
		if entry not in newList:
			newList.append(entry)
	return newList

def escapeRegex(originalStr):
	regexStr = '$()*+.[]?\^{}|'
	newStr = ''
	for entry in originalStr:
		if entry in regexStr:
			newStr += '\\'
		newStr += entry
	return newStr

def setView(viewid):
	xbmcgui.Dialog().yesno(__addonname__, '强制固定视图，视图代码 [%s]' % viewid, autoclose=1)
	xbmc.executebuiltin('Container.SetViewMode(%s)' % viewid)

def showRoot():
	# 显示导航
	items = [('按地区', 'area'), ('按类型', 'type'), ('自定义', 'custom'), ('历史记录', 'history')]

	for entry in items:
		item = xbmcgui.ListItem(entry[0])
		item.setArt({'poster': defaultPic})
		item_url = createUrl({'mode': entry[1]})
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

	# 设置内容
	xbmcplugin.setContent(pHandle, 'files')
	xbmcplugin.endOfDirectory(pHandle)

def showArea():
	url = 'http://www.haoqu.net/zhibo/'
	httpData = getHttpData(url)
	if not httpData: return

	# 显示地区
	regex = re.compile('<li date-id="\d+" class="item"><a href="(/\d+/[^"]*)">(.+?)</a></li>', re.DOTALL)
	match = regex.findall(httpData)
	for entry in match:
		label = HTMLParser.HTMLParser().unescape(entry[1])
		area_url = entry[0]
		item = xbmcgui.ListItem(label)
		item.setArt({'poster': defaultPic})
		item_url = createUrl({'mode': 'channel', 'url': area_url, 'group': label})
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

	# 设置内容
	xbmcplugin.setContent(pHandle, 'files')
	xbmcplugin.setPluginCategory(pHandle, '按地区')
	xbmcplugin.endOfDirectory(pHandle)

def showType():
	url = 'http://www.haoqu.net/zhibo/'
	httpData = getHttpData(url)
	if not httpData: return

	# 显示类型
	regex = re.compile('<li date-id="c\d+"  class="item"><a href="\.\./\.\.(/zhibo/.+?/)">(.+?)</a></li>', re.DOTALL)
	match = regex.findall(httpData)
	for entry in match:
		label = HTMLParser.HTMLParser().unescape(entry[1])
		type_url = entry[0]
		item = xbmcgui.ListItem(label)
		item.setArt({'poster': defaultPic})
		item_url = createUrl({'mode': 'channel', 'url': type_url, 'group': label})
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

	# 设置内容
	xbmcplugin.setContent(pHandle, 'files')
	xbmcplugin.setPluginCategory(pHandle, '按类型')
	xbmcplugin.endOfDirectory(pHandle)

def showCustom():
	# 显示推荐频道
	addonDir = getAddonDir()
	m3uDir = os.path.join(addonDir, 'M3U')
	if os.path.exists(m3uDir):
		fileList = sorted(os.listdir(m3uDir), key=lambda x: os.path.getmtime(os.path.join(m3uDir, x)))
		m3uList = [entry.decode('utf-8') for entry in fileList if entry.endswith('.m3u')]
		for entry in m3uList:
			label = entry[:-4]
			m3u = entry
			item = xbmcgui.ListItem(label)
			item.setArt({'poster': defaultPic})
			item.addContextMenuItems([('删除自定义频道', 'RunPlugin(%s)' % createUrl({'mode': 'remove', 'dir': m3uDir, 'm3u': m3u}))])
			item_url = createUrl({'mode': 'channel', 'dir': m3uDir, 'm3u': m3u, 'group': label})
			xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

	# 显示自定义频道
	dataDir = getDataDir()
	m3uDir = os.path.join(dataDir, 'M3U')
	if os.path.exists(m3uDir):
		fileList = sorted(os.listdir(m3uDir), key=lambda x: os.path.getmtime(os.path.join(m3uDir, x)))
		m3uList = [entry.decode('utf-8') for entry in fileList if entry.endswith('.m3u')]
		for entry in m3uList:
			label = entry[:-4]
			m3u = entry
			item = xbmcgui.ListItem(label)
			item.setArt({'poster': defaultPic})
			item.addContextMenuItems([('删除自定义频道', 'RunPlugin(%s)' % createUrl({'mode': 'remove', 'dir': m3uDir, 'm3u': m3u}))])
			item_url = createUrl({'mode': 'channel', 'dir': m3uDir, 'm3u': m3u, 'group': label})
			xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

	# 添加自定义频道
	item = xbmcgui.ListItem('添加自定义频道')
	item.setArt({'poster': defaultPic})
	item_url = createUrl({'mode': 'add'})
	xbmcplugin.addDirectoryItem(pHandle, item_url, item, False)

	# 设置内容
	xbmcplugin.setContent(pHandle, 'files')
	xbmcplugin.setPluginCategory(pHandle, '自定义')
	xbmcplugin.endOfDirectory(pHandle)

def showChannel():
	pageSize = 100

	url = params.get('url')
	m3u = params.get('m3u')
	group = params.get('group')
	if url: # 显示直播频道
		change = params.get('change')
		if not change: # 首次进入
			page = 1

		elif change == 'page': # 改变页数
			curPage = int(params.get('curpage'))
			totalPage = int(params.get('totalpage'))
			pageList = []
			if curPage>1: pageList.append('上一页')
			for i in range(1, totalPage+1): pageList.append(str(i))
			if curPage<totalPage: pageList.append('下一页')
			select = xbmcgui.Dialog().select('改变页数', createSelect(pageList, -1, str(curPage)))
			if select == -1 or pageList[select] == str(curPage): return
			if pageList[select] == '上一页': page = curPage-1
			elif pageList[select] == '下一页': page = curPage+1
			else: page = int(pageList[select])

		if url.startswith('http'): pass
		else: url = 'http://www.haoqu.net' + url
		httpData = getHttpData(url)
		if not httpData: return

		# 显示视频
		regex = re.compile('<li class="p-item"> <a href="(.+?)" class="thumb-outer" title=".*?"(?: target="_blank")?> <img class=\'thumb\' src=\'(.+?)\' alt=\'(.+?)\'/> <span class="t"><strong class="s">\\3</strong></span> </a> </li>', re.DOTALL)
		match = regex.findall(httpData)

		reg = re.compile('<a href="/zhibo/([^/]+)/index_(\d+)\.html">\\2</a><a href="/zhibo/\\1/index_\d+\.html">[^\d]+</a>', re.DOTALL)
		mat = reg.search(httpData)
		if mat: # 有多页的
			lastPage = int(mat.group(2))
			for i in range(2, lastPage+1):
				tempUrl = url + 'index_%d.html' % i
				httpData = getHttpData(tempUrl)
				if not httpData: return

				reg = re.compile('<li class="p-item"> <a href="(.+?)" class="thumb-outer" title=".*?"(?: target="_blank")?> <img class=\'thumb\' src=\'(.+?)\' alt=\'(.+?)\'/> <span class="t"><strong class="s">\\3</strong></span> </a> </li>', re.DOTALL)
				mat = reg.findall(httpData)
				match.extend(mat)

		videoList = match[(page-1)*pageSize: min(page*pageSize, len(match))]
		for entry in videoList:
			video_url = 'http://www.haoqu.net' + entry[0]
			poster = entry[1]
			if not poster.startswith('http'): poster = 'http://www.haoqu.net' + poster
			label = HTMLParser.HTMLParser().unescape(entry[2])

			item = xbmcgui.ListItem(label)
			item.setArt({'poster': poster})
			item_url = createUrl({'mode': 'play', 'url': video_url, 'label': label, 'thumb': poster})
			xbmcplugin.addDirectoryItem(pHandle, item_url, item, False)

		# 显示页数
		pageStr = ''
		totalPage = int((len(match)+pageSize-1)/pageSize)
		if totalPage>1:
			item = xbmcgui.ListItem('[COLOR yellow][B]页数：[/B]第%d页[/COLOR]' % page)
			item.setArt({'poster': defaultPic})
			item_url = createUrl({'mode': 'channel', 'change': 'page', 'curpage': str(page), 'totalpage': str(totalPage), 'url': url, 'group': group})
			xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

			pageStr += ' 第%d页' % page

	if m3u: # 显示自定义频道
		change = params.get('change')
		if not change: # 首次进入
			page = 1

		elif change == 'page': # 改变页数
			curPage = int(params.get('curpage'))
			totalPage = int(params.get('totalpage'))
			pageList = []
			if curPage>1: pageList.append('上一页')
			for i in range(1, totalPage+1): pageList.append(str(i))
			if curPage<totalPage: pageList.append('下一页')
			select = xbmcgui.Dialog().select('改变页数', createSelect(pageList, -1, str(curPage)))
			if select == -1 or pageList[select] == str(curPage): return
			if pageList[select] == '上一页': page = curPage-1
			elif pageList[select] == '下一页': page = curPage+1
			else: page = int(pageList[select])

		dir = params.get('dir')
		m3uFile = os.path.join(dir, m3u).decode('utf-8')
		if not os.path.exists(m3uFile):
			xbmcgui.Dialog().ok(__addonname__, '文件错误 %s' % m3uFile)
			return

		fHandle = open(m3uFile, 'r')
		m3uData = fHandle.read()
		fHandle.close()

		import chardet
		charset = chardet.detect(m3uData)['encoding']
		if charset != 'utf-8': m3uData = m3uData.decode(charset, 'ignore').encode('utf-8')

		# 显示视频
		regex = re.compile('#EXTINF:.*?,(.*?)\r?$', re.MULTILINE)
		match = regex.findall(m3uData)
		channelList = arrangeList(match)
		videoList = channelList[(page-1)*pageSize: min(page*pageSize, len(channelList))]
		for entry in videoList:
			video_url = m3uFile
			label = entry
			poster = customPic

			item = xbmcgui.ListItem(label)
			item.setArt({'poster': poster})
			item_url = createUrl({'mode': 'play', 'url': video_url, 'label': label, 'thumb': poster})
			xbmcplugin.addDirectoryItem(pHandle, item_url, item, False)

		pageStr = ''
		# 显示页数
		totalPage = int((len(channelList)+pageSize-1)/pageSize)
		if totalPage>1:
			item = xbmcgui.ListItem('[COLOR yellow][B]页数：[/B]第%d页[/COLOR]' % page)
			item.setArt({'poster': defaultPic})
			item_url = createUrl({'mode': 'channel', 'change': 'page', 'curpage': str(page), 'totalpage': str(totalPage), 'dir': dir, 'm3u': m3u, 'group': group})
			xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

			pageStr += ' 第%d页' % page

	# 设置内容
	xbmcplugin.setContent(pHandle, 'videos')
	xbmcplugin.setPluginCategory(pHandle, group+pageStr)
	xbmcplugin.endOfDirectory(pHandle)

	# 设置视图
	forceview = __addon__.getSetting('forceview')
	if forceview == 'true': setView('500')

def showHistory():
	# 读取历史记录
	dataDir = getDataDir()
	filePath = os.path.join(dataDir, 'history.log')
	historyList = []
	if os.path.exists(filePath):
		fHandle = open(filePath, 'r')
		try:
			historyList = simplejson.load(fHandle)
		except simplejson.scanner.JSONDecodeError, e:
			xbmcgui.Dialog().ok(__addonname__, '历史记录为空或格式有误 %s' % str(e))
			pass
		fHandle.close()

	pageSize = 100
	totalPage = int((len(historyList)+pageSize-1)/pageSize)

	change = params.get('change')
	if not change: # 首次进入
		page = 1

	else: # 非首次进入
		if change == 'page': # 改变页数
			curPage = int(params.get('curpage'))
			pageList = []
			if curPage>1: pageList.append('上一页')
			for i in range(1, totalPage+1): pageList.append(str(i))
			if curPage<totalPage: pageList.append('下一页')
			select = xbmcgui.Dialog().select('改变页数', createSelect(pageList, -1, str(curPage)))
			if select == -1 or pageList[select] == str(curPage): return
			if pageList[select] == '上一页': page = curPage-1
			elif pageList[select] == '下一页': page = curPage+1
			else: page = int(pageList[select])

		elif change == 'refresh': # 刷新列表
			page = int(params.get('curpage'))

	# 显示视频
	videoList = historyList[(page-1)*pageSize: min(page*pageSize, len(historyList))]
	for i, entry in enumerate(videoList):
		url = entry.get('url')
		label = entry.get('label')
		poster = entry.get('thumb')

		if None in [url, label, poster]:
			if xbmcgui.Dialog().yesno(__addonname__, '第%s条历史记录格式有误，是否清除记录' % str(i+1)):
				os.remove(filePath)
				break
			else: continue

		item = xbmcgui.ListItem(label)
		item.setArt({'poster': poster})
		item.addContextMenuItems([('删除单条记录', 'RunPlugin(%s)' % createUrl({'mode': 'delete', 'index': str(i+(page-1)*pageSize), 'curpage': str(page-int(len(videoList)==1 and totalPage!=1))})), ('删除全部记录', 'RunPlugin(%s)' % createUrl({'mode': 'clear'}))])
		item_url = createUrl({'mode': 'play', 'url': url, 'label': label, 'thumb': poster})
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, False)

	# 显示页数
	pageStr = ''
	if totalPage>1:
		item = xbmcgui.ListItem('[COLOR yellow][B]页数：[/B]第%d页[/COLOR]' % page)
		item.setArt({'poster': defaultPic})
		item_url = createUrl({'mode': 'history', 'change': 'page', 'curpage': str(page)})
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

		pageStr += ' 第%d页' % page

	# 设置内容
	xbmcplugin.setContent(pHandle, 'videos')
	xbmcplugin.setPluginCategory(pHandle, '历史记录'+pageStr)
	xbmcplugin.endOfDirectory(pHandle)

	# 设置视图
	forceview = __addon__.getSetting('forceview')
	if forceview == 'true': setView('500')

def playVideo():
	pDialog = xbmcgui.DialogProgress()
	pDialog.create(__addonname__)

	infoLabels = {'plot': ''}
	videoUrl = params.get('url').decode('utf-8')
	videoLabel = params.get('label')
	videoThumb = params.get('thumb')
	if videoUrl.endswith('.html'): # 直播频道
		# 获取视频信号源
		pDialog.update(20, '正在获取 [%s] 信号源，请稍等' % videoLabel)
		url = videoUrl
		httpData = getHttpData(url)
		if pDialog.iscanceled(): return
		if not httpData: return

		# 详情
		regex = re.compile('</a>\s*<div class="drop-panel">(<p.+?</p>)</div>\s*</div>', re.DOTALL)
		match = regex.search(httpData)
		if match:
			reg = re.compile('<p>((?!.*<img).+?)</p>', re.DOTALL)
			mat = reg.findall(match.group(1))
			if mat: infoLabels['plot'] = HTMLParser.HTMLParser().unescape(''.join(mat).replace('\n', ''))

		# 地址
		playList = []
		regex = re.compile('<li data-player="(\d+)" class="tab-item btn btn-syc(?: btn-syc-select)?"><span class="s">(.+?)</span></li>', re.DOTALL)
		match = regex.findall(httpData)
		for i, entry in enumerate(match):
			pDialog.update(40, '(%d/%d) 正在解析信号源 [%s] ，请稍等' % (i+1, len(match), entry[1]))
			url = 'http://www.haoqu.net/e/extend/tv.php?id=' + entry[0]
			httpData = getHttpData(url, False)
			if pDialog.iscanceled(): return
			if not httpData: continue

			reg = re.compile("signal = '([^']+)';", re.DOTALL)
			mat = reg.search(httpData)
			if not mat: continue

			pDialog.update(40, '(%d/%d) 正在解析信号源 [%s] ，请稍等' % (i+1, len(match), entry[1]))
			playLabel, playUrl, playType = mat.group(1).split('$')
			m3u = getUrl(playUrl, playType)
			if pDialog.iscanceled(): return
			if not m3u: continue

			playList.append((playLabel, m3u))

		preselect = -1
		while True:
			# 选择视频信号源
			pDialog.update(60, '正在选择 [%s] 信号源，请稍等' % videoLabel)
			if len(playList) == 0:
				xbmcgui.Dialog().ok(__addonname__, '暂无信号源，请尝试从好趣网打开视频 %s' % videoUrl)
				return
			elif len(playList) == 1: select = 0
			elif len(playList) > 1:
				try:
					select = xbmcgui.Dialog().select(videoLabel, [entry[0] for entry in playList], preselect=preselect)
				except TypeError:
					select = xbmcgui.Dialog().select(videoLabel, [entry[0] for entry in playList])
				if select == -1: return

			preselect = select
			m3u = playList[select][1]
			label = '%s (%s)' % (videoLabel, playList[select][0])

			# 检测视频源
			pDialog.update(80, '正在检测信号源 [%s] ，请稍等' % label)
			if m3u.startswith('http'):
				try:
					import urllib2
					response = urllib2.urlopen(m3u, timeout=10)
				except Exception, e:
					if pDialog.iscanceled(): return
					xbmcgui.Dialog().ok(__addonname__, '网络错误 %s %s' % (m3u, str(e)))
					if len(playList) == 1: return
					else: continue
				if pDialog.iscanceled(): return
				if response.getcode() != 200:
					xbmcgui.Dialog().ok(__addonname__, '网络错误 %s [%d]' % (m3u, response.getcode()))
					if len(playList) == 1: return
					else: continue
			break

	elif videoUrl.endswith('.m3u'): # 自定义频道
		if not os.path.exists(videoUrl):
			xbmcgui.Dialog().ok(__addonname__, '文件错误 %s' % videoUrl)
			return

		pDialog.update(25, '正在获取 [%s] 信号源，请稍等' % videoLabel)
		fHandle = open(videoUrl, 'r')
		m3uData = fHandle.read()
		fHandle.close()
		if pDialog.iscanceled(): return

		import chardet
		charset = chardet.detect(m3uData)['encoding']
		if charset != 'utf-8': m3uData = m3uData.decode(charset, 'ignore').encode('utf-8')

		regex = re.compile('#EXTINF:.*?,%s\r?\n(.*?)\r?$' % escapeRegex(videoLabel), re.MULTILINE)
		match = regex.findall(m3uData)
		sourceList = arrangeList(match)

		preselect = -1
		while True:
			# 选择视频信号源
			pDialog.update(50, '正在选择 [%s] 信号源，请稍等' % videoLabel)
			if len(sourceList) == 0:
				xbmcgui.Dialog().ok(__addonname__, '文件错误 %s' % videoUrl)
				return
			elif len(sourceList) == 1: select = 0
			elif len(sourceList) > 1:
				try:
					select = xbmcgui.Dialog().select(videoLabel, ['源%d' % (i+1) for i in range(len(sourceList))], preselect=preselect)
				except TypeError:
					select = xbmcgui.Dialog().select(videoLabel, ['源%d' % (i+1) for i in range(len(sourceList))])
				if select == -1: return

			preselect = select
			m3u = sourceList[select]
			label = '%s (自定义)' % videoLabel

			# 检测视频源
			pDialog.update(75, '正在检测信号源 [%s] ，请稍等' % label)
			if m3u.startswith('http'):
				try:
					import urllib2
					response = urllib2.urlopen(m3u, timeout=10)
				except Exception, e:
					if pDialog.iscanceled(): return
					xbmcgui.Dialog().ok(__addonname__, '网络错误 %s %s' % (m3u, str(e)))
					if len(sourceList) == 1: return
					else: continue
				if pDialog.iscanceled(): return
				if response.getcode() != 200:
					xbmcgui.Dialog().ok(__addonname__, '网络错误 %s [%d]' % (m3u, response.getcode()))
					if len(sourceList) == 1: return
					else: continue
			break

	else: # 历史记录
		m3u = videoUrl
		label = videoLabel

	# 准备播放视频
	pDialog.update(100, '信号源 [%s] 检测通过，准备播放' % label)
	item = xbmcgui.ListItem(label)
	item.setArt({'poster': videoThumb})
	item.setInfo('video', infoLabels)
	if pDialog.iscanceled(): return

	#dialog(m3u, 'textviewer')
	#return

	xbmc.Player().play(m3u, item) # 播放视频
	saveHistory({'url': m3u, 'label': label, 'thumb': videoThumb}) # 保存历史

	pDialog.close()

# 主程序
addon_url = sys.argv[0]
pHandle = int(sys.argv[1])
params = dict(urlparse.parse_qsl(sys.argv[2][1:]))
mode = params.get('mode')

defaultPic = os.path.join(getAddonDir(), 'media', 'default.png')
customPic = os.path.join(getAddonDir(), 'media', 'custom.png')

# 导航
if mode == None:
	showRoot()

# 地区
elif mode == 'area':
	showArea()

# 类型
elif mode == 'type':
	showType()

# 自定义
elif mode == 'custom':
	showCustom()

# 频道
elif mode == 'channel':
	showChannel()

# 历史
elif mode == 'history':
	showHistory()

# 播放
elif mode == 'play':
	playVideo()

# 删除单条记录
elif mode == 'delete':
	deleteHistory()

# 清除历史记录
elif mode == 'clear':
	clearHistory()

# 添加自定义频道
elif mode == 'add':
	addChannel()

# 删除自定义频道
elif mode == 'remove':
	removeChannel()