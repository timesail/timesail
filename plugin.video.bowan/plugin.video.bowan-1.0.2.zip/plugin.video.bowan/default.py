﻿# -*- coding: utf-8 -*-
import xbmc, xbmcgui, xbmcplugin, xbmcaddon
import urllib, urlparse, re, sys, os, HTMLParser
import simplejson

# 编码
if sys.getdefaultencoding() != 'utf-8':
	reload(sys)
	sys.setdefaultencoding('utf-8')

# 常数
__addonname__ = '播王視頻'
__addonid__   = 'plugin.video.bowan'
__addon__     = xbmcaddon.Addon(id=__addonid__)

# 函数
def logData(data, filePath='C:\Users\Administrator\Desktop\%s.txt' % __addonname__):
	filePath = filePath.decode('utf-8')
	fHandle = open(filePath, 'w')
	fHandle.write(data)
	fHandle.close()

def dialog(str, type='ok'):
	if type == 'ok': xbmcgui.Dialog().ok(__addonname__, str)
	elif type == 'textviewer': xbmcgui.Dialog().textviewer(__addonname__, str)

def saveHistory(type, history):
	dataDir = getDataDir()
	filePath = os.path.join(dataDir, type+'.log')
	if not os.path.exists(filePath): # 文件不存在则创建文件
		fHandle = open(filePath, 'w')
		historyList = [history]

	else: # 文件存在则读取文件
		try:
			fHandle = open(filePath, 'r+')
			historyList = simplejson.load(fHandle)
			if history in historyList: historyList.remove(history)
			historyList.insert(0, history)
			fHandle.seek(0, 0)
		except simplejson.scanner.JSONDecodeError: # 文件非json格式则重新创建文件
			fHandle = open(filePath, 'w')
			historyList = [history]
			pass

	simplejson.dump(historyList, fHandle, ensure_ascii=False)
	fHandle.close()

def deleteHistory():
	index = int(params.get('index'))
	type = params.get('type')

	dataDir = getDataDir()
	filePath = os.path.join(dataDir, type+'.log')
	fHandle = open(filePath, 'r+')

	historyList = simplejson.load(fHandle)
	if xbmcgui.Dialog().yesno(__addonname__, '確定要删除歷史記錄 [%s] 嗎' % historyList[index]['label']):
		historyList.pop(index)
		fHandle.seek(0, 0)
		fHandle.truncate()
		simplejson.dump(historyList, fHandle, ensure_ascii=False)

		page = params.get('curpage')
		xbmc.executebuiltin('Container.Update(%s,replace)' % createUrl({'mode': type, 'change': 'refresh', 'curpage': page}))

	fHandle.close()

def clearHistory():
	type = params.get('type')

	dataDir = getDataDir()
	filePath = os.path.join(dataDir, type+'.log')
	if os.path.exists(filePath):
		fHandle = open(filePath, 'r')
		try:
			historyList = simplejson.load(fHandle)
			fHandle.close()
			if xbmcgui.Dialog().yesno(__addonname__, '歷史記錄共%d條，是否清除' % len(historyList)):
				os.remove(filePath)
				xbmcgui.Dialog().ok(__addonname__, '清除記錄成功，共%d條' % len(historyList))

		except simplejson.scanner.JSONDecodeError:
			fHandle.close()
			if xbmcgui.Dialog().yesno(__addonname__, '歷史記錄為空或格式有誤，是否清除'):
				os.remove(filePath)
				xbmcgui.Dialog().ok(__addonname__, '清除記錄成功')

	else: xbmcgui.Dialog().ok(__addonname__, '歷史記錄不存在')

	page = '1'
	xbmc.executebuiltin('Container.Update(%s,replace)' % createUrl({'mode': type, 'change': 'refresh', 'curpage': page}))

def getDataDir():
	dataDir = xbmc.translatePath(__addon__.getAddonInfo('profile')).decode('utf-8')
	if not os.path.exists(dataDir): os.makedirs(dataDir)
	return dataDir

def getAddonDir():
	addonDir = xbmc.translatePath(__addon__.getAddonInfo('path')).decode('utf-8')
	return addonDir

def getHttpData(url):
	headers = {'User-Agent': 'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0)', 'Referer': 'https://bowan.su'}

	try:
		import urllib3, requests
		urllib3.disable_warnings()
		response = requests.get(url, headers=headers, timeout=10, verify=False)
	except requests.exceptions.ReadTimeout:
		xbmcgui.Dialog().ok(__addonname__, '讀取超時 %s' % url)
		return
	except requests.exceptions.ConnectionError:
		xbmcgui.Dialog().ok(__addonname__, '連接錯誤 %s' % url)
		return
	if response.status_code != 200:
		xbmcgui.Dialog().ok(__addonname__, '網絡錯誤 %s [%d]' % (url, response.status_code))
		return

	httpData = response.text.encode('utf-8')
	return httpData

def createSelect(list, index, value):
	result = []
	if index == -1: #  一元列表
		for entry in list:
			if entry == value: result.append('[%s]' % entry)
			else: result.append(entry)
	else: #  多元列表
		for entry in list:
			if entry[index] == value: result.append('[%s]' % entry[index])
			else: result.append(entry[index])
	return result

def createUrl(urlInfo):
	url = '%s?' % addon_url
	for key, value in urlInfo.items():
		url += '%s=%s&' % (key, urllib.quote(value.encode('utf-8')))
	url.rstrip('&')
	return url

def arrangeList(originalList):
	newList = []
	for entry in originalList:
		if entry not in newList:
			newList.append(entry)
	return newList

def escapeRegex(originalStr):
	regexStr = '$()*+.[]?\^{}|'
	newStr = ''
	for entry in originalStr:
		if entry in regexStr:
			newStr += '\\'
		newStr += entry
	return newStr

def toCHS(sentence):
	from lib.langconv import Converter
	return Converter('zh-hans').convert(sentence.decode('utf-8')).encode('utf-8')

def toCHT(sentence):
	from lib.langconv import Converter
	return Converter('zh-hant').convert(sentence.decode('utf-8')).encode('utf-8')

def setView(viewid):
	xbmcgui.Dialog().yesno(__addonname__, '強制固定視圖，視圖代码 [%s]' % viewid, autoclose=1)
	xbmc.executebuiltin('Container.SetViewMode(%s)' % viewid)

def showRoot():
	newworld = __addon__.getSetting('newworld') # 新世界的大門

	# 显示导航
	items = [('頻道', 'channel', 'avlist'), ('排行', 'hot', 'avhot'), ('搜索', 'search', 'avsearch'), ('歷史', 'history', 'avhistory')]
	for entry in items:
		item = xbmcgui.ListItem(entry[0])
		item.setArt({'poster': defaultPic})
		if newworld == 'true':
			item.addContextMenuItems([('新世界的大門', 'ActivateWindow(videos,%s)' % createUrl({'mode': entry[2]}))])
		item_url = createUrl({'mode': entry[1]})
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

	# 设置内容
	xbmcplugin.setContent(pHandle, 'files')
	xbmcplugin.endOfDirectory(pHandle)

def showChannel():
	# 显示频道
	cateList = [('首頁', 'https://bowan.su/'),
                ('戲劇', 'https://bowan.su/list/dramas_____hits.html'),
                ('電影', 'https://bowan.su/list/movies_____hits.html'),
                ('動漫', 'https://bowan.su/list/anime_____hits.html'),
                ('綜藝', 'https://bowan.su/list/show_____hits.html')]
	for entry in cateList:
		chn_url = entry[1]
		label = HTMLParser.HTMLParser().unescape(entry[0])
		item = xbmcgui.ListItem(label)
		item.setArt({'poster': defaultPic})
		item_url = createUrl({'mode': 'list', 'url': chn_url, 'chn': label})
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

	# 设置内容
	xbmcplugin.setContent(pHandle, 'files')
	xbmcplugin.setPluginCategory(pHandle, '頻道')
	xbmcplugin.endOfDirectory(pHandle)

def showList():
	chn = params.get('chn')
	change = params.get('change')
	if not change: # 首次进入
		url = params.get('url')
		sort = '按熱門排序'
	else: # 非首次进入
		if change == 'cate': # 改变分类
			cateInfo = simplejson.loads(params.get('cateinfo'))
			cateTitle = cateInfo['name']
			cateValue = cateInfo['active']
			cateList = cateInfo['list']
			select = xbmcgui.Dialog().select(cateTitle, createSelect(cateList, 1, cateValue))
			if select == -1 or cateList[select][1] == cateValue: return

			if cateTitle == '按分類' and select == 0: # 修正"按分类"首个选项链接
				url = {'戲劇': '/dramas/', '電影': '/movies/', '動漫': '/anime/', '綜藝': '/show/'}[chn]
			else: url = cateList[select][0]

			if url.startswith('/list/'): url = 'https://bowan.su' + url
			else: url = 'https://bowan.su/list' + url[:-1] + '_____hits.html'
			sort = '按熱門排序'

		elif change == 'sort': # 改变排序
			sortInfo = simplejson.loads(params.get('sortinfo'))
			curSort = sortInfo['active']
			sortList = sortInfo['list']
			select = xbmcgui.Dialog().select('改變排序', createSelect(sortList, 1, curSort))
			if select == -1 or sortList[select][1] == curSort: return
			url = 'https://bowan.su' + sortList[select][0].replace('_vod', '')
			sort = sortList[select][1]

		elif change == 'page': # 改变页数
			pageInfo = simplejson.loads(params.get('pageinfo'))
			curPage = pageInfo['active']
			pageList = pageInfo['list']
			select = xbmcgui.Dialog().select('改變頁數', createSelect(pageList, 1, curPage))
			if select == -1 or pageList[select][0] == '': return
			url = 'https://bowan.su' + pageList[select][0]
			sort = params.get('sort')

	httpData = getHttpData(url)
	if not httpData: return

	# 显示分类
	cates = []
	regex = re.compile('<ul class="clearfix">\s*<li class="text"><span class="text-muted">([^<]+)</span></li>(.+?)</ul>', re.DOTALL)
	match = regex.findall(httpData)
	for entry in match:
		cateInfo = {}
		cateInfo['name'] = entry[0]

		reg = re.compile('<a {1,2}class="active" href="[^"]*".*?>(.+?)</a>', re.DOTALL)
		mat = reg.search(entry[1])
		cateInfo['active'] = mat.group(1)

		reg = re.compile('<a {1,3}(?:class="active" )?href="([^"]+)".*?>(.+?)</a>', re.DOTALL)
		mat = reg.findall(entry[1])
		cateInfo['list'] = mat[:]
		cates.append(cateInfo)

	for entry in cates:
		item = xbmcgui.ListItem('[COLOR yellow][B]%s：[/B]%s[/COLOR]' % (entry['name'], entry['active']))
		item.setArt({'poster': defaultPic})
		item_url = createUrl({'mode': 'list', 'change': 'cate', 'cateinfo': simplejson.dumps(entry), 'sort': sort, 'url': url, 'chn': chn})
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

	# 显示排序
	if chn != '首頁':
		sortInfo = {}
		sortInfo['active'] = sort

		regex = re.compile('<li (?:class="(?:active|gold)")?><a href="([^"]+)" data="[^"]*">(.+?)</a></li>', re.DOTALL)
		match = regex.findall(httpData)
		sortInfo['list'] = match[:]

		item = xbmcgui.ListItem('[COLOR yellow][B]排序：[/B]%s[/COLOR]' % sortInfo['active'])
		item.setArt({'poster': defaultPic})
		item_url = createUrl({'mode': 'list', 'change': 'sort', 'sortinfo': simplejson.dumps(sortInfo), 'url': url, 'chn': chn})
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

	# 显示视频
	regex = re.compile('<li class="col-md-2 col-sm-3 col-xs-4(?: (?:hidden-xs|visible-sm)?)?">\s*<a class="video-pic loading" data-original="([^"]+)" href="([^"]+)" title="([^"]+)" ?>\s*<span class="player"></span>.*?<span class="note text-bg-r">(.*?)</span>\s*</a>\s*<div class="title"><h5 class="text-overflow"><a href="\\2" title="\\3">(.+?)</a></h5></div>\s*<div class="subtitle text-muted text-overflow hidden-xs">(.*?)</div>\s*</li>', re.DOTALL)
	match = regex.findall(httpData)
	for entry in match:
		poster = entry[0]
		series_url = entry[1]
		label = HTMLParser.HTMLParser().unescape(entry[4])

		infoLabels = {}
		infoLabels['plot'] = ''
		if entry[3]: infoLabels['plot'] += '狀態：' + entry[3] + '\n'
		if entry[5]: infoLabels['plot'] += '主演：' + entry[5] + '\n'

		item = xbmcgui.ListItem(label)
		item.setArt({'poster': poster})
		item.setInfo('video', infoLabels)
		item_url = createUrl({'mode': 'play', 'url': series_url, 'title': label})
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, False)

	# 显示页数
	pageStr = ''
	regex = re.compile('<div class="box-page clearfix ajax-page" id="long-page"><ul>(.+?)</ul></div>', re.DOTALL)
	match = regex.search(httpData)
	if match:
		pageInfo = {}
		reg = re.compile('<li class="hidden-xs active"><span>(\d+)</span>', re.DOTALL)
		mat = reg.search(match.group(1))
		pageInfo['active'] = mat.group(1)

		pageInfo['list'] = []
		reg = re.compile('<li(?: class="hidden-xs(?: active)?")?><(?:a|span)(.*?)>(.+?)</(?:a|span)></li>', re.DOTALL)
		mat = reg.findall(match.group(1))
		for entry in mat:
			regi = re.compile('href="([^"]+)"', re.DOTALL)
			mati = regi.search(entry[0])
			if mati: pageInfo['list'].append((mati.group(1), entry[1]))
			else: pageInfo['list'].append(('', entry[1]))

		item = xbmcgui.ListItem('[COLOR yellow][B]頁數：[/B]第%s頁[/COLOR]' % pageInfo['active'])
		item.setArt({'poster': defaultPic})
		item_url = createUrl({'mode': 'list', 'change': 'page', 'pageinfo': simplejson.dumps(pageInfo), 'sort': sort, 'chn': chn})
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

		pageStr = ' 第%s頁' % pageInfo['active']

	# 设置内容
	xbmcplugin.setContent(pHandle, 'movies')
	xbmcplugin.setPluginCategory(pHandle, chn+pageStr)
	xbmcplugin.endOfDirectory(pHandle)

	# 设置视图
	forceview = __addon__.getSetting('forceview')
	if forceview == 'true':
		viewid = __addon__.getSetting('viewid')
		setView(viewid)

def showAVList():
	change = params.get('change')
	if not change: # 首次进入
		url = 'https://av.bowan.su/'
		nav = '網站首頁'
	else: # 非首次进入
		if change == 'nav': # 改变导航
			navInfo = simplejson.loads(params.get('navinfo'))
			curNav = navInfo['active']
			navList = navInfo['list']
			select = xbmcgui.Dialog().select('改變導航', createSelect(navList, 1, curNav))
			if select == -1 or navList[select][1] == curNav: return
			url = 'https://av.bowan.su' + navList[select][0]
			nav = navList[select][1]

		elif change == 'page': # 改变页数
			pageInfo = simplejson.loads(params.get('pageinfo'))
			curPage = pageInfo['active']
			pageList = pageInfo['list']
			select = xbmcgui.Dialog().select('改變頁數', createSelect(pageList, 1, curPage))
			if select == -1 or pageList[select][0] == '': return
			url = 'https://av.bowan.su' + pageList[select][0]
			nav = params.get('nav')

	httpData = getHttpData(url)
	if not httpData: return

	# 显示导航
	navInfo = {}
	navInfo['active'] = nav

	regex = re.compile('<li id="menu-item-\d*" class="mdui-list-item mdui-ripple" ?><a href="([^"]+)">(.+?)</a></li>', re.DOTALL)
	match = regex.findall(httpData)
	navInfo['list'] = match[:]

	item = xbmcgui.ListItem('[COLOR yellow][B]導航：[/B]%s[/COLOR]' % navInfo['active'])
	item.setArt({'poster': defaultPic})
	item_url = createUrl({'mode': 'avlist', 'change': 'nav', 'navinfo': simplejson.dumps(navInfo)})
	xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

	# 显示视频
	regex = re.compile('<div class="mdui-col">\s*<div class="mdui-grid-tile list-video-thumb"><a href="([^"]+)" ?><img src="([^"]+)"></a></div>\s*<h3 class="mdui-list-item-two-line f14 text-normal video-title"><a href="\\1" ?>(.+?)</a></h3>\s*<div class="mdui-typo-caption-opacity f12 video-details">(.+?)</div>\s*</div>', re.DOTALL)
	match = regex.findall(httpData)
	for entry in match:
		series_url = entry[0]
		poster = entry[1]
		label = HTMLParser.HTMLParser().unescape(entry[2])

		infoLabels = {}
		infoLabels['plot'] = ''
		reg = re.compile('</i>(.+?)</span>', re.DOTALL)
		mat = reg.findall(entry[3])
		if mat: infoLabels['plot'] += ','.join(mat)

		item = xbmcgui.ListItem(label)
		item.setArt({'poster': poster})
		item.setInfo('video', infoLabels)
		item_url = createUrl({'mode': 'playav', 'url': series_url, 'title': label, 'thumb': poster})
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, False)

	# 显示页数
	pageStr = ''
	regex = re.compile('<ul class="paginator-ul">(.+?)</ul>', re.DOTALL)
	match = regex.search(httpData)
	if match:
		pageInfo = {}
		reg = re.compile('<span class="pagenow">(\d+)</span>', re.DOTALL)
		mat = reg.search(httpData)
		pageInfo['active'] = mat.group(1)

		pageInfo['list'] = []
		reg = re.compile('<(?:span|a) (.+?)>(.+?)</(?:span|a)>', re.DOTALL)
		mat = reg.findall(match.group(1))
		for entry in mat:
			regi = re.compile('href="([^"]+)"', re.DOTALL)
			mati = regi.search(entry[0])
			if mati: pageInfo['list'].append((mati.group(1), entry[1]))
			else: pageInfo['list'].append(('', entry[1]))

		item = xbmcgui.ListItem('[COLOR yellow][B]頁數：[/B]第%s頁[/COLOR]' % pageInfo['active'])
		item.setArt({'poster': defaultPic})
		item_url = createUrl({'mode': 'avlist', 'change': 'page', 'pageinfo': simplejson.dumps(pageInfo), 'nav': nav})
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

		pageStr = ' 第%s頁' % pageInfo['active']

	# 设置内容 及 视图
	xbmcplugin.setContent(pHandle, 'videos')
	xbmcplugin.setPluginCategory(pHandle, '成人'+pageStr)
	xbmcplugin.endOfDirectory(pHandle)

	# 设置视图
	forceview = __addon__.getSetting('forceview')
	if forceview == 'true':
		viewid = __addon__.getSetting('viewid')
		setView(viewid)

def showHot():
	change = params.get('change')
	if not change: # 首次进入
		url = 'https://bowan.su/topmov.html'
	else: # 非首次进入
		if change == 'chn':
			chnInfo = simplejson.loads(params.get('chninfo'))
			curChn = chnInfo['active']
			chnList = chnInfo['list']
			select = xbmcgui.Dialog().select('改變榜單', createSelect(chnList, 1, curChn))
			if select == -1 or chnList[select][1] == curChn: return
			url = 'https://bowan.su' + chnList[select][0]

	httpData = getHttpData(url)
	if not httpData: return

	# 显示频道
	chnInfo = {}
	regex = re.compile('<li><a class="text-overflow active" href="[^"]*">(.+?)</a></li>', re.DOTALL)
	match = regex.search(httpData)
	chnInfo['active'] = match.group(1)

	regex = re.compile('<li><a class="text-overflow (?:active)?" href="([^"]+)">(.+?)</a></li>', re.DOTALL)
	match = regex.findall(httpData)
	chnInfo['list'] = match[:]

	item = xbmcgui.ListItem('[COLOR yellow][B]榜單：[/B]%s[/COLOR]' % chnInfo['active'])
	item.setArt({'poster': defaultPic})
	item_url = createUrl({'mode': 'hot', 'change': 'chn', 'chninfo': simplejson.dumps(chnInfo)})
	xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

	# 显示视频
	regex = re.compile('<div class="col-md-2 col-sm-4 col-xs-4 hotlist clearfix">\s*<a class="video-pic loading" data-original="([^"]+)" href="([^"]+)" title="([^"]+)" >\s*<span class="top"><em>(\d{1,3})</em></span>\s*<!--<span class="tips red">\d*</span> ?-->\s*<span class="player"></span>\s*<span class="note text-bg-r">(.+?)</span>', re.DOTALL)
	match = regex.findall(httpData)
	for entry in match:
		poster = entry[0]
		series_url = entry[1]
		label = HTMLParser.HTMLParser().unescape(entry[2])
		label2 = '[COLOR red]%02d.[/COLOR] %s' % (int(entry[3]), label)

		infoLabels = {}
		infoLabels['plot'] = ''
		infoLabels['plot'] += '狀態：' + entry[4] + '\n'

		item = xbmcgui.ListItem(label2)
		item.setArt({'poster': poster})
		item.setInfo('video', infoLabels)
		item_url = createUrl({'mode': 'play', 'url': series_url, 'title': label})
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, False)

	# 设置内容 及 视图
	xbmcplugin.setContent(pHandle, 'movies')
	xbmcplugin.setPluginCategory(pHandle, '排行')
	xbmcplugin.endOfDirectory(pHandle)

	# 设置视图
	forceview = __addon__.getSetting('forceview')
	if forceview == 'true':
		viewid = __addon__.getSetting('viewid')
		setView(viewid)

def showAVHot():
	# 设置内容
	xbmcplugin.setContent(pHandle, 'videos')
	xbmcplugin.setPluginCategory(pHandle, '排行')
	xbmcplugin.endOfDirectory(pHandle)

	# 设置视图
	forceview = __addon__.getSetting('forceview')
	if forceview == 'true':
		viewid = __addon__.getSetting('viewid')
		setView(viewid)

def showSearch():
	change = params.get('change')
	if not change: # 首次进入
		key = xbmcgui.Dialog().input('輸入關鍵字')
		if not key: return
		url = 'https://bowan.su/search/?wd=' + toCHT(key)
	else: # 非首次进入
		key = params.get('key')
		if change == 'page': # 改变页数
			pageInfo = simplejson.loads(params.get('pageinfo'))
			curPage = pageInfo['active']
			pageList = pageInfo['list']
			select = xbmcgui.Dialog().select('改變頁數', createSelect(pageList, 1, curPage))
			if select == -1 or pageList[select][0] == '': return
			url = 'https://bowan.su' + pageList[select][0]

	httpData = getHttpData(url)
	if not httpData: return

	# 显示视频
	regex = re.compile('<div class="details-info-min col-md-12 col-sm-12 col-xs-12 clearfix news-box-txt p-0">\s*<div class="col-md-3 col-sm-4 col-xs-3 news-box-txt-l clearfix"><a class="video-pic loading" href="([^"]+)" title="([^"]+)" data-original="([^"]+)" style="padding-top:150%;"><span class="note text-bg-c">\\2</span></a></div>\s*<div class="col-md-9 col-sm-8 col-xs-9 clearfix pb-0">\s*<div class="details-info p-0">\s*<ul class="info clearfix">\s*<li class="col-md-6 col-sm-6 col-xs-12"><a href="\\1" title="\\2">(.+?)</a>(.+?)</ul>\s*</div>\s*</div>\s*</div>', re.DOTALL)
	match = regex.findall(httpData)
	for entry in match:
		series_url = entry[0]
		poster = entry[2]
		label = HTMLParser.HTMLParser().unescape(entry[1])
		label2 = HTMLParser.HTMLParser().unescape(entry[3]).replace('<font color="#09BB07">', '[COLOR red]').replace('</font>', '[/COLOR]')

		infoLabels = {}
		infoLabels['plot'] = ''
		reg = re.compile('<span>狀態：</span>(.*?)</li>', re.DOTALL)
		mat = reg.search(entry[4])
		if mat: infoLabels['plot'] += '狀態：' + mat.group(1) + '\n'

		reg = re.compile('<span class="hidden-xs">類型：</span>(.*?)</li>', re.DOTALL)
		mat = reg.search(entry[4])
		if mat: infoLabels['plot'] += '類型：' + mat.group(1) + '\n'

		reg = re.compile('<span class="hidden-xs">主演：</span>(.*?)</li>', re.DOTALL)
		mat = reg.search(entry[4])
		if mat:
			regi = re.compile('<a rel="nofollow" href="[^"]*" target="_blank">(.*?)</a>', re.DOTALL)
			mati = regi.findall(mat.group(1))
			infoLabels['plot'] += '主演：' + ','.join(mati).replace('<font color="#09BB07">', '[COLOR red]').replace('</font>', '[/COLOR]') + '\n'

		reg = re.compile('<span>導演：</span>(.*?)</li>', re.DOTALL)
		mat = reg.search(entry[4])
		if mat:
			regi = re.compile('<a rel="nofollow" href="[^"]*" target="_blank">(.*?)</a>', re.DOTALL)
			mati = regi.findall(mat.group(1))
			infoLabels['plot'] += '導演：' + ','.join(mati).replace('<font color="#09BB07">', '[COLOR red]').replace('</font>', '[/COLOR]') + '\n'

		reg = re.compile('<span>國家/地區：</span>(.*?)</li>', re.DOTALL)
		mat = reg.search(entry[4])
		if mat: infoLabels['plot'] += '國家/地區：' + mat.group(1) + '\n'

		reg = re.compile('<span>語言/字幕：</span>(.*?)</li>', re.DOTALL)
		mat = reg.search(entry[4])
		if mat: infoLabels['plot'] += '語言/字幕：' + mat.group(1) + '\n'

		reg = re.compile('<span>(集數：|時長：)</span>(.*?)</li>', re.DOTALL)
		mat = reg.search(entry[4])
		if mat: infoLabels['plot'] += mat.group(1) + mat.group(2).strip() + '\n'

		reg = re.compile('<span>年代：</span>(.*?)</li>', re.DOTALL)
		mat = reg.search(entry[4])
		if mat: infoLabels['plot'] += '年代：' + mat.group(1) + '\n'

		reg = re.compile('<span>更新時間：</span>(.*?)</li>', re.DOTALL)
		mat = reg.search(entry[4])
		if mat: infoLabels['plot'] += '更新時間：' + mat.group(1) + '\n'

		reg = re.compile('<span>詳細介紹：</span><span class="details-content-default">(.*?)</span>', re.DOTALL)
		mat = reg.search(entry[4])
		if mat: infoLabels['plot'] += '詳細介紹：' + HTMLParser.HTMLParser().unescape(mat.group(1)).replace('<font color="#09BB07">', '[COLOR red]').replace('</font>', '[/COLOR]') + '\n'

		item = xbmcgui.ListItem(label2)
		item.setArt({'poster': poster})
		item.setInfo('video', infoLabels)
		item_url = createUrl({'mode': 'play', 'url': series_url, 'title': label})
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, False)

	# 显示页数
	pageStr = ''
	regex = re.compile('<div class="box-page clearfix ajax-page" id="long-page"><ul>(.+?)</ul></div>', re.DOTALL)
	match = regex.search(httpData)
	if match:
		pageInfo = {}
		reg = re.compile('<li class="hidden-xs active"><span>(\d+)</span>', re.DOTALL)
		mat = reg.search(match.group(1))
		pageInfo['active'] = mat.group(1)

		pageInfo['list'] = []
		reg = re.compile('<li(?: class="hidden-xs(?: active)?")?><(?:a|span)(.*?)>(.+?)</(?:a|span)></li>', re.DOTALL)
		mat = reg.findall(match.group(1))
		for entry in mat:
			regi = re.compile('href="([^"]+)"', re.DOTALL)
			mati = regi.search(entry[0])
			if mati: pageInfo['list'].append((mati.group(1), entry[1]))
			else: pageInfo['list'].append(('', entry[1]))

		item = xbmcgui.ListItem('[COLOR yellow][B]頁數：[/B]第%s頁[/COLOR]' % pageInfo['active'])
		item.setArt({'poster': defaultPic})
		item_url = createUrl({'mode': 'search', 'change': 'page', 'pageinfo': simplejson.dumps(pageInfo), 'key': key})
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

		pageStr = ' 第%s頁' % pageInfo['active']

	# 设置内容 及 视图
	xbmcplugin.setContent(pHandle, 'movies')
	xbmcplugin.setPluginCategory(pHandle, key+pageStr)
	xbmcplugin.endOfDirectory(pHandle)

	# 设置视图
	forceview = __addon__.getSetting('forceview')
	if forceview == 'true':
		viewid = __addon__.getSetting('viewid')
		setView(viewid)

def showAVSearch():
	change = params.get('change')
	if not change: # 首次进入
		key = xbmcgui.Dialog().input('輸入關鍵字')
		if not key: return
		url = 'https://av.bowan.su/index.php?m=vod-search-wd-' + toCHT(key)
	else: # 非首次进入
		key = params.get('key')
		if change == 'page': # 改变页数
			pageInfo = simplejson.loads(params.get('pageinfo'))
			curPage = pageInfo['active']
			pageList = pageInfo['list']
			select = xbmcgui.Dialog().select('改變頁數', createSelect(pageList, 1, curPage))
			if select == -1 or pageList[select][0] == '': return
			url = 'https://av.bowan.su' + pageList[select][0]

	httpData = getHttpData(url)
	if not httpData: return

	# 显示视频
	regex = re.compile('<div class="mdui-col">\s*<div class="mdui-grid-tile list-video-thumb"><a href="([^"]+)" ?><img src="([^"]+)"/?></a></div>\s*<h3 class="mdui-list-item-two-line f14 text-normal video-title"><a href="\\1" ?>(.+?)</a></h3>\s*<div class="mdui-typo-caption-opacity f12 video-details">(.+?)</div>\s*</div>', re.DOTALL)
	match = regex.findall(httpData)
	for entry in match:
		series_url = entry[0]
		poster = entry[1]
		label = HTMLParser.HTMLParser().unescape(entry[2])

		infoLabels = {}
		infoLabels['plot'] = ''
		reg = re.compile('</i>(.+?)</span>', re.DOTALL)
		mat = reg.findall(entry[3])
		if mat: infoLabels['plot'] += ','.join(mat)

		item = xbmcgui.ListItem(label)
		item.setArt({'poster': poster})
		item.setInfo('video', infoLabels)
		item_url = createUrl({'mode': 'playav', 'url': series_url, 'title': label, 'thumb': poster})
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, False)

	# 显示页数
	pageStr = ''
	regex = re.compile('<ul class="paginator-ul">(.+?)</ul>', re.DOTALL)
	match = regex.search(httpData)
	if match:
		pageInfo = {}
		reg = re.compile('<span class="pagenow">(\d+)</span>', re.DOTALL)
		mat = reg.search(match.group(1))
		pageInfo['active'] = mat.group(1)

		pageInfo['list'] = []
		reg = re.compile('<(?:span|a) (.+?)>(.+?)</(?:span|a)>', re.DOTALL)
		mat = reg.findall(match.group(1))
		for entry in mat:
			regi = re.compile('href="([^"]+)"', re.DOTALL)
			mati = regi.search(entry[0])
			if mati: pageInfo['list'].append((mati.group(1), entry[1]))
			else: pageInfo['list'].append(('', entry[1]))

		item = xbmcgui.ListItem('[COLOR yellow][B]頁數：[/B]第%s頁[/COLOR]' % pageInfo['active'])
		item.setArt({'poster': defaultPic})
		item_url = createUrl({'mode': 'avsearch', 'change': 'page', 'pageinfo': simplejson.dumps(pageInfo), 'key': key})
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

		pageStr = ' 第%s頁' % pageInfo['active']

	# 设置内容 及 视图
	xbmcplugin.setContent(pHandle, 'videos')
	xbmcplugin.setPluginCategory(pHandle, key+pageStr)
	xbmcplugin.endOfDirectory(pHandle)

	# 设置视图
	forceview = __addon__.getSetting('forceview')
	if forceview == 'true':
		viewid = __addon__.getSetting('viewid')
		setView(viewid)

def showHistory():
	# 读取历史记录
	dataDir = getDataDir()
	filePath = os.path.join(dataDir, 'history.log')
	historyList = []
	if os.path.exists(filePath):
		fHandle = open(filePath, 'r')
		try:
			historyList = simplejson.load(fHandle)
		except simplejson.scanner.JSONDecodeError, e:
			xbmcgui.Dialog().ok(__addonname__, '歷史記錄為空或格式有誤 %s' % str(e))
			pass
		fHandle.close()

	pageSize = 100
	totalPage = int((len(historyList)+pageSize-1)/pageSize)

	change = params.get('change')
	if not change: # 首次进入
		page = 1

	else: # 非首次进入
		if change == 'page': # 改变页数
			curPage = int(params.get('curpage'))
			pageList = []
			if curPage>1: pageList.append('上一頁')
			for i in range(1, totalPage+1): pageList.append(str(i))
			if curPage<totalPage: pageList.append('下一頁')
			select = xbmcgui.Dialog().select('改變頁數', createSelect(pageList, -1, str(curPage)))
			if select == -1 or pageList[select] == str(curPage): return
			if pageList[select] == '上一頁': page = curPage-1
			elif pageList[select] == '下一頁': page = curPage+1
			else: page = int(pageList[select])

		elif change == 'refresh': # 刷新列表
			page = int(params.get('curpage'))

	# 显示视频
	videoList = historyList[(page-1)*pageSize: min(page*pageSize, len(historyList))]
	for i, entry in enumerate(videoList):
		video_url = entry.get('url')
		label = entry.get('label')
		poster = entry.get('thumb')

		item = xbmcgui.ListItem(label)
		item.setArt({'poster': poster})
		item.addContextMenuItems([('删除單條記錄', 'RunPlugin(%s)' % createUrl({'mode': 'delete', 'index': str(i+(page-1)*pageSize), 'curpage': str(page-int(len(videoList)==1 and totalPage!=1)), 'type': 'history'})), ('删除全部記錄', 'RunPlugin(%s)' % createUrl({'mode': 'clear', 'type': 'history'}))])
		item_url = createUrl({'mode': 'play', 'url': video_url, 'label': label, 'thumb': poster})
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, False)

	# 显示页数
	pageStr = ''
	if totalPage>1:
		item = xbmcgui.ListItem('[COLOR yellow][B]頁數：[/B]第%d頁[/COLOR]' % page)
		item.setArt({'poster': defaultPic})
		item_url = createUrl({'mode': 'history', 'change': 'page', 'curpage': str(page)})
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

		pageStr = ' 第%d頁' % page

	# 设置内容 及 视图
	xbmcplugin.setContent(pHandle, 'videos')
	xbmcplugin.setPluginCategory(pHandle, '歷史記錄'+pageStr)
	xbmcplugin.endOfDirectory(pHandle)

	# 设置视图
	forceview = __addon__.getSetting('forceview')
	if forceview == 'true': setView('500')

def showAVHistory():
	# 读取历史记录
	dataDir = getDataDir()
	filePath = os.path.join(dataDir, 'avhistory.log')
	historyList = []
	if os.path.exists(filePath):
		fHandle = open(filePath, 'r')
		try:
			historyList = simplejson.load(fHandle)
		except simplejson.scanner.JSONDecodeError, e:
			xbmcgui.Dialog().ok(__addonname__, '歷史記錄為空或格式有誤 %s' % str(e))
			pass
		fHandle.close()

	pageSize = 100
	totalPage = int((len(historyList)+pageSize-1)/pageSize)

	change = params.get('change')
	if not change: # 首次进入
		page = 1

	else: # 非首次进入
		if change == 'page': # 改变页数
			curPage = int(params.get('curpage'))
			pageList = []
			if curPage>1: pageList.append('上一頁')
			for i in range(1, totalPage+1): pageList.append(str(i))
			if curPage<totalPage: pageList.append('下一頁')
			select = xbmcgui.Dialog().select('改變頁數', createSelect(pageList, -1, str(curPage)))
			if select == -1 or pageList[select] == str(curPage): return
			if pageList[select] == '上一頁': page = curPage-1
			elif pageList[select] == '下一頁': page = curPage+1
			else: page = int(pageList[select])

		elif change == 'refresh': # 刷新列表
			page = int(params.get('curpage'))

	# 显示视频
	videoList = historyList[(page-1)*pageSize: min(page*pageSize, len(historyList))]
	for i, entry in enumerate(videoList):
		video_url = entry.get('url')
		label = entry.get('label')
		poster = entry.get('thumb')

		item = xbmcgui.ListItem(label)
		item.setArt({'poster': poster})
		item.addContextMenuItems([('删除單條記錄', 'RunPlugin(%s)' % createUrl({'mode': 'delete', 'index': str(i+(page-1)*pageSize), 'curpage': str(page-int(len(videoList)==1 and totalPage!=1)), 'type': 'avhistory'})), ('删除全部記錄', 'RunPlugin(%s)' % createUrl({'mode': 'clear', 'type': 'avhistory'}))])
		item_url = createUrl({'mode': 'playav', 'url': video_url, 'label': label, 'thumb': poster})
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, False)

	# 显示页数
	pageStr = ''
	if totalPage>1:
		item = xbmcgui.ListItem('[COLOR yellow][B]頁數：[/B]第%d頁[/COLOR]' % page)
		item.setArt({'poster': defaultPic})
		item_url = createUrl({'mode': 'avhistory', 'change': 'page', 'curpage': str(page)})
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

		pageStr = ' 第%d頁' % page

	# 设置内容 及 视图
	xbmcplugin.setContent(pHandle, 'videos')
	xbmcplugin.setPluginCategory(pHandle, '歷史記錄'+pageStr)
	xbmcplugin.endOfDirectory(pHandle)

	# 设置视图
	forceview = __addon__.getSetting('forceview')
	if forceview == 'true': setView('500')

def playVideo():
	pDialog = xbmcgui.DialogProgress()
	pDialog.create(__addonname__)

	title = params.get('title')
	if title: # 非历史记录
		# 获取视频源
		pDialog.update(16, '正在獲取 [%s] 視頻源，請稍等' % title)
		url = 'https://bowan.su' + params.get('url')
		sourceData = getHttpData(url)
		if not sourceData: return
		if pDialog.iscanceled(): return

		sorttype = __addon__.getSetting('sorttype') # 集數排序方式
		buildVersion = float(xbmc.getInfoLabel('System.BuildVersion').split(' ')[0].split('-')[0]) # KODI版本号
		presource = -1
		while True:
			# 选择源
			pDialog.update(33, '正在选择 [%s] 視頻源，請稍等' % title)
			regex = re.compile('<li(?: class="(?:active )? hidden-xs")?><a class="[^"]*" href="#([^"]+)" (?:tabindex="-1" )?data-toggle="tab">(.+?)</a></li>', re.DOTALL)
			match = regex.findall(sourceData)
			sourceList = arrangeList(match)
			if len(sourceList) == 0:
				xbmcgui.Dialog().ok(__addonname__, '暫無視頻源，請稍後再試 %s' % url)
				return
			elif len(sourceList) == 1:
				select_source = 0
			else:
				if buildVersion<17: select_source = xbmcgui.Dialog().select(title, createSelect(sourceList, 1, ''))
				else: select_source = xbmcgui.Dialog().select(title, createSelect(sourceList, 1, ''), preselect=presource)
				if select_source == -1: return

			presource = select_source
			source_id = sourceList[select_source][0]
			source = sourceList[select_source][1]

			consource = False
			prevideo = -1
			while True:
				# 选择视频
				pDialog.update(50, '正在选择 [%s] 視頻源，請稍等' % title)
				regex = re.compile('<ul class="clearfix fade in active" id="%s">(.+?)</ul>' % source_id, re.DOTALL)
				match = regex.search(sourceData)

				reg = re.compile('<li><a href="([^"]+)">(.+?)(?:<span class="new"></span>)?</a></li>', re.DOTALL)
				mat = reg.findall(match.group(1))
				videoList = mat[:]
				if sorttype == '0': videoList.reverse() # 正序
				if len(videoList) == 0:
					xbmcgui.Dialog().ok(__addonname__, '暫無視頻源，請稍後再試 %s' % url)
					if len(sourceList) == 1: return
					else:
						consource = True
						break
				else:
					if buildVersion<17: select_video = xbmcgui.Dialog().select('%s (%s)' % (title, source), createSelect(videoList, 1, ''))
					else: select_video = xbmcgui.Dialog().select('%s (%s)' % (title, source), createSelect(videoList, 1, ''), preselect=prevideo)
					if select_video == -1: 
						if len(sourceList) == 1: return
						else:
							consource = True
							break

				prevideo = select_video
				url = videoList[select_video][0]
				label = '%s %s (%s)' % (title, videoList[select_video][1], source)

				# 解析视频源
				pDialog.update(66, '正在解析視頻源 [%s] ，請稍等' % label)
				url = 'https://bowan.su' + url
				httpData = getHttpData(url)
				if not httpData: continue
				if pDialog.iscanceled(): return

				regex = re.compile('<script type="application/ld\\+json">.*?"description" : "(.+?)",\s*"thumbnailURL" : "(.+?)".*?</script>', re.DOTALL)
				match = regex.search(httpData)
				if match:
					poster = match.group(2)[16:]
					infoLabels = {'plot': HTMLParser.HTMLParser().unescape(match.group(1))}
				else:
					poster = ''
					infoLabels = {'plot': ''}

				regex = re.compile('<script>var zanpiancms_player = (.+?);</script>', re.DOTALL)
				match = regex.search(httpData)
				if match:
					playInfo = simplejson.loads(match.group(1))
					m3u = playInfo['url']
				else:
					xbmcgui.Dialog().ok(__addonname__, '無法獲取播放信息 %s' % url)
					continue

				# 检测视频源
				pDialog.update(83, '正在檢測視頻源 [%s] ，請稍等' % label)
				try:
					import urllib3, requests
					urllib3.disable_warnings()
					response = requests.get(m3u, timeout=10, verify=False)
				except requests.exceptions.ReadTimeout:
					xbmcgui.Dialog().ok(__addonname__, '讀取超時 %s' % m3u)
					continue
				except requests.exceptions.ConnectionError:
					xbmcgui.Dialog().ok(__addonname__, '連接錯誤 %s' % m3u)
					continue
				if response.status_code != 200:
					xbmcgui.Dialog().ok(__addonname__, '網絡錯誤 %s [%d]' % (m3u, response.status_code))
					continue
				if pDialog.iscanceled(): return

				break

			if consource: continue # 循环
			else: break # 跳出

	else: # 历史记录
		m3u = params.get('url')
		label = params.get('label')
		poster = params.get('thumb')
		infoLabels = {'plot': ''}

	# 准备播放视频
	pDialog.update(100, '視頻源 [%s] 檢測通過，準備播放' % label)
	item = xbmcgui.ListItem(label)
	item.setArt({'poster': poster})
	item.setInfo('video', infoLabels)
	if pDialog.iscanceled(): return

	xbmc.Player().play(m3u, item) # 播放视频
	saveHistory('history', {'url': m3u, 'label': label, 'thumb': poster}) # 保存历史

	pDialog.close()

def playAV():
	pDialog = xbmcgui.DialogProgress()
	pDialog.create(__addonname__)

	title = params.get('title')
	if title: # 非历史记录
		# 获取并解析视频源
		pDialog.update(33, '正在獲取 [%s] 視頻源並解析，請稍等' % title)
		url = 'https://av.bowan.su' + params.get('url')
		httpData = getHttpData(url)
		if not httpData: return
		if pDialog.iscanceled(): return

		regex = re.compile('<span>([^<]+)</span><br>', re.DOTALL)
		match = regex.findall(httpData)
		if match: infoLabels = {'plot': '\n'.join(match)}
		else: infoLabels = {'plot': ''}
		poster = params.get('thumb')

		regex = re.compile("<script>var mac_flag='play',mac_link='[^']*', mac_name='([^']+)',mac_from='[^']*',mac_server='[^']*',mac_note='[^']*',mac_url=unescape\('([^']+)'\); </script>", re.DOTALL)
		match = regex.search(httpData)
		if match:
			label = HTMLParser.HTMLParser().unescape(match.group(1))
			m3u = urllib.unquote(match.group(2))
			if '$$$' in m3u: m3u = m3u.split('$$$')[0]
			if '$' in m3u: m3u = m3u.split('$')[1]
		else:
			xbmcgui.Dialog().ok(__addonname__, '無法獲取播放信息 %s' % url)
			return

		# 检测视频源
		pDialog.update(66, '正在檢測視頻源 [%s] ，請稍等' % label)
		try:
			import urllib3, requests
			urllib3.disable_warnings()
			response = requests.get(m3u, timeout=10, verify=False)
		except requests.exceptions.ReadTimeout:
			xbmcgui.Dialog().ok(__addonname__, '讀取超時 %s' % m3u)
			return
		except requests.exceptions.ConnectionError:
			xbmcgui.Dialog().ok(__addonname__, '連接錯誤 %s' % m3u)
			return
		if response.status_code != 200:
			xbmcgui.Dialog().ok(__addonname__, '網絡錯誤 %s [%d]' % (m3u, response.status_code))
			return
		if pDialog.iscanceled(): return

	else: # 历史记录
		m3u = params.get('url')
		label = params.get('label')
		poster = params.get('thumb')
		infoLabels = {'plot': ''}

	# 准备播放视频
	pDialog.update(100, '視頻源 [%s] 檢測通過，準備播放' % label)
	item = xbmcgui.ListItem(label)
	item.setArt({'poster': poster})
	item.setInfo('video', infoLabels)
	if pDialog.iscanceled(): return

	xbmc.Player().play(m3u, item) # 播放视频
	saveHistory('avhistory', {'url': m3u, 'label': label, 'thumb': poster}) # 保存历史

	pDialog.close()

# 主程序
addon_url = sys.argv[0]
if sys.argv[1] == 'clear': mode = 'clear'
else:
	pHandle = int(sys.argv[1])
	params = dict(urlparse.parse_qsl(sys.argv[2][1:]))
	mode = params.get('mode')

defaultPic = os.path.join(getAddonDir(), 'media', 'default.png')

# 导航
if mode == None:
	showRoot()

# 频道
elif mode == 'channel':
	showChannel()

# 列表
elif mode == 'list':
	showList()

# 新世界列表
elif mode == 'avlist':
	showAVList()

# 排行
elif mode == 'hot':
	showHot()

# 新世界排行
elif mode == 'avhot':
	showAVHot()

# 搜索
elif mode == 'search':
	showSearch()

# 新世界搜索
elif mode == 'avsearch':
	showAVSearch()

# 历史
elif mode == 'history':
	showHistory()

# 新世界历史
elif mode == 'avhistory':
	showAVHistory()

# 播放
elif mode == 'play':
	playVideo()

# 播放新世界
elif mode == 'playav':
	playAV()

# 删除单条记录
elif mode == 'delete':
	deleteHistory()

# 清除历史记录
elif mode == 'clear':
	clearHistory()