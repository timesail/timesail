﻿# -*- coding: utf-8 -*-
import xbmc, xbmcgui, xbmcplugin, xbmcaddon
import urllib2, urllib, urlparse, re, sys, os, zlib, HTMLParser
import requests, simplejson
from lib.langconv import *

# 编码
if sys.getdefaultencoding() != 'utf-8':
	reload(sys)
	sys.setdefaultencoding('utf-8')

# 常数
__addonname__ = '播王视频'
__addonid__   = 'plugin.video.bowan'
__addon__     = xbmcaddon.Addon(id=__addonid__)

# 函数
def logData(data, filePath='C:\Users\Administrator\Desktop\%s.txt' % __addonname__):
	filePath = filePath.decode('utf-8')
	fHandle = open(filePath, 'w')
	fHandle.write(data)
	fHandle.close()

def dialog(str, type='ok'):
	if type == 'ok': xbmcgui.Dialog().ok(__addonname__, str)
	elif type == 'textviewer': xbmcgui.Dialog().textviewer(__addonname__, str)

def saveHistory(type, history):
	dataDir = getDataDir()
	filePath = os.path.join(dataDir, type+'.log')
	if not os.path.exists(filePath): # 文件不存在则创建文件
		fHandle = open(filePath, 'w')
		historyList = [history]

	else: # 文件存在则读取文件
		try:
			fHandle = open(filePath, 'r+')
			historyList = simplejson.load(fHandle)
			if history in historyList: historyList.remove(history)
			historyList.insert(0, history)
			fHandle.seek(0, 0)
		except simplejson.scanner.JSONDecodeError: # 文件非json格式则重新创建文件
			fHandle = open(filePath, 'w')
			historyList = [history]
			pass

	simplejson.dump(historyList, fHandle, ensure_ascii=False)
	fHandle.close()

def deleteHistory():
	index = int(params.get('index'))
	type = params.get('type')

	dataDir = getDataDir()
	filePath = os.path.join(dataDir, type+'.log')
	fHandle = open(filePath, 'r+')

	historyList = simplejson.load(fHandle)
	if xbmcgui.Dialog().yesno(__addonname__, '确定要删除历史记录 [%s] 吗' % historyList[index]['label']):
		historyList.pop(index)
		fHandle.seek(0, 0)
		fHandle.truncate()
		simplejson.dump(historyList, fHandle, ensure_ascii=False)

		page = params.get('curpage')
		xbmc.executebuiltin('Container.Update(%s,replace)' % createUrl({'mode': type, 'change': 'refresh', 'curpage': page}))

	fHandle.close()

def clearHistory():
	type = params.get('type')

	dataDir = getDataDir()
	filePath = os.path.join(dataDir, type+'.log')
	if os.path.exists(filePath):
		fHandle = open(filePath, 'r')
		try:
			historyList = simplejson.load(fHandle)
			fHandle.close()
			if xbmcgui.Dialog().yesno(__addonname__, '历史记录共%d条，是否清除' % len(historyList)):
				os.remove(filePath)
				xbmcgui.Dialog().ok(__addonname__, '清除记录成功，共%d条' % len(historyList))

		except simplejson.scanner.JSONDecodeError:
			fHandle.close()
			if xbmcgui.Dialog().yesno(__addonname__, '历史记录为空或格式有误，是否清除'):
				os.remove(filePath)
				xbmcgui.Dialog().ok(__addonname__, '清除记录成功')

	else: xbmcgui.Dialog().ok(__addonname__, '历史记录不存在')

	page = '1'
	xbmc.executebuiltin('Container.Update(%s,replace)' % createUrl({'mode': type, 'change': 'refresh', 'curpage': page}))

def getDataDir():
	dataDir = xbmc.translatePath(__addon__.getAddonInfo('profile')).decode('utf-8')
	if not os.path.exists(dataDir): os.makedirs(dataDir)
	return dataDir

def getAddonDir():
	addonDir = xbmc.translatePath(__addon__.getAddonInfo('path')).decode('utf-8')
	return addonDir

def getHttpData(url):
	headers = {'User-Agent': 'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0)', 'Referer': 'https://bowan.su'}

	try:
		response = requests.get(url, headers=headers, verify=False)
	except requests.exceptions.ConnectionError:
		xbmcgui.Dialog().ok(__addonname__, '连接错误 %s' % url)
		return

	if response.status_code != 200:
		xbmcgui.Dialog().ok(__addonname__, '网络错误 %s (%d)' % (url, status_code))
		return

	httpData = response.text
	return toCHS(httpData)

def createSelect(list, index, value):
	result = []
	if index == -1: #  一元列表
		for entry in list:
			if entry == value: result.append('[%s]' % entry)
			else: result.append(entry)
	else: #  多元列表
		for entry in list:
			if entry[index] == value: result.append('[%s]' % entry[index])
			else: result.append(entry[index])
	return result

def createUrl(urlInfo):
	url = '%s?' % addon_url
	for key, value in urlInfo.items():
		url += '%s=%s&' % (key, urllib.quote(value.encode('utf-8')))
	url.rstrip('&')
	return url

def arrangeList(originalList):
	newList = []
	for entry in originalList:
		if entry not in newList:
			newList.append(entry)
	return newList

def escapeRegex(originalStr):
	regexStr = '$()*+.[]?\^{}|'
	newStr = ''
	for entry in originalStr:
		if entry in regexStr:
			newStr += '\\'
		newStr += entry
	return newStr

def toCHS(sentence):
	return Converter('zh-hans').convert(sentence.decode('utf-8')).encode('utf-8')

def toCHT(sentence):
	return Converter('zh-hant').convert(sentence.decode('utf-8')).encode('utf-8')

def showRoot():
	# 显示导航
	items = [('频道', 'channel', 'avchannel'), ('排行', 'hot', 'avhot'), ('搜索', 'search', 'avsearch'), ('历史', 'history', 'avhistory')]
	for entry in items:
		item = xbmcgui.ListItem(entry[0])
		item.setArt({'poster': defaultPic})
		if enableAV and entry[2]:
			item.addContextMenuItems([('新世界的大门', 'ActivateWindow(videos,%s)' % createUrl({'mode': entry[2]}))])
		item_url = createUrl({'mode': entry[1]})
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

	# 设置内容
	xbmcplugin.setContent(pHandle, 'files')
	xbmcplugin.endOfDirectory(pHandle)

def showChannel():
	# 显示频道
	cateList = [('首页', 'https://bowan.su/'),
                ('剧集', 'https://bowan.su/list/dramas_____hits.html'),
                ('电影', 'https://bowan.su/list/movies_____hits.html'),
                ('动漫', 'https://bowan.su/list/anime_____hits.html'),
                ('综艺', 'https://bowan.su/list/show_____hits.html')]
	for entry in cateList:
		chn_url = entry[1]
		label = HTMLParser.HTMLParser().unescape(entry[0])
		item = xbmcgui.ListItem(label)
		item.setArt({'poster': defaultPic})
		item_url = createUrl({'mode': 'list', 'url': chn_url, 'chn': label})
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

	# 设置内容
	xbmcplugin.setContent(pHandle, 'files')
	xbmcplugin.setPluginCategory(pHandle, '频道')
	xbmcplugin.endOfDirectory(pHandle)

def showList():
	url = params.get('url')
	chn = params.get('chn')
	change = params.get('change')
	if not change: # 首次进入
		sort = '按热门排序'
	else: # 非首次进入
		httpData = getHttpData(url)
		if not httpData: return

		if change == 'cate': # 改变分类
			cateTitle = params.get('catetitle')
			cateValue = params.get("catevalue")

			regex = re.compile('<ul class="clearfix">\s*<li class="text"><span class="text-muted">%s</span></li>(.+?)</ul>' % escapeRegex(cateTitle), re.DOTALL)
			match = regex.search(httpData)

			reg = re.compile('<a {1,3}(?:class="active" )?href="([^"]+)".*?>(.+?)</a>', re.DOTALL)
			mat = reg.findall(match.group(1))
			select = xbmcgui.Dialog().select(cateTitle, createSelect(mat, 1, cateValue))
			if select == -1 or mat[select][1] == cateValue: return

			if cateTitle == '按分类' and select == 0: # 修正"按分类"首个选项链接
				url = {'剧集': '/dramas/', '电影': '/movies/', '动漫': '/anime/', '综艺': '/show/'}[chn]
			else: url = mat[select][0]

			if url.startswith('/list/'): url = 'https://bowan.su' + url
			else: url = 'https://bowan.su/list' + url[:-1] + '_____hits.html'
			sort = '按热门排序'

		elif change == 'sort': # 改变排序
			sort = params.get('sort')
			regex = re.compile('<li (?:class="(?:active|gold)")?><a href="([^"]+)" data="[^"]*">(.+?)</a></li>', re.DOTALL)
			match = regex.findall(httpData)
			select = xbmcgui.Dialog().select('改变排序', createSelect(match, 1, sort))
			if select == -1 or match[select][1] == sort: return
			url = 'https://bowan.su' + match[select][0].replace('_vod', '')
			sort = match[select][1]

		elif change == 'page': # 改变页数
			curPage = params.get('curpage')
			regex = re.compile('<div class="box-page clearfix ajax-page" id="long-page"><ul>(.+?)</ul></div>', re.DOTALL)
			match = regex.search(httpData)

			reg = re.compile('<li(?: class="hidden-xs(?: active)?")?><(?:a|span)(.*?)>(.+?)</(?:a|span)></li>', re.DOTALL)
			mat = reg.findall(match.group(1))
			select = xbmcgui.Dialog().select('改变页数', createSelect(mat, 1, curPage))
			if select == -1: return

			regi = re.compile('href="([^"]+)"', re.DOTALL)
			mati = regi.search(mat[select][0])
			if not mati: return
			url = 'https://bowan.su' + mati.group(1)
			sort = params.get('sort')

	httpData = getHttpData(url)
	if not httpData: return

	# 显示分类
	cates = []
	regex = re.compile('<ul class="clearfix">\s*<li class="text"><span class="text-muted">([^<]+)</span></li>(.+?)</ul>', re.DOTALL)
	match = regex.findall(httpData)
	for entry in match:
		reg = re.compile('<a {1,2}class="active" href="[^"]*".*?>(.+?)</a>', re.DOTALL)
		mat = reg.search(entry[1])
		if mat: cates.append((entry[0], mat.group(1)))

	for entry in cates:
		item = xbmcgui.ListItem('[COLOR yellow][B]%s：[/B]%s[/COLOR]' % (entry[0], entry[1]))
		item.setArt({'poster': defaultPic})
		item_url = createUrl({'mode': 'list', 'change': 'cate', 'catetitle': entry[0], 'catevalue': entry[1], 'sort': sort, 'url': url, 'chn': chn})
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

	# 显示排序
	if chn != '首页':
		item = xbmcgui.ListItem('[COLOR yellow][B]排序：[/B]%s[/COLOR]' % sort)
		item.setArt({'poster': defaultPic})
		item_url = createUrl({'mode': 'list', 'change': 'sort', 'sort': sort, 'url': url, 'chn': chn})
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

	# 显示视频
	regex = re.compile('<li class="col-md-2 col-sm-3 col-xs-4(?: (?:hidden-xs|visible-sm)?)?">\s*<a class="video-pic loading" data-original="([^"]+)" href="([^"]+)" title="([^"]+)" ?>\s*<span class="player"></span>.*?<span class="note text-bg-r">(.*?)</span>\s*</a>\s*<div class="title"><h5 class="text-overflow"><a href="\\2" title="\\3">(.+?)</a></h5></div>\s*<div class="subtitle text-muted text-overflow hidden-xs">(.*?)</div>\s*</li>', re.DOTALL)
	match = regex.findall(httpData)
	for entry in match:
		poster = entry[0]
		series_url = entry[1]
		label = HTMLParser.HTMLParser().unescape(entry[4])

		infoLabels = {}
		infoLabels['plot'] = ''
		if entry[3]: infoLabels['plot'] += '状态：' + entry[3] + '\n'
		if entry[5]: infoLabels['plot'] += '主演：' + entry[5] + '\n'

		item = xbmcgui.ListItem(label)
		item.setArt({'poster': poster})
		item.setInfo('video', infoLabels)
		item_url = createUrl({'mode': 'play', 'url': series_url, 'title': label})
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, False)

	# 显示页数
	pageStr = ''
	regex = re.compile('<li class="hidden-xs active"><span>(\d+)</span>', re.DOTALL)
	match = regex.search(httpData)
	if match:
		page = match.group(1)
		item = xbmcgui.ListItem('[COLOR yellow][B]页数：[/B]第%s页[/COLOR]' % page)
		item.setArt({'poster': defaultPic})
		item_url = createUrl({'mode': 'list', 'change': 'page', 'curpage': page, 'sort': sort, 'url': url, 'chn': chn})
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

		pageStr = ' 第%s页' % page

	# 设置内容 及 视图
	xbmcplugin.setContent(pHandle, 'movies')
	xbmcplugin.setPluginCategory(pHandle, chn+pageStr)
	xbmcplugin.endOfDirectory(pHandle)
	xbmc.executebuiltin('container.SetViewMode(%d)' % viewSetting)

def showAVChannel():
	# 显示频道
	cateList = [('成人', 'https://av.bowan.su/')]
	for entry in cateList:
		chn_url = entry[1]
		label = HTMLParser.HTMLParser().unescape(entry[0])
		item = xbmcgui.ListItem(label)
		item.setArt({'poster': defaultPic})
		item_url = createUrl({'mode': 'avlist', 'url': chn_url, 'chn': label})
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

	# 设置内容
	xbmcplugin.setContent(pHandle, 'files')
	xbmcplugin.setPluginCategory(pHandle, '频道')
	xbmcplugin.endOfDirectory(pHandle)

def showAVList():
	url = params.get('url')
	chn = params.get('chn')
	change = params.get('change')
	if not change: # 首次进入
		nav = '网站首页'
	else: # 非首次进入
		httpData = getHttpData(url)
		if not httpData: return

		if change == 'nav': # 改变导航
			nav = params.get('nav')
			regex = re.compile('<li id="menu-item-\d*" class="mdui-list-item mdui-ripple" ?><a href="([^"]+)">(.+?)</a></li>', re.DOTALL)
			match = regex.findall(httpData)
			select = xbmcgui.Dialog().select('改变导航', createSelect(match, 1, nav))
			if select == -1 or match[select][1] == nav: return
			url = 'https://av.bowan.su' + match[select][0]
			nav = match[select][1]

		elif change == 'page': # 改变页数
			curPage = params.get('curpage')
			regex = re.compile('<ul class="paginator-ul">(.+?)</ul>', re.DOTALL)
			match = regex.search(httpData)

			reg = re.compile('<(?:span|a) (.+?)>(.+?)</(?:span|a)>', re.DOTALL)
			mat = reg.findall(match.group(1))
			select = xbmcgui.Dialog().select('改变页数', createSelect(mat, 1, curPage))
			if select == -1: return

			regi = re.compile('href="([^"]+)"', re.DOTALL)
			mati = regi.search(mat[select][0])
			if not mati: return
			url = 'https://av.bowan.su' + mati.group(1)
			nav = params.get('nav')

	httpData = getHttpData(url)
	if not httpData: return

	# 显示导航
	item = xbmcgui.ListItem('[COLOR yellow][B]导航：[/B]%s[/COLOR]' % nav)
	item.setArt({'poster': defaultPic})
	item_url = createUrl({'mode': 'avlist', 'change': 'nav', 'nav': nav, 'url': url, 'chn': chn})
	xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

	# 显示视频
	regex = re.compile('<div class="mdui-col">\s*<div class="mdui-grid-tile list-video-thumb"><a href="([^"]+)" ?><img src="([^"]+)"></a></div>\s*<h3 class="mdui-list-item-two-line f14 text-normal video-title"><a href="\\1" ?>(.+?)</a></h3>\s*<div class="mdui-typo-caption-opacity f12 video-details">(.+?)</div>\s*</div>', re.DOTALL)
	match = regex.findall(httpData)
	for entry in match:
		series_url = entry[0]
		poster = entry[1]
		label = HTMLParser.HTMLParser().unescape(entry[2])

		infoLabels = {}
		infoLabels['plot'] = ''
		reg = re.compile('</i>(.+?)</span>', re.DOTALL)
		mat = reg.findall(entry[3])
		if mat: infoLabels['plot'] += ','.join(mat)

		item = xbmcgui.ListItem(label)
		item.setArt({'poster': poster})
		item.setInfo('video', infoLabels)
		item_url = createUrl({'mode': 'playav', 'url': series_url, 'title': label, 'thumb': poster})
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, False)

	# 显示页数
	pageStr = ''
	regex = re.compile('<span class="pagenow">(\d+)</span>', re.DOTALL)
	match = regex.search(httpData)
	if match:
		page = match.group(1)
		item = xbmcgui.ListItem('[COLOR yellow][B]页数：[/B]第%s页[/COLOR]' % page)
		item.setArt({'poster': defaultPic})
		item_url = createUrl({'mode': 'avlist', 'change': 'page', 'curpage': page, 'nav': nav, 'url': url, 'chn': chn})
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

		pageStr = ' 第%s页' % page

	# 设置内容 及 视图
	xbmcplugin.setContent(pHandle, 'videos')
	xbmcplugin.setPluginCategory(pHandle, chn+pageStr)
	xbmcplugin.endOfDirectory(pHandle)
	xbmc.executebuiltin('container.SetViewMode(%d)' % viewSetting)

def showHot():
	change = params.get('change')
	if not change: # 首次进入
		url = 'https://bowan.su/topmov.html'
	else:
		url = params.get('url')
		httpData = getHttpData(url)
		if not httpData: return

		if change == 'chn':
			curChn = params.get('curchn')
			regex = re.compile('<li><a class="text-overflow (?:active)?" href="([^"]+)">(.+?)</a></li>', re.DOTALL)
			match = regex.findall(httpData)
			select = xbmcgui.Dialog().select('改变榜单', createSelect(match, 1, curChn))
			if select == -1 or match[select][1] == curChn: return
			url = 'https://bowan.su' + match[select][0]

	httpData = getHttpData(url)
	if not httpData: return

	# 显示频道
	regex = re.compile('<li><a class="text-overflow active" href="[^"]*">(.+?)</a></li>', re.DOTALL)
	match = regex.search(httpData)
	if match:
		chn = match.group(1)
		item = xbmcgui.ListItem('[COLOR yellow][B]榜单：[/B]%s[/COLOR]' % chn)
		item.setArt({'poster': defaultPic})
		item_url = createUrl({'mode': 'hot', 'change': 'chn', 'curchn': chn, 'url': url})
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

	# 显示视频
	regex = re.compile('<div class="col-md-2 col-sm-4 col-xs-4 hotlist clearfix">\s*<a class="video-pic loading" data-original="([^"]+)" href="([^"]+)" title="([^"]+)" >\s*<span class="top"><em>(\d{1,3})</em></span>\s*<!--<span class="tips red">\d*</span> ?-->\s*<span class="player"></span>\s*<span class="note text-bg-r">(.+?)</span>', re.DOTALL)
	match = regex.findall(httpData)
	for entry in match:
		poster = entry[0]
		series_url = entry[1]
		label = HTMLParser.HTMLParser().unescape(entry[2])
		label2 = '[COLOR red]%02d.[/COLOR] %s' % (int(entry[3]), label)

		infoLabels = {}
		infoLabels['plot'] = ''
		infoLabels['plot'] += '状态：' + entry[4] + '\n'

		item = xbmcgui.ListItem(label2)
		item.setArt({'poster': poster})
		item.setInfo('video', infoLabels)
		item_url = createUrl({'mode': 'play', 'url': series_url, 'title': label})
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, False)

	# 设置内容 及 视图
	xbmcplugin.setContent(pHandle, 'movies')
	xbmcplugin.setPluginCategory(pHandle, '排行')
	xbmcplugin.endOfDirectory(pHandle)
	xbmc.executebuiltin('container.SetViewMode(%d)' % viewSetting)

def showAVHot():
	dialog('排行功能开发中')

	# 设置内容
	xbmcplugin.setContent(pHandle, 'movies')
	xbmcplugin.setPluginCategory(pHandle, '排行')
	xbmcplugin.endOfDirectory(pHandle)
	xbmc.executebuiltin('container.SetViewMode(%d)' % viewSetting)

def showSearch():
	change = params.get('change')
	if not change: # 首次进入
		key = xbmcgui.Dialog().input('输入关键词')
		if not key: return
		url = 'https://bowan.su/search/?wd=' + toCHT(key)
	else: # 非首次进入
		key = params.get('key')
		url = params.get('url')
		httpData = getHttpData(url)
		if not httpData: return

		if change == 'page': # 改变页数
			curPage = params.get('curpage')
			regex = re.compile('<div class="box-page clearfix ajax-page" id="long-page"><ul>(.+?)</ul></div>', re.DOTALL)
			match = regex.search(httpData)

			reg = re.compile('<li(?: class="hidden-xs(?: active)?")?><(?:a|span)(.*?)>(.+?)</(?:a|span)></li>', re.DOTALL)
			mat = reg.findall(match.group(1))
			select = xbmcgui.Dialog().select('改变页数', createSelect(mat, 1, curPage))
			if select == -1: return

			regi = re.compile('href="([^"]+)"', re.DOTALL)
			mati = regi.search(mat[select][0])
			if not mati: return
			url = 'https://bowan.su' + mati.group(1)

	httpData = getHttpData(url)
	if not httpData: return

	# 显示视频
	regex = re.compile('<div class="details-info-min col-md-12 col-sm-12 col-xs-12 clearfix news-box-txt p-0">\s*<div class="col-md-3 col-sm-4 col-xs-3 news-box-txt-l clearfix"><a class="video-pic loading" href="([^"]+)" title="([^"]+)" data-original="([^"]+)" style="padding-top:150%;"><span class="note text-bg-c">\\2</span></a></div>\s*<div class="col-md-9 col-sm-8 col-xs-9 clearfix pb-0">\s*<div class="details-info p-0">\s*<ul class="info clearfix">\s*<li class="col-md-6 col-sm-6 col-xs-12"><a href="\\1" title="\\2">(.+?)</a>(.+?)</ul>\s*</div>\s*</div>\s*</div>', re.DOTALL)
	match = regex.findall(httpData)
	for entry in match:
		series_url = entry[0]
		poster = entry[2]
		label = HTMLParser.HTMLParser().unescape(entry[1])
		label2 = HTMLParser.HTMLParser().unescape(entry[3]).replace('<font color="#09BB07">', '[COLOR red]').replace('</font>', '[/COLOR]')

		infoLabels = {}
		infoLabels['plot'] = ''
		reg = re.compile('<span>状态：</span>(.*?)</li>', re.DOTALL)
		mat = reg.search(entry[4])
		if mat: infoLabels['plot'] += '状态：' + mat.group(1) + '\n'

		reg = re.compile('<span class="hidden-xs">类型：</span>(.*?)</li>', re.DOTALL)
		mat = reg.search(entry[4])
		if mat: infoLabels['plot'] += '类型：' + mat.group(1) + '\n'

		reg = re.compile('<span class="hidden-xs">主演：</span>(.*?)</li>', re.DOTALL)
		mat = reg.search(entry[4])
		if mat:
			regi = re.compile('<a rel="nofollow" href="[^"]*" target="_blank">(.*?)</a>', re.DOTALL)
			mati = regi.findall(mat.group(1))
			infoLabels['plot'] += '主演：' + ','.join(mati).replace('<font color="#09BB07">', '[COLOR red]').replace('</font>', '[/COLOR]') + '\n'

		reg = re.compile('<span>导演：</span>(.*?)</li>', re.DOTALL)
		mat = reg.search(entry[4])
		if mat:
			regi = re.compile('<a rel="nofollow" href="[^"]*" target="_blank">(.*?)</a>', re.DOTALL)
			mati = regi.findall(mat.group(1))
			infoLabels['plot'] += '导演：' + ','.join(mati).replace('<font color="#09BB07">', '[COLOR red]').replace('</font>', '[/COLOR]') + '\n'

		reg = re.compile('<span>国家/地区：</span>(.*?)</li>', re.DOTALL)
		mat = reg.search(entry[4])
		if mat: infoLabels['plot'] += '国家/地区：' + mat.group(1) + '\n'

		reg = re.compile('<span>语言/字幕：</span>(.*?)</li>', re.DOTALL)
		mat = reg.search(entry[4])
		if mat: infoLabels['plot'] += '语言/字幕：' + mat.group(1) + '\n'

		reg = re.compile('<span>(集数：|时长：)</span>(.*?)</li>', re.DOTALL)
		mat = reg.search(entry[4])
		if mat: infoLabels['plot'] += mat.group(1) + mat.group(2).strip() + '\n'

		reg = re.compile('<span>年代：</span>(.*?)</li>', re.DOTALL)
		mat = reg.search(entry[4])
		if mat: infoLabels['plot'] += '年代：' + mat.group(1) + '\n'

		reg = re.compile('<span>更新时间：</span>(.*?)</li>', re.DOTALL)
		mat = reg.search(entry[4])
		if mat: infoLabels['plot'] += '更新时间：' + mat.group(1) + '\n'

		reg = re.compile('<span>详细介绍：</span><span class="details-content-default">(.*?)</span>', re.DOTALL)
		mat = reg.search(entry[4])
		if mat: infoLabels['plot'] += '详细介绍：' + HTMLParser.HTMLParser().unescape(mat.group(1)).replace('<font color="#09BB07">', '[COLOR red]').replace('</font>', '[/COLOR]') + '\n'

		item = xbmcgui.ListItem(label2)
		item.setArt({'poster': poster})
		item.setInfo('video', infoLabels)
		item_url = createUrl({'mode': 'play', 'url': series_url, 'title': label})
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, False)

	# 显示页数
	pageStr = ''
	regex = re.compile('<li class="hidden-xs active"><span>(\d+)</span>', re.DOTALL)
	match = regex.search(httpData)
	if match:
		page = match.group(1)
		item = xbmcgui.ListItem('[COLOR yellow][B]页数：[/B]第%s页[/COLOR]' % page)
		item.setArt({'poster': defaultPic})
		item_url = createUrl({'mode': 'search', 'change': 'page', 'curpage': page, 'url': url, 'key': key})
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

		pageStr = ' 第%s页' % page

	# 设置内容 及 视图
	xbmcplugin.setContent(pHandle, 'movies')
	xbmcplugin.setPluginCategory(pHandle, key+pageStr)
	xbmcplugin.endOfDirectory(pHandle)
	xbmc.executebuiltin('container.SetViewMode(%d)' % viewSetting)

def showAVSearch():
	change = params.get('change')
	if not change: # 首次进入
		key = xbmcgui.Dialog().input('输入关键词')
		if not key: return
		url = 'https://av.bowan.su/index.php?m=vod-search-wd-' + toCHT(key)
	else: # 非首次进入
		key = params.get('key')
		url = params.get('url')
		httpData = getHttpData(url)
		if not httpData: return

		if change == 'page': # 改变页数
			curPage = params.get('curpage')
			regex = re.compile('<ul class="paginator-ul">(.+?)</ul>', re.DOTALL)
			match = regex.search(httpData)

			reg = re.compile('<(?:span|a) (.+?)>(.+?)</(?:span|a)>', re.DOTALL)
			mat = reg.findall(match.group(1))
			select = xbmcgui.Dialog().select('改变页数', createSelect(mat, 1, curPage))
			if select == -1: return

			regi = re.compile('href="([^"]+)"', re.DOTALL)
			mati = regi.search(mat[select][0])
			if not mati: return
			url = 'https://av.bowan.su' + mati.group(1)

	httpData = getHttpData(url)
	if not httpData: return

	# 显示视频
	regex = re.compile('<div class="mdui-col">\s*<div class="mdui-grid-tile list-video-thumb"><a href="([^"]+)" ?><img src="([^"]+)"/?></a></div>\s*<h3 class="mdui-list-item-two-line f14 text-normal video-title"><a href="\\1" ?>(.+?)</a></h3>\s*<div class="mdui-typo-caption-opacity f12 video-details">(.+?)</div>\s*</div>', re.DOTALL)
	match = regex.findall(httpData)
	for entry in match:
		series_url = entry[0]
		poster = entry[1]
		label = HTMLParser.HTMLParser().unescape(entry[2])

		infoLabels = {}
		infoLabels['plot'] = ''
		reg = re.compile('</i>(.+?)</span>', re.DOTALL)
		mat = reg.findall(entry[3])
		if mat: infoLabels['plot'] += ','.join(mat)

		item = xbmcgui.ListItem(label)
		item.setArt({'poster': poster})
		item.setInfo('video', infoLabels)
		item_url = createUrl({'mode': 'playav', 'url': series_url, 'title': label, 'thumb': poster})
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, False)

	# 显示页数
	pageStr = ''
	regex = re.compile('<span class="pagenow">(\d+)</span>', re.DOTALL)
	match = regex.search(httpData)
	if match:
		page = match.group(1)
		item = xbmcgui.ListItem('[COLOR yellow][B]页数：[/B]第%s页[/COLOR]' % page)
		item.setArt({'poster': defaultPic})
		item_url = createUrl({'mode': 'avsearch', 'change': 'page', 'curpage': page, 'url': url, 'key': key})
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

		pageStr = ' 第%s页' % page

	# 设置内容 及 视图
	xbmcplugin.setContent(pHandle, 'videos')
	xbmcplugin.setPluginCategory(pHandle, key+pageStr)
	xbmcplugin.endOfDirectory(pHandle)
	xbmc.executebuiltin('container.SetViewMode(%d)' % viewSetting)

def showHistory():
	# 读取历史记录
	dataDir = getDataDir()
	filePath = os.path.join(dataDir, 'history.log')
	historyList = []
	if os.path.exists(filePath):
		fHandle = open(filePath, 'r')
		try:
			historyList = simplejson.load(fHandle)
		except simplejson.scanner.JSONDecodeError, e:
			xbmcgui.Dialog().ok(__addonname__, '历史记录为空或格式有误 %s' % str(e))
			pass
		fHandle.close()

	pageSize = 100
	totalPage = int((len(historyList)+pageSize-1)/pageSize)

	change = params.get('change')
	if change == None:  # 首次进入
		page = 1

	elif change == 'page': # 改变页数
		curPage = int(params.get('curpage'))
		pageList = []
		if curPage>1: pageList.append('上一页')
		for i in range(1, totalPage+1): pageList.append(str(i))
		if curPage<totalPage: pageList.append('下一页')
		select = xbmcgui.Dialog().select('改变页数', createSelect(pageList, -1, str(curPage)))
		if select == -1 or pageList[select] == str(curPage): return
		if pageList[select] == '上一页': page = curPage-1
		elif pageList[select] == '下一页': page = curPage+1
		else: page = int(pageList[select])

	elif change == 'refresh': # 刷新列表
		page = int(params.get('curpage'))

	# 显示视频
	videoList = historyList[(page-1)*pageSize: min(page*pageSize, len(historyList))]
	for i, entry in enumerate(videoList):
		video_url = entry.get('url')
		label = entry.get('label')
		poster = entry.get('thumb')

		item = xbmcgui.ListItem(label)
		item.setArt({'poster': poster})
		item.addContextMenuItems([('删除单条记录', 'RunPlugin(%s)' % createUrl({'mode': 'delete', 'index': str(i+(page-1)*pageSize), 'curpage': str(page-int(len(videoList)==1 and totalPage!=1)), 'type': 'history'})), ('删除全部记录', 'RunPlugin(%s)' % createUrl({'mode': 'clear', 'type': 'history'}))])
		item_url = createUrl({'mode': 'play', 'url': video_url, 'label': label, 'thumb': poster})
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, False)

	# 显示页数
	pageStr = ''
	if totalPage>1:
		item = xbmcgui.ListItem('[COLOR yellow][B]页数：[/B]第%d页[/COLOR]' % page)
		item.setArt({'poster': defaultPic})
		item_url = createUrl({'mode': 'history', 'change': 'page', 'curpage': str(page)})
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

		pageStr = ' 第%d页' % page

	# 设置内容 及 视图
	xbmcplugin.setContent(pHandle, 'videos')
	xbmcplugin.setPluginCategory(pHandle, '历史记录'+pageStr)
	xbmcplugin.endOfDirectory(pHandle)
	xbmc.executebuiltin('container.SetViewMode(500)')

def showAVHistory():
	# 读取历史记录
	dataDir = getDataDir()
	filePath = os.path.join(dataDir, 'avhistory.log')
	historyList = []
	if os.path.exists(filePath):
		fHandle = open(filePath, 'r')
		try:
			historyList = simplejson.load(fHandle)
		except simplejson.scanner.JSONDecodeError, e:
			xbmcgui.Dialog().ok(__addonname__, '历史记录为空或格式有误 %s' % str(e))
			pass
		fHandle.close()

	pageSize = 100
	totalPage = int((len(historyList)+pageSize-1)/pageSize)

	change = params.get('change')
	if change == None:  # 首次进入
		page = 1

	elif change == 'page': # 改变页数
		curPage = int(params.get('curpage'))
		pageList = []
		if curPage>1: pageList.append('上一页')
		for i in range(1, totalPage+1): pageList.append(str(i))
		if curPage<totalPage: pageList.append('下一页')
		select = xbmcgui.Dialog().select('改变页数', createSelect(pageList, -1, str(curPage)))
		if select == -1 or pageList[select] == str(curPage): return
		if pageList[select] == '上一页': page = curPage-1
		elif pageList[select] == '下一页': page = curPage+1
		else: page = int(pageList[select])

	elif change == 'refresh': # 刷新列表
		page = int(params.get('curpage'))

	# 显示视频
	videoList = historyList[(page-1)*pageSize: min(page*pageSize, len(historyList))]
	for i, entry in enumerate(videoList):
		video_url = entry.get('url')
		label = entry.get('label')
		poster = entry.get('thumb')

		item = xbmcgui.ListItem(label)
		item.setArt({'poster': poster})
		item.addContextMenuItems([('删除单条记录', 'RunPlugin(%s)' % createUrl({'mode': 'delete', 'index': str(i+(page-1)*pageSize), 'curpage': str(page-int(len(videoList)==1 and totalPage!=1)), 'type': 'avhistory'})), ('删除全部记录', 'RunPlugin(%s)' % createUrl({'mode': 'clear', 'type': 'avhistory'}))])
		item_url = createUrl({'mode': 'play', 'url': video_url, 'label': label, 'thumb': poster})
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, False)

	# 显示页数
	pageStr = ''
	if totalPage>1:
		item = xbmcgui.ListItem('[COLOR yellow][B]页数：[/B]第%d页[/COLOR]' % page)
		item.setArt({'poster': defaultPic})
		item_url = createUrl({'mode': 'avhistory', 'change': 'page', 'curpage': str(page)})
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

		pageStr = ' 第%d页' % page

	# 设置内容 及 视图
	xbmcplugin.setContent(pHandle, 'videos')
	xbmcplugin.setPluginCategory(pHandle, '历史记录'+pageStr)
	xbmcplugin.endOfDirectory(pHandle)
	xbmc.executebuiltin('container.SetViewMode(500)')

def playVideo():
	title = params.get('title')
	if title: # 非历史记录
		pDialog = xbmcgui.DialogProgress()
		pDialog.create(__addonname__)

		pDialog.update(25, '正在获取 [%s] 视频源，请稍等' % title)
		url = 'https://bowan.su' + params.get('url')
		httpData = getHttpData(url)
		if not httpData: return
		if pDialog.iscanceled(): return

		buildVersion = float(xbmc.getInfoLabel('System.BuildVersion').split(' ')[0].split('-')[0])
		select = 0
		while True:
			# 选择源
			regex = re.compile('<li(?: class="(?:active )? hidden-xs")?><a class="[^"]*" href="#([^"]+)" (?:tabindex="-1" )?data-toggle="tab">(.+?)</a></li>', re.DOTALL)
			match = regex.findall(httpData)
			sourceList = arrangeList(match)
			if len(sourceList) == 0:
				xbmcgui.Dialog().ok(__addonname__, '暂无视频源，请稍后再试 %s' % url)
				return
			elif len(sourceList) == 1:
				select_source = 0
			else:
				if buildVersion<17: select_source = xbmcgui.Dialog().select(title, createSelect(sourceList, 1, ''))
				else: select_source = xbmcgui.Dialog().select(title, createSelect(sourceList, 1, ''), preselect=select)
				if select_source == -1: return

			source_id = sourceList[select_source][0]
			source = sourceList[select_source][1]

			# 选择视频
			regex = re.compile('<ul class="clearfix fade in active" id="%s">(.+?)</ul>' % source_id, re.DOTALL)
			match = regex.search(httpData)

			reg = re.compile('<li><a href="([^"]+)">(.+?)(?:<span class="new"></span>)?</a></li>', re.DOTALL)
			mat = reg.findall(match.group(1))
			videoList = mat[:]
			if not sortRev: videoList.reverse()
			if len(videoList) == 0:
				xbmcgui.Dialog().ok(__addonname__, '暂无视频源，请稍后再试 %s' % url)
				if len(sourceList) == 1: return
				else:
					select = select_source
					continue
			else:
				select_video = xbmcgui.Dialog().select('%s (%s)' % (title, source), createSelect(videoList, 1, ''))
				if select_video == -1: 
					if len(sourceList) == 1: return
					else:
						select = select_source
						continue

			url = videoList[select_video][0]
			label = '%s %s (%s)' % (title, videoList[select_video][1], source)
			break

		# 获取视频信息
		pDialog.update(50, '正在解析视频源 [%s] ，请稍等' % label)
		url = 'https://bowan.su' + url
		httpData = getHttpData(url)
		if not httpData: return
		if pDialog.iscanceled(): return

		regex = re.compile('<script type="application/ld\\+json">.*?"description" : "(.+?)",\s*"thumbnailURL" : "(.+?)".*?</script>', re.DOTALL)
		match = regex.search(httpData)
		if match:
			poster = match.group(2)[16:]
			infoLabels = {'plot': HTMLParser.HTMLParser().unescape(match.group(1))}
		else:
			poster = ''
			infoLabels = {'plot': ''}

		regex = re.compile('<script>var zanpiancms_player = (.+?);</script>', re.DOTALL)
		match = regex.search(httpData)
		if match:
			playInfo = simplejson.loads(match.group(1))
			m3u = playInfo['url']
		else:
			xbmcgui.Dialog().ok(__addonname__, '无法获取播放信息 %s' % url)
			return

		pDialog.update(75, '正在检测视频源 [%s] ，请稍等' % label)
		try:
			response = requests.get(m3u, verify=False)
		except requests.exceptions.ConnectionError:
			xbmcgui.Dialog().ok(__addonname__, '服务器已关闭或地址错误 %s' % m3u)
			return

		if response.status_code != 200:
			xbmcgui.Dialog().ok(__addonname__, '服务器已关闭或地址错误 %s (%d)' % (m3u, status_code))
			return
		if pDialog.iscanceled(): return

		pDialog.update(100, '视频源 [%s] 检测通过，准备播放' % label)
		item = xbmcgui.ListItem(label)
		item.setArt({'poster': poster})
		item.setInfo('video', infoLabels)
		if pDialog.iscanceled(): return

		xbmc.Player().play(m3u, item) # 播放视频
		saveHistory('history', {'url': m3u, 'label': label, 'thumb': poster}) # 保存历史
		pDialog.close()

	else: # 历史记录
		m3u = params.get('url')
		label = params.get('label')
		poster = params.get('thumb')

		item = xbmcgui.ListItem(label)
		item.setArt({'poster': poster})
		xbmc.Player().play(m3u, item) # 播放视频
		saveHistory('history', {'url': m3u, 'label': label, 'thumb': poster}) # 保存历史

def playAV():
	title = params.get('title')
	if title: # 非历史记录
		pDialog = xbmcgui.DialogProgress()
		pDialog.create(__addonname__)

		pDialog.update(33, '正在获取 [%s] 视频源，请稍等' % title)
		url = 'https://av.bowan.su' + params.get('url')
		httpData = getHttpData(url)
		if not httpData: return
		if pDialog.iscanceled(): return

		regex = re.compile('<span>([^<]+)</span><br>', re.DOTALL)
		match = regex.findall(httpData)
		if match: infoLabels = {'plot': '\n'.join(match)}
		else: infoLabels = {'plot': ''}
		poster = params.get('thumb')

		regex = re.compile("<script>var mac_flag='play',mac_link='[^']*', mac_name='([^']+)',mac_from='[^']*',mac_server='[^']*',mac_note='[^']*',mac_url=unescape\('([^']+)'\); </script>", re.DOTALL)
		match = regex.search(httpData)
		if match:
			label = HTMLParser.HTMLParser().unescape(match.group(1))
			m3u = urllib.unquote(match.group(2))
			if '$$$' in m3u: m3u = m3u.split('$$$')[0].split('$')[1]
		else:
			xbmcgui.Dialog().ok(__addonname__, '无法获取播放信息 %s' % url)
			return

		pDialog.update(66, '正在检测视频源 [%s] ，请稍等' % label)
		try:
			response = requests.get(m3u, verify=False)
		except requests.exceptions.ConnectionError:
			xbmcgui.Dialog().ok(__addonname__, '服务器已关闭或地址错误 %s' % m3u)
			return

		if response.status_code != 200:
			xbmcgui.Dialog().ok(__addonname__, '服务器已关闭或地址错误 %s (%d)' % (m3u, status_code))
			return
		if pDialog.iscanceled(): return

		pDialog.update(100, '视频源 [%s] 检测通过，准备播放' % label)
		item = xbmcgui.ListItem(label)
		item.setArt({'poster': poster})
		item.setInfo('video', infoLabels)
		if pDialog.iscanceled(): return

		xbmc.Player().play(m3u, item) # 播放视频
		saveHistory('avhistory', {'url': m3u, 'label': label, 'thumb': poster}) # 保存历史
		pDialog.close()

	else: # 历史记录
		m3u = params.get('url')
		label = params.get('label')
		poster = params.get('thumb')

		item = xbmcgui.ListItem(label)
		item.setArt({'poster': poster})
		xbmc.Player().play(m3u, item) # 播放视频
		saveHistory('avhistory', {'url': m3u, 'label': label, 'thumb': poster}) # 保存历史

# 主程序
addon_url = sys.argv[0]
if sys.argv[1] == 'clear': mode = 'clear'
else:
	pHandle = int(sys.argv[1])
	params = dict(urlparse.parse_qsl(sys.argv[2][1:]))
	mode = params.get('mode')

defaultPic = os.path.join(getAddonDir(), 'media', 'default.png')

viewtype = __addon__.getSetting('viewtype')
if viewtype == '0': viewSetting = 54 # 信息墙
elif viewtype == '1': viewSetting = 500 # 海报墙
elif viewtype == '2': viewSetting = 55 # 宽列表

sorttype = __addon__.getSetting('sorttype')
if sorttype == '0': sortRev = False # 正序
elif sorttype == '1': sortRev = True # 倒序

newworld = __addon__.getSetting('newworld')
if newworld == 'false': enableAV = False # 关闭
elif newworld == 'true': enableAV = True # 打开

# 导航
if mode == None:
	showRoot()

# 频道
elif mode == 'channel':
	showChannel()

# 列表
elif mode == 'list':
	showList()

# 新世界频道
elif mode == 'avchannel':
	showAVChannel()

# 新世界列表
elif mode == 'avlist':
	showAVList()

# 排行
elif mode == 'hot':
	showHot()

# 新世界排行
elif mode == 'avhot':
	showAVHot()

# 搜索
elif mode == 'search':
	showSearch()

# 新世界搜索
elif mode == 'avsearch':
	showAVSearch()

# 历史
elif mode == 'history':
	showHistory()

# 新世界历史
elif mode == 'avhistory':
	showAVHistory()

# 播放
elif mode == 'play':
	playVideo()

# 播放新世界
elif mode == 'playav':
	playAV()

# 删除单条记录
elif mode == 'delete':
	deleteHistory()

# 清除历史记录
elif mode == 'clear':
	clearHistory()