﻿# -*- coding: utf-8 -*-
import xbmc, xbmcgui, xbmcplugin, xbmcaddon
import urllib, urlparse, re, sys, os, HTMLParser
import simplejson

# 编码
if sys.getdefaultencoding() != 'utf-8':
	reload(sys)
	sys.setdefaultencoding('utf-8')

# 常数
__addonname__ = '美剧天堂'
__addonid__   = 'plugin.video.meijutt'
__addon__     = xbmcaddon.Addon(id=__addonid__)

# 函数
def logData(data, filePath='C:\Users\Administrator\Desktop\%s.txt' % __addonname__):
	filePath = filePath.decode('utf-8')
	fHandle = open(filePath, 'w')
	fHandle.write(data)
	fHandle.close()

def dialog(str, type='ok'):
	if type == 'ok': xbmcgui.Dialog().ok(__addonname__, str)
	elif type == 'textviewer': xbmcgui.Dialog().textviewer(__addonname__, str)

def saveHistory(history):
	dataDir = getDataDir()
	filePath = os.path.join(dataDir, 'history.log')
	if not os.path.exists(filePath): # 文件不存在则创建文件
		fHandle = open(filePath, 'w')
		historyList = [history]

	else: # 文件存在则读取文件
		try:
			fHandle = open(filePath, 'r+')
			historyList = simplejson.load(fHandle)
			if history in historyList: historyList.remove(history)
			historyList.insert(0, history)
			fHandle.seek(0, 0)
		except simplejson.scanner.JSONDecodeError: # 文件非json格式则重新创建文件
			fHandle = open(filePath, 'w')
			historyList = [history]
			pass

	simplejson.dump(historyList, fHandle, ensure_ascii=False)
	fHandle.close()

def deleteHistory():
	dataDir = getDataDir()
	filePath = os.path.join(dataDir, 'history.log')
	if os.path.exists(filePath):
		fHandle = open(filePath, 'r+')
		try:
			historyList = simplejson.load(fHandle)
			index = int(params.get('index'))
			if xbmcgui.Dialog().yesno(__addonname__, '确定要删除历史记录 [%s] 吗' % historyList[index]['label']):
				historyList.pop(index)
				fHandle.seek(0, 0)
				fHandle.truncate()
				simplejson.dump(historyList, fHandle, ensure_ascii=False)

				page = params.get('curpage')
				xbmc.executebuiltin('Container.Update(%s,replace)' % createUrl({'mode': 'history', 'change': 'refresh', 'curpage': page}))

		except simplejson.scanner.JSONDecodeError:
			if xbmcgui.Dialog().yesno(__addonname__, '历史记录为空或格式有误，是否清除'):
				os.remove(filePath)
				xbmc.executebuiltin('Container.Update(%s,replace)' % createUrl({'mode': 'history'}))

	else: xbmcgui.Dialog().ok(__addonname__, '历史记录不存在')
	fHandle.close()

def clearHistory():
	dataDir = getDataDir()
	filePath = os.path.join(dataDir, 'history.log')
	if os.path.exists(filePath):
		fHandle = open(filePath, 'r')
		try:
			historyList = simplejson.load(fHandle)
			fHandle.close()
			if xbmcgui.Dialog().yesno(__addonname__, '历史记录共%d条，是否清除' % len(historyList)):
				os.remove(filePath)
				xbmc.executebuiltin('Container.Update(%s,replace)' % createUrl({'mode': 'history'}))

		except simplejson.scanner.JSONDecodeError:
			fHandle.close()
			if xbmcgui.Dialog().yesno(__addonname__, '历史记录为空或格式有误，是否清除'):
				os.remove(filePath)
				xbmc.executebuiltin('Container.Update(%s,replace)' % createUrl({'mode': 'history'}))

	else: xbmcgui.Dialog().ok(__addonname__, '历史记录不存在')

def getDataDir():
	dataDir = xbmc.translatePath(__addon__.getAddonInfo('profile')).decode('utf-8')
	if not os.path.exists(dataDir): os.makedirs(dataDir)
	return dataDir

def getAddonDir():
	addonDir = xbmc.translatePath(__addon__.getAddonInfo('path')).decode('utf-8')
	return addonDir

def getHttpData(url):
	import urllib2
	request = urllib2.Request(url)
	request.add_header('User-Agent', 'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0)')

	maxtimes = 10
	for t in range(maxtimes):
		try:
			response = urllib2.urlopen(request)
			httpData = response.read()
			break
		except Exception, e:
			if '11004' in str(e):
				if t<maxtimes-1: continue
				else: xbmcgui.Dialog().ok(__addonname__, '网络错误 %s %s %d次' % (url, str(e), maxtimes))
			else: xbmcgui.Dialog().ok(__addonname__, '网络错误 %s %s' % (url, str(e)))
			return

	if response.headers.get('content-encoding', None) == 'gzip':
		import zlib
		httpData = zlib.decompress(httpData, zlib.MAX_WBITS|32)

	response.close()
	return httpData.decode('gb2312', 'ignore')

def postHttpData(url, data):
	import urllib2
	request = urllib2.Request(url, urllib.urlencode(data))
	request.add_header('User-Agent', 'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0)')

	maxtimes = 10
	for t in range(maxtimes):
		try:
			response = urllib2.urlopen(request)
			httpData = response.read()
			break
		except Exception, e:
			if '11004' in str(e):
				if t<maxtimes-1: continue
				else: xbmcgui.Dialog().ok(__addonname__, '网络错误 %s %s %d次' % (url, str(e), maxtimes))
			else: xbmcgui.Dialog().ok(__addonname__, '网络错误 %s %s' % (url, str(e)))
			return

	if response.headers.get('content-encoding', None) == 'gzip':
		import zlib
		httpData = zlib.decompress(httpData, zlib.MAX_WBITS|32)

	response.close()
	return httpData.decode('gb2312', 'ignore')

def createSelect(list, index, value=None):
	result = []
	if index == -1: #  一元列表
		for entry in list:
			if entry == value: result.append('[%s]' % entry)
			else: result.append(entry)
	else: #  多元列表
		for entry in list:
			if entry[index] == value: result.append('[%s]' % entry[index])
			else: result.append(entry[index])
	return result

def createUrl(urlInfo):
	url = '%s?' % addon_url
	for key, value in urlInfo.items():
		url += '%s=%s&' % (key, urllib.quote(value.encode('utf-8')))
	url = url[:-1]
	return url

def setView(viewid):
	xbmcgui.Dialog().yesno(__addonname__, '强制固定视图，视图代码 [%s]' % viewid, autoclose=1)
	xbmc.executebuiltin('Container.SetViewMode(%s)' % viewid)

def showRoot():
	# 显示导航
	items = [('剧集频道', 'list'), ('热播排行', 'rank'), ('最近更新', 'new'), ('美剧搜索', 'search'), ('历史记录', 'history')]
	for entry in items:
		item = xbmcgui.ListItem(entry[0])
		item.setArt({'poster': defaultPic})
		item_url = createUrl({'mode': entry[1]})
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

	# 设置内容
	xbmcplugin.setContent(pHandle, 'files')
	xbmcplugin.endOfDirectory(pHandle)

def showList():
	change = params.get('change')
	if not change: # 首次进入
		url = 'https://www.meijutt.tv/1_______.html'
	else: # 非首次进入
		if change == 'cate': # 改变分类
			cateInfo = simplejson.loads(params.get('cateinfo'))
			cateTitle = cateInfo['name']
			cateValue = cateInfo['active']
			cateList = cateInfo['list']
			select = xbmcgui.Dialog().select(cateTitle, createSelect(cateList, 1, cateValue))
			if select == -1 or cateList[select][1] == cateValue: return
			url = 'https://www.meijutt.tv' + cateList[select][0]

		elif change == 'page': # 改变页数
			pageInfo = simplejson.loads(params.get('pageinfo'))
			curPage = pageInfo['active']
			pageList = pageInfo['list']
			select = xbmcgui.Dialog().select('改变页数', createSelect(pageList, 1, curPage))
			if select == -1 or pageList[select][1] == curPage: return
			url = 'https://www.meijutt.tv' + pageList[select][0]

	httpData = getHttpData(url)
	if not httpData: return

	# 显示分类
	cates = []
	regex = re.compile('<li id="[^"]*"(?: class="no-b")?><strong>(.+?)</strong><div>(.+?)</div></li>', re.DOTALL)
	match = regex.findall(httpData)
	for entry in match:
		cateInfo = {}
		cateInfo['name'] = entry[0]

		reg = re.compile('<a href="[^"]*" class="current" target="_self">(.+?)</a>', re.DOTALL)
		mat = reg.search(entry[1])
		cateInfo['active'] = mat.group(1)

		reg = re.compile('<a href="([^"]+)"(?: class="current")? target="_self">(.+?)</a>', re.DOTALL)
		mat = reg.findall(entry[1])
		cateInfo['list'] = mat[:]

		cates.append(cateInfo)

	for entry in cates:
		item = xbmcgui.ListItem('[COLOR yellow][B]%s：[/B]%s[/COLOR]' % (entry['name'], entry['active']))
		item.setArt({'poster': defaultPic})
		item_url = createUrl({'mode': 'list', 'change': 'cate', 'cateinfo': simplejson.dumps(entry)})
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

	# 显示视频
	regex = re.compile('<div class="cn_box2"><div class="cn_box_box3"><div class="bor_img3_right"><a href="([^"]+)" title="([^"]+)" target="_blank"><img class="list_pic" src="([^"]+)"  border="0" alt="\\2"/></a><em><strong class="average-big">(\d+)</strong><span class="average-small">(\.\d+)</span></em></div></div><ul class="list_20">(.+?)</ul></div>', re.DOTALL)
	match = regex.findall(httpData)
	for entry in match:
		content_url = 'https://www.meijutt.tv' + entry[0]
		label = HTMLParser.HTMLParser().unescape(entry[1])
		poster = entry[2]

		infoLabels = {'plot': '评分：' + entry[3] + entry[4] + '\n'}
		reg = re.compile('<li>(<font class="cor_move_li2">.+?)</li>', re.DOTALL)
		mat = reg.findall(entry[5])
		for ent in mat:
			infoLabels['plot'] += re.sub('<.*?>', '', ent) + '\n'

		item = xbmcgui.ListItem(label)
		item.setArt({'poster': poster})
		item.setInfo('video', infoLabels)
		item_url = createUrl({'mode': 'content', 'url': content_url})
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

	# 显示页数
	pageStr = ''
	regex = re.compile('<div class="page">(<span>.+?)</div>', re.DOTALL)
	match = regex.search(httpData)

	pageInfo = {}
	reg = re.compile('<em>(\d+)</em>', re.DOTALL)
	mat = reg.search(match.group(1))
	pageInfo['active'] = mat.group(1)

	pageInfo['list'] = []
	reg = re.compile('<(?:a|em)(.*?)>(.+?)</(?:a|em)>', re.DOTALL)
	mat = reg.findall(match.group(1))
	for entry in mat:
		if entry[0] == ' class="nolink"': continue
		elif entry[0] == '': pageInfo['list'].append(('', entry[1]))
		else:
			regi = re.compile('href="([^"]+)"', re.DOTALL)
			mati = regi.search(entry[0])
			pageInfo['list'].append((mati.group(1), entry[1]))

	if len(pageInfo['list'])>1: # 不只一页
		item = xbmcgui.ListItem('[COLOR yellow][B]页数：[/B]第%s页[/COLOR]' % pageInfo['active'])
		item.setArt({'poster': defaultPic})
		item_url = createUrl({'mode': 'list', 'change': 'page', 'pageinfo': simplejson.dumps(pageInfo)})
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

		pageStr = ' 第%s页' % pageInfo['active']

	# 设置内容
	xbmcplugin.setContent(pHandle, 'movies')
	xbmcplugin.setPluginCategory(pHandle, '剧集频道'+pageStr)
	xbmcplugin.endOfDirectory(pHandle)

	# 设置视图
	forceview = __addon__.getSetting('forceview')
	if forceview == 'true':
		viewid = __addon__.getSetting('viewid')
		setView(viewid)

def showContent():
	pageSize = 100
	url = params.get('url')
	change = params.get('change')
	if not change: #首次进入
		index = None
		page = 1
	else: # 非首次进入
		if change == 'source':
			sourceInfo = simplejson.loads(params.get('sourceinfo'))
			curSource = sourceInfo['active']
			sourceList = sourceInfo['list']

			for index, entry in enumerate(sourceList):
				if entry == {u'云播': '云播二', u'云播二': '云播'}[sourceInfo['active']]: break
				if index == len(sourceList)-1:
					xbmcgui.Dialog().ok(__addonname__, '当前暂无其他来源')
					return
			page = 1

		elif change == 'page': # 改变页数
			curPage = int(params.get('curpage'))
			totalPage = int(params.get('totalpage'))
			pageList = []
			if curPage>1: pageList.append('上一页')
			for i in range(1, totalPage+1): pageList.append(str(i))
			if curPage<totalPage: pageList.append('下一页')
			select = xbmcgui.Dialog().select('改变页数', createSelect(pageList, -1, str(curPage)))
			if select == -1 or pageList[select] == str(curPage): return
			if pageList[select] == '上一页': page = curPage-1
			elif pageList[select] == '下一页': page = curPage+1
			else: page = int(pageList[select])
			index = int(params.get('index'))

	httpData = getHttpData(url)
	if not httpData: return

	# 显示来源
	regex = re.compile('<label class="playIco_[^"]*""?>(.+?)</label>', re.DOTALL)
	match = regex.findall(httpData)
	if not match:
		xbmcgui.Dialog().ok(__addonname__, '当前剧集无法播放 %s' % url)
		return

	if not index:
		for index, entry in enumerate(match):
			if entry in ['云播', '云播二']: break
			if index == len(match)-1:
				xbmcgui.Dialog().ok(__addonname__, '当前剧集无法播放 %s' % url)
				return

	sourceInfo = {}
	sourceInfo['active'] = match[index]
	sourceInfo['list'] = match[:]

	item = xbmcgui.ListItem('[COLOR yellow][B]来源：[/B]%s[/COLOR]' % sourceInfo['active'])
	item.setArt({'poster': defaultPic})
	item_url = createUrl({'mode': 'content', 'change': 'source', 'sourceinfo': simplejson.dumps(sourceInfo), 'url': url})
	xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

	# 显示视频
	# 详情
	regex = re.compile('<div class="o_r_t_wap pr"><div class="info-title"><span>[^<]*</span><h1>(.+?)</h1>[^<]*</div><div class="info-box"><div class="o_list"><div class="o_big_img_bg_b"><img src="([^"]+)" border="0" /> </div></div>(<div class="o_r_contact_all">.+?</div>)<!--AD 300x200-->', re.DOTALL)
	match = regex.search(httpData)
	title = match.group(1)
	poster = match.group(2)

	infoLabels = {'plot': ''}
	reg = re.compile('<li><font color="#[^"]*">(.+?)</font></li>', re.DOTALL)
	mat = reg.search(match.group(3))
	if mat: infoLabels['plot'] += '更新：' + re.sub('<.*?>', '', mat.group(1)) + '\n'

	reg = re.compile('<li ?>(<em>.+?)</li>', re.DOTALL)
	mat = reg.findall(match.group(3))
	for entry in mat:
		infoLabels['plot'] += re.sub('<.*?>', '', entry.replace('<span class="more-text">更多&gt;&gt;</span>', '')) + '\n'

	reg = re.compile('<li style="position:static"><label>(.+?)</label>', re.DOTALL)
	mat = reg.search(match.group(3))
	if mat: infoLabels['plot'] += re.sub('<.*?>', '', mat.group(1).replace('</a>', ' ')) + '\n'

	reg = re.compile('<li>(<label><em>.+?</span>)</li>', re.DOTALL)
	mat = reg.findall(match.group(3))
	for entry in mat:
		infoLabels['plot'] += re.sub('<.*?>', '', entry.replace('</li><li>', '\n').replace('<span><em>', '\n')) + '\n'

	# 链接
	regex = re.compile('<div class="tabs-list"><div class="(?:omlist_box7|wp-list)">(<ul.+?</ul>)</div></div>', re.DOTALL)
	match = regex.findall(httpData)

	reg = re.compile("<a title='([^']+)' href='([^']+)' target=\"_blank\">\\1</a>", re.DOTALL)
	mat = reg.findall(match[index])
	sorttype = __addon__.getSetting('sorttype')
	if sorttype == '1': mat.reverse()
	videoList = mat[(page-1)*pageSize: min(page*pageSize, len(mat))]
	for entry in videoList:
		label = '%s %s' % (title, HTMLParser.HTMLParser().unescape(entry[0]))
		video_url = 'https://www.meijutt.tv' + entry[1]

		item = xbmcgui.ListItem(label)
		item.setArt({'poster': poster})
		item.setInfo('video', infoLabels)
		item_url = createUrl({'mode': 'play', 'url': video_url, 'label': label, 'thumb': poster})
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, False)

	# 显示页数
	pageStr = ''
	totalPage = int((len(mat)+pageSize-1)/pageSize)
	if totalPage>1:
		item = xbmcgui.ListItem('[COLOR yellow][B]页数：[/B]第%d页[/COLOR]' % page)
		item.setArt({'poster': defaultPic})
		item_url = createUrl({'mode': 'content', 'change': 'page', 'curpage': str(page), 'totalpage': str(totalPage), 'index': str(index), 'url': url})
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

		pageStr = ' 第%d页' % page

	# 设置内容
	xbmcplugin.setContent(pHandle, 'movies')
	xbmcplugin.setPluginCategory(pHandle, title+pageStr)
	xbmcplugin.endOfDirectory(pHandle)

	# 设置视图
	forceview = __addon__.getSetting('forceview')
	if forceview == 'true': setView('50')

def showRank():
	change = params.get('change')
	if not change: # 首次进入
		url = 'https://www.meijutt.tv/alltop_hit.html'
	else: # 非首次进入
		if change == 'none': return
		elif change == 'sort':
			sortInfo = simplejson.loads(params.get('sortinfo'))
			curSort = sortInfo['active']
			sortList = sortInfo['list']

			index = [entry[1] for entry in sortList].index(curSort)
			if index == len(sortList)-1: index = 0
			else: index += 1

			if sortList[index][1] == sortInfo['active']: return
			url = 'https://www.meijutt.tv/' + sortList[index][0]

	httpData = getHttpData(url)
	if not httpData: return

	# 显示排序
	sortInfo = {}
	regex = re.compile('<a href="alltop_[^"]*.html" class="asjpx">(.+?)</a>', re.DOTALL)
	match = regex.search(httpData)
	sortInfo['active'] = match.group(1)

	regex = re.compile('<a href="(alltop_[^"]+.html)"(?: class="asjpx")?>(.+?)</a>', re.DOTALL)
	match = regex.findall(httpData)
	sortInfo['list'] = match[:]

	item = xbmcgui.ListItem('[COLOR yellow][B]排序：[/B]%s[/COLOR]' % sortInfo['active'])
	item.setArt({'poster': defaultPic})
	item_url = createUrl({'mode': 'rank', 'change': 'sort', 'sortinfo': simplejson.dumps(sortInfo)})
	xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

	# 显示视频
	regex = re.compile('<div class="top-min"><div class="tt fn-clear"><h5>(.+?)</h5><span>(.+?)</span> </div><ul class="top-list fn-clear">(.+?)</ul></div>', re.DOTALL)
	match = regex.findall(httpData)
	for entry in match:
		chn = entry[0]
		tag = entry[1]

		item = xbmcgui.ListItem('[COLOR red][B]%s[/B][/COLOR]' % chn)
		item.setArt({'poster': defaultPic})
		item_url = createUrl({'mode': 'rank', 'change': 'none'})
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

		reg = re.compile('<li><div class="lasted-num fn-left" ><i>(\d+)</i></div><h5><a href="([^"]+)" title="([^"]+)" target="_blank">\\3</a></h5><div class="lasted-time fn-right(?: lasted-state)?" >(.+?)</div></li>', re.DOTALL)
		mat = reg.findall(entry[2])
		for ent in mat:
			rank = '%02d. ' % int(ent[0])
			content_url = 'https://www.meijutt.tv' + ent[1]
			label = HTMLParser.HTMLParser().unescape(ent[2])
			infoLabels = {'plot': tag + '：' + re.sub('<.*?>', '', ent[3])}

			item = xbmcgui.ListItem(rank+label)
			item.setArt({'poster': defaultPic})
			item.setInfo('video', infoLabels)
			item_url = createUrl({'mode': 'content', 'url': content_url})
			xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

	# 设置内容
	xbmcplugin.setContent(pHandle, 'files')
	xbmcplugin.setPluginCategory(pHandle, '热播排行')
	xbmcplugin.endOfDirectory(pHandle)

def showNew():
	url = 'https://www.meijutt.tv/new100.html'
	httpData = getHttpData(url)
	if not httpData: return

	# 显示视频
	regex = re.compile(u'<div style="width:100%; background-color:#fff" class="top_warp"><div class="top-min top-min-long new100"><div class="tt fn-clear"><h5>最近100个更新</h5><span style=" margin-left:272px; float:left">(.+?)</span><span style=" margin-left:157px; float:left">(.+?)</span><span style=" margin-left:171px; float:left" >(.+?)</span><span  style=" margin-right:12px; float:right">(.+?)</span> </div><ul class="top-list  fn-clear">(.+?)</ul></div><div class="list"> </div></div></div>', re.DOTALL)
	match = regex.search(httpData)
	tag1, tag2, tag3, tag4 = match.group(1,2,3,4)

	reg = re.compile('<li><div class="lasted-num fn-left"><i>(\d+)</i></div><h5><a href="([^"]+)" title="([^"]+)" target="_blank">\\3</a></h5><span class="state1 new100state1">(.+?)</span><span class="mjjq">(.+?)</span><span class="mjtv">(.+?)</span><div class="lasted-time new100time fn-right">(.+?)</div></li>', re.DOTALL)
	mat = reg.findall(match.group(5))
	for entry in mat:
		rank = '%02d. ' % int(entry[0])
		content_url = 'https://www.meijutt.tv' + entry[1]
		label = HTMLParser.HTMLParser().unescape(entry[2])

		infoLabels = {'plot': ''}
		infoLabels['plot'] += tag1 + '：' + re.sub('<.*?>', '', entry[3].replace('<span class="sub">', '[').replace('</em>', ']')) + '\n'
		infoLabels['plot'] += tag2 + '：' + entry[4] + '\n'
		infoLabels['plot'] += tag3 + '：' + entry[5] + '\n'
		infoLabels['plot'] += tag4 + '：' + re.sub('<.*?>', '', entry[6]) + '\n'

		item = xbmcgui.ListItem(rank+label)
		item.setArt({'poster': defaultPic})
		item.setInfo('video', infoLabels)
		item_url = createUrl({'mode': 'content', 'url': content_url})
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

	# 设置内容
	xbmcplugin.setContent(pHandle, 'files')
	xbmcplugin.setPluginCategory(pHandle, '最近更新')
	xbmcplugin.endOfDirectory(pHandle)

def showSearch():
	change = params.get('change')
	if not change: # 首次进入
		key = xbmcgui.Dialog().input('输入关键词')
		if not key: return
		url = 'https://www.meijutt.tv/search/index.asp?searchword=' + urllib.quote(key.encode('gb2312'))
	else: # 非首次进入
		key = params.get('key')
		if change == 'page': # 改变页数
			pageInfo = simplejson.loads(params.get('pageinfo'))
			curPage = pageInfo['active']
			pageList = pageInfo['list']
			select = xbmcgui.Dialog().select('改变页数', createSelect(pageList, 1, curPage))
			if select == -1 or pageList[select][1] == curPage: return
			url = 'https://www.meijutt.tv/search/index.asp' + pageList[select][0]

	httpData = getHttpData(url)
	if not httpData: return

	# 显示视频
	regex = re.compile('<div class="cn_box2" ><div class="cn_box_box3"><div class="bor_img3_right"> <a href="([^"]+)" title="([^"]+)" target="_blank"><img class="list_pic" src="([^"]+)" border="0" alt="\\2"/></a><em><strong class="average-big">(\d+)</strong><span class="average-small">(\.\d+)</span></em></div></div><ul class="list_20">(.+?)</ul></div>', re.DOTALL)
	match = regex.findall(httpData)
	for entry in match:
		content_url = 'https://www.meijutt.tv' + entry[0]
		label = HTMLParser.HTMLParser().unescape(entry[1])
		poster = entry[2]

		infoLabels = {'plot': '评分：' + entry[3] + entry[4] + '\n'}
		reg = re.compile('<li>(<font  ?class="cor_move_li2">.+?)</li>', re.DOTALL)
		mat = reg.findall(entry[5])
		for ent in mat:
			infoLabels['plot'] += re.sub('<.*?>', '', ent) + '\n'

		item = xbmcgui.ListItem(label)
		item.setArt({'poster': poster})
		item.setInfo('video', infoLabels)
		item_url = createUrl({'mode': 'content', 'url': content_url})
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

	# 显示页数
	pageStr = ''
	regex = re.compile('<div class="page">(<span>.+?)</div>', re.DOTALL)
	match = regex.search(httpData)

	pageInfo = {}
	reg = re.compile('<em>(\d+)</em>', re.DOTALL)
	mat = reg.search(match.group(1))
	pageInfo['active'] = mat.group(1)

	pageInfo['list'] = []
	reg = re.compile('<(?:a|em)(.*?)>(.+?)</(?:a|em)>', re.DOTALL)
	mat = reg.findall(match.group(1))
	for entry in mat:
		if entry[0] == " class='nolink'": continue
		elif entry[0] == '': pageInfo['list'].append(('', entry[1]))
		else:
			regi = re.compile("href='([^']+)'", re.DOTALL)
			mati = regi.search(entry[0])
			pageInfo['list'].append((mati.group(1), entry[1]))

	if len(pageInfo['list'])>1: # 不只一页
		item = xbmcgui.ListItem('[COLOR yellow][B]页数：[/B]第%s页[/COLOR]' % pageInfo['active'])
		item.setArt({'poster': defaultPic})
		item_url = createUrl({'mode': 'search', 'change': 'page', 'pageinfo': simplejson.dumps(pageInfo), 'key': key})
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

		pageStr = ' 第%s页' % pageInfo['active']

	# 设置内容
	xbmcplugin.setContent(pHandle, 'movies')
	xbmcplugin.setPluginCategory(pHandle, key+pageStr)
	xbmcplugin.endOfDirectory(pHandle)

	# 设置视图
	forceview = __addon__.getSetting('forceview')
	if forceview == 'true':
		viewid = __addon__.getSetting('viewid')
		setView(viewid)

def showHistory():
	# 读取历史记录
	dataDir = getDataDir()
	filePath = os.path.join(dataDir, 'history.log')
	historyList = []
	if os.path.exists(filePath):
		fHandle = open(filePath, 'r')
		try:
			historyList = simplejson.load(fHandle)
		except simplejson.scanner.JSONDecodeError, e:
			xbmcgui.Dialog().ok(__addonname__, '历史记录为空或格式有误 %s' % str(e))
			pass
		fHandle.close()

	pageSize = 100
	totalPage = int((len(historyList)+pageSize-1)/pageSize)

	change = params.get('change')
	if not change: # 首次进入
		page = 1

	else: # 非首次进入
		if change == 'page': # 改变页数
			curPage = int(params.get('curpage'))
			pageList = []
			if curPage>1: pageList.append('上一页')
			for i in range(1, totalPage+1): pageList.append(str(i))
			if curPage<totalPage: pageList.append('下一页')
			select = xbmcgui.Dialog().select('改变页数', createSelect(pageList, -1, str(curPage)))
			if select == -1 or pageList[select] == str(curPage): return
			if pageList[select] == '上一页': page = curPage-1
			elif pageList[select] == '下一页': page = curPage+1
			else: page = int(pageList[select])

		elif change == 'refresh': # 刷新列表
			page = int(params.get('curpage'))

	# 显示视频
	videoList = historyList[(page-1)*pageSize: min(page*pageSize, len(historyList))]
	for i, entry in enumerate(videoList):
		url = entry.get('url')
		label2 = entry.get('label2')
		poster = entry.get('thumb')

		if None in [url, label2, poster]:
			if xbmcgui.Dialog().yesno(__addonname__, '第%s条历史记录格式有误，是否清除记录' % str(i+1)):
				os.remove(filePath)
				break
			else: continue

		item = xbmcgui.ListItem(label2)
		item.setArt({'poster': poster})
		item.addContextMenuItems([('删除单条记录', 'RunPlugin(%s)' % createUrl({'mode': 'delete', 'index': str(i+(page-1)*pageSize), 'curpage': str(page-int(len(videoList)==1 and totalPage!=1))})), ('删除全部记录', 'RunPlugin(%s)' % createUrl({'mode': 'clear'}))])
		item_url = createUrl({'mode': 'play', 'url': url, 'label2': label2, 'thumb': poster})
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, False)

	# 显示页数
	pageStr = ''
	if totalPage>1:
		item = xbmcgui.ListItem('[COLOR yellow][B]页数：[/B]第%d页[/COLOR]' % page)
		item.setArt({'poster': defaultPic})
		item_url = createUrl({'mode': 'history', 'change': 'page', 'curpage': str(page)})
		xbmcplugin.addDirectoryItem(pHandle, item_url, item, True)

		pageStr = ' 第%d页' % page

	# 设置内容
	xbmcplugin.setContent(pHandle, 'movies')
	xbmcplugin.setPluginCategory(pHandle, '历史记录'+pageStr)
	xbmcplugin.endOfDirectory(pHandle)

	# 设置视图
	forceview = __addon__.getSetting('forceview')
	if forceview == 'true': setView('50')

def playVideo():
	pDialog = xbmcgui.DialogProgress()
	pDialog.create(__addonname__)

	poster = params.get('thumb')
	label = params.get('label')
	if label: # 非历史记录
		url = params.get('url')

		# 获取视频序号
		regex = re.compile('/video/\d+-(\d+)-(\d+).html', re.DOTALL)
		match = regex.search(url)
		i = int (match.group(1))
		j = int (match.group(2))

		# 获取视频源
		pDialog.update(25, '正在获取 [%s] 视频源，请稍等' % label)
		httpData = getHttpData(url)
		if pDialog.iscanceled(): return
		if not httpData: return

		regex = re.compile('<div class="kp_flashbox_wrap"><div class="ptitle"><script type="text/javascript" src="([^"]+)"></script>', re.DOTALL)
		match = regex.search(httpData)
		url = 'https://www.meijutt.tv' + match.group(1)

		pDialog.update(50, '正在选择 [%s] 视频源，请稍等' % label)
		httpData = getHttpData(url)
		if pDialog.iscanceled(): return
		if not httpData: return

		regex = re.compile('var VideoListJson=(\[.+?\]),urlinfo=', re.DOTALL)
		match = regex.search(httpData)
		playInfo = simplejson.loads(match.group(1))

		label2 = '%s (%s)' % (label, playInfo[i][0])
		m3u = playInfo[i][1][j][1][:-5] + playInfo[i][1][j][1][-4:]
		if not m3u.endswith('.m3u8'):
			pDialog.update(50, '正在选择 [%s] 视频源，请稍等' % label)
			httpData = getHttpData(m3u)
			if pDialog.iscanceled(): return
			if not httpData: return

			if '/share/' in m3u:
				regex = re.compile('var main = "([^"]+)";')
				match = regex.search(httpData)
				m3u = m3u.split('/share/')[0] + match.group(1)
			elif '/v/' in m3u:
				regex = re.compile("video: {\s*url: '([^']+)',")
				match = regex.search(httpData)
				m3u = match.group(1)
			else:
				xbmcgui.Dialog().ok(__addonname__, '未知视频源类型 %s' % m3u)
				return

		# 检测视频源
		pDialog.update(75, '正在检测视频源 [%s] ，请稍等' % label2)
		try:
			import urllib2
			response = urllib2.urlopen(m3u, timeout=10)
		except Exception, e:
			if pDialog.iscanceled(): return
			xbmcgui.Dialog().ok(__addonname__, '网络错误 %s %s' % (m3u, str(e)))
			return
		if pDialog.iscanceled(): return
		if response.getcode() != 200:
			xbmcgui.Dialog().ok(__addonname__, '网络错误 %s [%d]' % (m3u, response.getcode()))
			return

	else: # 历史记录
		label2 = params.get('label2')
		m3u = params.get('url')

	# 准备播放视频
	pDialog.update(100, '视频源 [%s] 检测通过，准备播放' % label2)
	item = xbmcgui.ListItem(label2)
	item.setArt({'poster': poster})
	if pDialog.iscanceled(): return

	xbmc.Player().play(m3u, item) # 播放视频
	saveHistory({'url': m3u, 'label2': label2, 'thumb': poster}) # 保存历史

	pDialog.close()

# 主程序
addon_url = sys.argv[0]
pHandle = int(sys.argv[1])
params = dict(urlparse.parse_qsl(sys.argv[2][1:]))
mode = params.get('mode')

defaultPic = os.path.join(getAddonDir(), 'media', 'default.png')

# 导航
if mode == None:
	showRoot()

# 列表
elif mode == 'list':
	showList()

# 内容
elif mode == 'content':
	showContent()

# 排行
elif mode == 'rank':
	showRank()

# 更新
elif mode == 'new':
	showNew()

# 搜索
elif mode == 'search':
	showSearch()

# 历史
elif mode == 'history':
	showHistory()

# 播放
elif mode == 'play':
	playVideo()

# 删除单条记录
elif mode == 'delete':
	deleteHistory()

# 清除历史记录
elif mode == 'clear':
	clearHistory()
