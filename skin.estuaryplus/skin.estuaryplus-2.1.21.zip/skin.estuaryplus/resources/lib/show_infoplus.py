# -*- coding: utf-8 -*-
import xbmc, xbmcgui
import sys

# 编码
if sys.getdefaultencoding() != 'utf-8':
	reload(sys)
	sys.setdefaultencoding('utf-8')

# 主程序
xbmcgui.Window(12003).setProperty('View', 'InfoPlus')

# 不是Windows平台需要手动focus
isWindows = xbmc.getCondVisibility('System.Platform.Windows')
if not isWindows:
	controlID = xbmcgui.Window(xbmcgui.getCurrentWindowId()).getFocusId()
	xbmc.executebuiltin('SetFocus("%d")' % controlID)

# 显示视频信息
xbmc.executebuiltin('Action("Info")')